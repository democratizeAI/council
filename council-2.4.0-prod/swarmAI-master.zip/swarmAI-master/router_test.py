#!/usr/bin/env python3
"""
🔥💀⚔️ ROUTER SMOKE TEST - VERIFY DISPATCHER FIX ⚔️💀🔥
========================================================
MISSION: Test intent router on key Boss-200 question types
TARGET: All tests should show ✅ 
STRATEGY: Representative examples from each category
"""

from router_intent import detect_block

def test_intent_router():
    """Test the intent router on representative questions"""
    
    tests = {
        # MATH - Should all route to "math"
        "What is 25% of 240?": "math",
        "Calculate 7!": "math", 
        "Calculate 15! factorial": "math",
        "What is 2^10?": "math",
        "What is the square root of 144?": "math",
        "Calculate 8 * 7 * 6 * 5": "math",
        "What is 40% of 150?": "math",
        "Calculate 12 * 13": "math",
        "What is 15% of 200?": "math",
        "Calculate 9!": "math",
        
        # CODE - Should all route to "code" 
        "Write a Python function to reverse a string": "code",
        "Write a function to calculate factorial": "code",
        "Implement binary search in Python": "code",
        "Write a function to check if number is prime": "code",
        "Implement bubble sort algorithm": "code",
        "Write a function to merge two sorted lists": "code",
        "Algorithm to find maximum in list": "code",
        "def factorial(n):": "code",
        "Binary search rotated array": "code",
        "Reverse a string function": "code",
        
        # KNOWLEDGE - Should all route to "knowledge"
        "What is the capital of France?": "knowledge", 
        "Who wrote Romeo and Juliet?": "knowledge",
        "What is the chemical symbol for gold?": "knowledge",
        "In what year did World War II end?": "knowledge",
        "What is the largest planet in our solar system?": "knowledge",
        "What is the capital of Germany?": "knowledge",
        "Who wrote Hamlet?": "knowledge",
        "What is the capital of Japan?": "knowledge",
        "Chemical symbol for silver": "knowledge",
        "When did WWII start?": "knowledge",
        
        # LOGIC - Should all route to "logic"
        "A job starts at 09:00 and takes 6 hours": "logic",
        "Schedule three jobs with constraints": "logic", 
        "Job A before job B, job C after B": "logic",
        "What is the earliest start time?": "logic",
        "Jobs must not overlap": "logic",
        "Schedule tasks with dependencies": "logic",
        "Temporal ordering problem": "logic",
        "Constraint satisfaction": "logic",
        "Before and after relationships": "logic",
        "Scheduling optimization": "logic",
    }
    
    print("🔥💀⚔️ ROUTER INTENT TEST")
    print("=" * 50)
    print("🎯 Testing dispatcher routing accuracy")
    print()
    
    correct = 0
    total = len(tests)
    
    # Group by expected category for cleaner output
    categories = {}
    for question, expected in tests.items():
        if expected not in categories:
            categories[expected] = []
        categories[expected].append(question)
    
    for category in ["math", "code", "knowledge", "logic"]:
        if category in categories:
            print(f"📊 {category.upper()} QUESTIONS:")
            category_correct = 0
            category_total = len(categories[category])
            
            for question in categories[category]:
                expected = tests[question]
                got = detect_block(question)
                is_correct = got == expected
                
                if is_correct:
                    correct += 1
                    category_correct += 1
                
                status = "✅" if is_correct else "❌"
                print(f"   {status} {question[:45]:45} → {got}")
            
            print(f"   📈 {category.upper()}: {category_correct}/{category_total} correct\n")
    
    accuracy = correct / total
    print(f"🎯 OVERALL ACCURACY: {correct}/{total} = {accuracy:.1%}")
    
    if accuracy >= 0.9:
        print("✅ ROUTER READY - Accuracy ≥90%")
        return True
    else:
        print("❌ ROUTER NEEDS TUNING - Add more patterns/keywords")
        return False

if __name__ == "__main__":
    success = test_intent_router()
    
    if success:
        print("\n🚀 READY FOR INTEGRATION")
    else:
        print("\n🔧 TUNE PATTERNS BEFORE INTEGRATION") 