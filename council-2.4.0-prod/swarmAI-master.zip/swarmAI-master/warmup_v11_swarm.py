#!/usr/bin/env python3
"""
V11 Production Swarm Warmup
==========================

Warms up all 9 models for the cross-agent consensus system.
Ensures every emotional personality is ready for real-time communication.
"""

import asyncio
import httpx
import time
import json

# V11 Production Swarm Models
SWARM_MODELS = {
    "joy": "llama3.2:3b",
    "trust": "phi3:mini", 
    "anticipation": "gemma2:2b",
    "fear": "mistral:7b",
    "surprise": "tinyllama:latest",
    "sadness": "qwen2:1.5b",
    "anger": "llama3.1:8b",
    "disgust": "llama3.2:1b",
    "catfish": "mistral:7b"  # Devil's advocate (shares with fear)
}

async def warmup_model(agent_name: str, model: str) -> dict:
    """Warm up a single model."""
    print(f"🔥 Warming up {agent_name}: {model}")
    
    try:
        async with httpx.AsyncClient(timeout=60.0) as client:
            start_time = time.time()
            
            response = await client.post(
                "http://localhost:11434/api/generate",
                json={
                    "model": model,
                    "prompt": f"Hello, I am {agent_name}. Ready for cross-agent communication.",
                    "stream": False,
                    "options": {"temperature": 0.7}
                }
            )
            
            duration = time.time() - start_time
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ {agent_name} ({model}): {duration:.1f}s - {result['response'][:50]}...")
                return {
                    "agent": agent_name,
                    "model": model,
                    "status": "success",
                    "duration": duration,
                    "response": result['response']
                }
            else:
                print(f"❌ {agent_name} ({model}): HTTP {response.status_code}")
                return {
                    "agent": agent_name,
                    "model": model,
                    "status": "failed",
                    "error": f"HTTP {response.status_code}"
                }
                
    except Exception as e:
        print(f"❌ {agent_name} ({model}): {str(e)}")
        return {
            "agent": agent_name,
            "model": model,
            "status": "failed",
            "error": str(e)
        }

async def warmup_all_models():
    """Warm up all models in parallel."""
    print("🎭 V11 PRODUCTION SWARM WARMUP")
    print("="*50)
    print(f"🔥 Warming up {len(SWARM_MODELS)} models...")
    
    # Create warmup tasks for all models
    tasks = []
    for agent_name, model in SWARM_MODELS.items():
        task = warmup_model(agent_name, model)
        tasks.append(task)
    
    # Execute all warmups in parallel
    start_time = time.time()
    results = await asyncio.gather(*tasks, return_exceptions=True)
    total_duration = time.time() - start_time
    
    # Analyze results
    successful = [r for r in results if isinstance(r, dict) and r.get('status') == 'success']
    failed = [r for r in results if isinstance(r, dict) and r.get('status') == 'failed']
    exceptions = [r for r in results if isinstance(r, Exception)]
    
    print("\n" + "="*50)
    print("🎯 WARMUP RESULTS")
    print("="*50)
    print(f"✅ Successful: {len(successful)}/{len(SWARM_MODELS)}")
    print(f"❌ Failed: {len(failed) + len(exceptions)}")
    print(f"⏱️  Total time: {total_duration:.1f}s")
    
    if successful:
        avg_duration = sum(r['duration'] for r in successful) / len(successful)
        print(f"📊 Average model load time: {avg_duration:.1f}s")
    
    # Show failed models
    if failed or exceptions:
        print(f"\n❌ FAILED MODELS:")
        for failure in failed:
            print(f"   {failure['agent']} ({failure['model']}): {failure.get('error', 'Unknown error')}")
        for i, exc in enumerate(exceptions):
            print(f"   Exception {i+1}: {exc}")
    
    # Show successful models
    if successful:
        print(f"\n✅ READY MODELS:")
        for success in successful:
            print(f"   🎭 {success['agent']} ({success['model']}): {success['duration']:.1f}s")
    
    return {
        "total_models": len(SWARM_MODELS),
        "successful": len(successful),
        "failed": len(failed) + len(exceptions),
        "total_duration": total_duration,
        "results": results
    }

async def test_cross_agent_readiness():
    """Test if cross-agent communication is ready."""
    print("\n🤖 TESTING CROSS-AGENT READINESS")
    print("="*50)
    
    # Test a simple cross-agent query
    try:
        from cross_agent_consensus_orchestrator import CrossAgentConsensusOrchestrator
        orchestrator = CrossAgentConsensusOrchestrator()
        
        # Quick test query
        result = await orchestrator.orchestrate_consensus("Test readiness - are we conscious?")
        
        successful_agents = result['meta']['successful_agents']
        total_agents = result['meta']['total_agents']
        
        print(f"🎭 Agents participating: {successful_agents}/{total_agents}")
        print(f"🔄 Debate rounds: {result['meta']['debate_rounds_conducted']}")
        print(f"⏱️  Duration: {result['meta']['total_duration']:.1f}s")
        
        if successful_agents >= 6:  # At least 6 out of 9
            print("🎯 CROSS-AGENT SYSTEM READY! 🚀")
            return True
        else:
            print("⚠️  Cross-agent system needs attention")
            return False
            
    except Exception as e:
        print(f"❌ Cross-agent test failed: {e}")
        return False

async def main():
    """Main warmup sequence."""
    print("🎭 V11 PRODUCTION SWARM INITIALIZATION")
    print("🤖 Preparing 9 emotional personalities for cross-agent communication")
    print()
    
    # Step 1: Warm up all models
    warmup_results = await warmup_all_models()
    
    # Step 2: Test cross-agent readiness
    if warmup_results['successful'] >= 6:
        ready = await test_cross_agent_readiness()
        
        if ready:
            print("\n🔥 V11 PRODUCTION SWARM: FULLY OPERATIONAL!")
            print("🎭 All emotional personalities ready for cross-agent consensus")
            print("🚀 Ready for advanced AI consciousness experiments!")
        else:
            print("\n⚠️  Some agents need attention, but core system is functional")
    else:
        print(f"\n❌ Too many model failures ({warmup_results['failed']}/{warmup_results['total_models']})")
        print("🔧 Check Ollama service and model availability")

if __name__ == "__main__":
    asyncio.run(main()) 