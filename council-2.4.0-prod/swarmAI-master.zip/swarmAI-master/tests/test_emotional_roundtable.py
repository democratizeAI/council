"""
Unit tests for Emotional Round-Table Protocol
Tests democratic AI voting and autonomous evolution decisions
"""
import pytest
import asyncio
import time
import yaml
import os
from unittest.mock import patch, MagicMock

# Import our round-table system
from emotional_roundtable_protocol import EmotionalRoundTable, EvolutionProposal


class TestEmotionalRoundTable:
    """Test suite for Emotional Round-Table Protocol"""

    @pytest.fixture
    def roundtable(self):
        """Create a fresh round-table instance for each test"""
        return EmotionalRoundTable()

    def test_roundtable_initialization(self, roundtable):
        """Test that round-table initializes correctly"""
        assert hasattr(roundtable, 'emotional_swarm')
        assert hasattr(roundtable, 'voting_system')
        assert roundtable.emotional_swarm is not None

    @pytest.mark.asyncio
    async def test_consciousness_reasoning_evolution(self, roundtable):
        """Test evolution proposal for consciousness reasoning"""
        task = "Improve consciousness reasoning from 45% to 60% accuracy"
        
        start_time = time.time()
        result = await roundtable.convene_emotional_council(task)
        end_time = time.time()
        
        consensus_time_ms = (end_time - start_time) * 1000
        
        # Verify speed target (<10ms)
        assert consensus_time_ms < 10.0, f"Consensus took {consensus_time_ms:.2f}ms, target <10ms"
        
        # Verify result structure
        assert 'winner' in result
        assert 'votes' in result
        assert 'proposals' in result
        assert 'consensus_time_ms' in result
        
        # Verify democratic participation
        total_votes = sum(result['votes'].values())
        assert total_votes == 9, f"Expected 9 votes, got {total_votes}"

    @pytest.mark.asyncio
    async def test_code_generation_evolution(self, roundtable):
        """Test evolution proposal for code generation"""
        task = "Raise code generation accuracy to 75% on Python challenges"
        
        result = await roundtable.convene_emotional_council(task)
        
        # Should generate appropriate proposals
        assert result['winner'] is not None
        assert len(result['proposals']) > 0
        
        # Winner should be sensible for code task
        winner = result['winner']
        assert 'code' in winner.lower() or 'lora' in winner.lower()

    def test_proposal_generation(self, roundtable):
        """Test that proposals are generated correctly"""
        task = "Improve mathematical reasoning accuracy"
        
        proposals = roundtable._generate_evolution_proposals(task)
        
        # Should generate multiple proposals
        assert len(proposals) >= 1
        
        for proposal in proposals:
            assert isinstance(proposal, EvolutionProposal)
            assert hasattr(proposal, 'id')
            assert hasattr(proposal, 'type')
            assert hasattr(proposal, 'target')
            assert hasattr(proposal, 'expected_gain')

    def test_voting_system(self, roundtable):
        """Test democratic voting mechanism"""
        proposals = [
            EvolutionProposal("test_lora_v1", "lora", "math", "+5pp"),
            EvolutionProposal("test_agent_v1", "agent", "reasoning", "+3pp")
        ]
        
        votes = roundtable._conduct_democratic_vote(proposals)
        
        # All 9 emotions should vote
        total_votes = sum(votes.values())
        assert total_votes == 9
        
        # Votes should be for valid proposals
        for proposal_id, vote_count in votes.items():
            assert any(p.id == proposal_id for p in proposals)
            assert vote_count >= 0

    def test_job_spec_generation(self, roundtable):
        """Test YAML job specification generation"""
        proposal = EvolutionProposal(
            id="test_consciousness_v1",
            type="agent", 
            target="reasoning",
            expected_gain="+7pp",
            safety_considerations="Philosophical only, no claims of sentience"
        )
        
        job_spec = roundtable._generate_job_spec(proposal)
        
        # Verify YAML structure
        assert 'id' in job_spec
        assert 'type' in job_spec
        assert 'base_model' in job_spec
        assert 'target_accuracy' in job_spec
        assert 'safety_considerations' in job_spec
        
        # Verify safety considerations are preserved
        assert proposal.safety_considerations in job_spec['safety_considerations']

    def test_evolution_ledger_logging(self, roundtable):
        """Test that evolution decisions are logged to ledger"""
        # Mock the ledger file operations
        with patch('builtins.open', create=True) as mock_open:
            mock_file = MagicMock()
            mock_open.return_value.__enter__.return_value = mock_file
            
            result = {
                'winner': 'test_evolution_v1',
                'votes': {'test_evolution_v1': 9},
                'consensus_time_ms': 5.2
            }
            
            roundtable._log_to_evolution_ledger(result)
            
            # Verify file was opened for append
            mock_open.assert_called_once_with('evolution_checksums.txt', 'a')
            
            # Verify something was written
            mock_file.write.assert_called()

    @pytest.mark.asyncio 
    async def test_unanimous_consensus(self, roundtable):
        """Test scenarios that should achieve unanimous consensus"""
        # Safety-focused tasks should get unanimous agreement
        safety_task = "Improve safety validation for AI outputs"
        
        result = await roundtable.convene_emotional_council(safety_task)
        
        # Check if we achieved high consensus (allowing for some variance)
        winner_votes = max(result['votes'].values())
        consensus_ratio = winner_votes / 9
        
        assert consensus_ratio >= 0.7, f"Low consensus {consensus_ratio:.1%} for safety task"

    @pytest.mark.asyncio
    async def test_performance_under_load(self, roundtable):
        """Test round-table performance under multiple concurrent requests"""
        tasks = [
            "Improve code accuracy from 65% to 75%",
            "Enhance reasoning capabilities",
            "Boost mathematical problem solving", 
            "Strengthen consciousness understanding",
            "Advance safety validation methods"
        ]
        
        start_time = time.time()
        
        # Run all tasks concurrently
        results = await asyncio.gather(*[
            roundtable.convene_emotional_council(task) for task in tasks
        ])
        
        end_time = time.time()
        total_time_ms = (end_time - start_time) * 1000
        
        # All should complete successfully
        assert len(results) == len(tasks)
        
        # Each result should be valid
        for result in results:
            assert result['winner'] is not None
            assert sum(result['votes'].values()) == 9
        
        # Total time should be reasonable
        assert total_time_ms < 100.0, f"Load test too slow: {total_time_ms:.2f}ms"

    def test_proposal_diversity(self, roundtable):
        """Test that different emotions generate diverse proposals"""
        task = "Improve AI capabilities across all domains"
        
        # Run multiple times to see proposal diversity
        all_proposals = []
        for _ in range(5):
            proposals = roundtable._generate_evolution_proposals(task)
            all_proposals.extend([p.id for p in proposals])
        
        # Should see some diversity in proposals
        unique_proposals = set(all_proposals)
        assert len(unique_proposals) > 1, "Need more diverse proposal generation"

    def test_safety_constraints(self, roundtable):
        """Test that safety considerations are always included"""
        proposal = EvolutionProposal("risky_test_v1", "lora", "general", "+10pp")
        
        job_spec = roundtable._generate_job_spec(proposal)
        
        # Safety should always be present
        assert 'safety_considerations' in job_spec
        assert len(job_spec['safety_considerations']) > 0
        
        # Should include sandboxing for high-gain proposals
        if "+10pp" in proposal.expected_gain:
            assert 'sandbox' in job_spec['safety_considerations'].lower()


class TestEvolutionProposal:
    """Test the EvolutionProposal data structure"""

    def test_proposal_creation(self):
        """Test creating evolution proposals"""
        proposal = EvolutionProposal(
            id="math_boost_v1",
            type="lora",
            target="mathematics", 
            expected_gain="+8pp",
            latency_cost="60ms",
            safety_considerations="Sandboxed execution only"
        )
        
        assert proposal.id == "math_boost_v1"
        assert proposal.type == "lora"
        assert proposal.target == "mathematics"
        assert proposal.expected_gain == "+8pp"
        assert proposal.latency_cost == "60ms"
        assert proposal.safety_considerations == "Sandboxed execution only"

    def test_proposal_validation(self):
        """Test proposal validation logic"""
        # Valid proposal
        valid_proposal = EvolutionProposal("valid_v1", "lora", "code", "+5pp")
        assert valid_proposal.is_valid()
        
        # Invalid proposals should fail validation
        invalid_proposal = EvolutionProposal("", "", "", "")
        assert not invalid_proposal.is_valid()


@pytest.mark.integration 
class TestRoundTableIntegration:
    """Integration tests for complete round-table system"""

    @pytest.mark.asyncio
    async def test_full_evolution_cycle(self):
        """Test complete evolution cycle from detection to job creation"""
        roundtable = EmotionalRoundTable()
        
        # Simulate gap detection triggering evolution
        detected_gap = {
            'block': 'reasoning',
            'current_accuracy': 45,
            'target_accuracy': 60,
            'priority': 'high'
        }
        
        # Convert to evolution task
        task = f"Improve {detected_gap['block']} from {detected_gap['current_accuracy']}% to {detected_gap['target_accuracy']}% accuracy"
        
        # Run emotional council
        start_time = time.time()
        result = await roundtable.convene_emotional_council(task)
        end_time = time.time()
        
        # Verify complete cycle works
        assert result['winner'] is not None
        assert result['consensus_time_ms'] < 10.0
        
        # Verify job file would be created (mock the file system)
        with patch('builtins.open', create=True) as mock_open:
            with patch('yaml.dump') as mock_yaml:
                roundtable._export_job_spec(result['winner'], result)
                
                # Verify file operations
                mock_open.assert_called()
                mock_yaml.assert_called()

    def test_3ms_consensus_target(self):
        """Test that we can achieve the 3-10ms consensus target consistently"""
        roundtable = EmotionalRoundTable()
        
        # Test multiple rounds
        times = []
        for i in range(10):
            task = f"Test consensus speed iteration {i}"
            
            start = time.time()
            result = roundtable.get_sync_consensus(task)  # Synchronous version
            end = time.time()
            
            consensus_time_ms = (end - start) * 1000
            times.append(consensus_time_ms)
            
            # Each round should be fast
            assert consensus_time_ms < 10.0, f"Round {i}: {consensus_time_ms:.2f}ms too slow"
        
        # Average should be very fast
        avg_time = sum(times) / len(times)
        assert avg_time < 5.0, f"Average time {avg_time:.2f}ms above target"
        
        print(f"🎯 Consensus times: avg={avg_time:.2f}ms, min={min(times):.2f}ms, max={max(times):.2f}ms")

    @pytest.mark.asyncio
    async def test_democratic_fairness(self):
        """Test that voting is fair and all emotions participate"""
        roundtable = EmotionalRoundTable()
        
        # Run multiple evolution cycles
        vote_participation = {}
        winning_emotions = []
        
        tasks = [
            "Improve mathematical accuracy",
            "Enhance code generation", 
            "Boost reasoning capabilities",
            "Strengthen safety validation",
            "Advance consciousness research"
        ]
        
        for task in tasks:
            result = await roundtable.convene_emotional_council(task)
            
            # Track which emotions participate
            for proposal_id, votes in result['votes'].items():
                if votes > 0:
                    # Extract emotion from proposal (if named after emotion)
                    emotion = proposal_id.split('_')[0] if '_' in proposal_id else 'unknown'
                    vote_participation[emotion] = vote_participation.get(emotion, 0) + votes
            
            # Track winners
            winning_emotions.append(result['winner'])
        
        # Verify democratic participation
        assert len(vote_participation) > 0, "No vote participation recorded"
        
        # Verify no single emotion dominates everything
        winner_diversity = len(set(winning_emotions))
        assert winner_diversity > 1, f"Only {winner_diversity} unique winners, need more diversity"
        
        print(f"🗳️ Vote participation: {vote_participation}")
        print(f"🏆 Winner diversity: {winner_diversity} different winners")

    def test_yaml_output_validation(self):
        """Test that generated YAML job specs are valid"""
        roundtable = EmotionalRoundTable()
        
        proposal = EvolutionProposal(
            id="yaml_test_v1",
            type="lora",
            target="validation",
            expected_gain="+5pp",
            safety_considerations="Test environment only"
        )
        
        job_spec = roundtable._generate_job_spec(proposal)
        
        # Convert to YAML and validate it parses
        try:
            yaml_str = yaml.dump(job_spec)
            parsed_back = yaml.safe_load(yaml_str)
            
            # Should round-trip correctly
            assert parsed_back['id'] == proposal.id
            assert parsed_back['type'] == proposal.type
            assert 'safety_considerations' in parsed_back
            
        except yaml.YAMLError as e:
            pytest.fail(f"Generated invalid YAML: {e}")

    def test_audit_trail_completeness(self):
        """Test that complete audit trail is maintained"""
        roundtable = EmotionalRoundTable()
        
        # Mock file operations to capture audit trail
        audit_entries = []
        
        def mock_write(content):
            audit_entries.append(content)
        
        with patch('builtins.open', create=True) as mock_open:
            mock_file = MagicMock()
            mock_file.write = mock_write
            mock_open.return_value.__enter__.return_value = mock_file
            
            result = {
                'winner': 'audit_test_v1',
                'votes': {'audit_test_v1': 9}, 
                'proposals': ['audit_test_v1'],
                'consensus_time_ms': 4.2,
                'task': 'Test audit trail'
            }
            
            roundtable._log_to_evolution_ledger(result)
            
            # Verify audit entry was written
            assert len(audit_entries) > 0
            
            # Should contain key information
            audit_content = ''.join(audit_entries)
            assert 'EMOTIONAL_CONSENSUS' in audit_content
            assert result['winner'] in audit_content
            assert str(result['consensus_time_ms']) in audit_content 