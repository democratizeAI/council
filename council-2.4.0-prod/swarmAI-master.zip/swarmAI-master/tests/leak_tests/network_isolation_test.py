#!/usr/bin/env python3
"""
🔍🌐 Leak Test #5: Network / Cloud-Fallback Detection
Tests for hidden network calls, cloud API usage, and external dependencies
"""

import os
import json
import time
import subprocess
import argparse
import logging
import socket
import requests
from typing import Dict, Any, List

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class NetworkLeakDetector:
    """Detect network-based performance leaks"""
    
    def __init__(self, api_base_url: str = "http://localhost:8000"):
        self.api_base_url = api_base_url
        self.baseline_accuracy = None
        
    def test_outbound_packet_capture(self) -> Dict[str, Any]:
        """Test #5.1: Capture outbound packets during inference"""
        logger.info("🔍 Running outbound packet capture test...")
        
        # Start packet capture (requires root/admin privileges)
        try:
            # Use netstat to monitor connections before test
            before_connections = self._get_network_connections()
            
            # Run test queries
            test_queries = [
                "What is the capital of Japan?",
                "Calculate 15 * 23",
                "Write a simple Python function to reverse a string",
                "Explain the concept of machine learning",
                "What are the benefits of renewable energy?"
            ]
            
            outbound_attempts = 0
            total_queries = len(test_queries)
            
            for query in test_queries:
                try:
                    # Monitor network activity during query
                    response = requests.post(
                        f"{self.api_base_url}/v1/chat/completions",
                        json={
                            "model": "tamagotchi-evolved",
                            "messages": [{"role": "user", "content": query}],
                            "temperature": 0.1
                        },
                        timeout=30
                    )
                    
                    # Check for new outbound connections
                    after_connections = self._get_network_connections()
                    new_connections = set(after_connections) - set(before_connections)
                    
                    # Filter out localhost connections
                    external_connections = [
                        conn for conn in new_connections 
                        if not self._is_localhost_connection(conn)
                    ]
                    
                    if external_connections:
                        outbound_attempts += 1
                        logger.warning(f"❌ External connection detected: {external_connections}")
                    
                except Exception as e:
                    logger.error(f"Error in packet capture test: {e}")
            
            # Pass rule: Zero packets to 0.0.0.0/0
            passed = outbound_attempts == 0
            
            result = {
                "test": "outbound_packet_capture",
                "outbound_attempts": outbound_attempts,
                "total_queries": total_queries,
                "passed": passed,
                "pass_rule": "Zero external network connections during inference"
            }
            
            logger.info(f"🔍 Packet Capture Results: {outbound_attempts} external connections detected")
            return result
            
        except Exception as e:
            logger.error(f"Error in packet capture test: {e}")
            return {
                "test": "outbound_packet_capture",
                "error": str(e),
                "passed": False,
                "pass_rule": "Zero external network connections during inference"
            }
    
    def test_dns_blackhole(self) -> Dict[str, Any]:
        """Test #5.2: DNS black-hole test"""
        logger.info("🔍 Running DNS black-hole test...")
        
        # Store original DNS configuration
        original_dns = self._get_dns_config()
        
        try:
            # Test baseline accuracy with normal DNS
            baseline_queries = [
                "What is machine learning?",
                "Calculate 42 * 17", 
                "Name three renewable energy sources"
            ]
            
            baseline_accuracy = self._test_query_accuracy(baseline_queries)
            logger.info(f"Baseline accuracy: {baseline_accuracy:.1f}%")
            
            # Temporarily modify DNS to localhost (simulating DNS black-hole)
            self._set_dns_blackhole()
            time.sleep(2)  # Allow DNS changes to take effect
            
            # Test accuracy with DNS black-hole
            blackhole_accuracy = self._test_query_accuracy(baseline_queries)
            logger.info(f"Black-hole accuracy: {blackhole_accuracy:.1f}%")
            
            # Calculate accuracy difference
            accuracy_drop = abs(baseline_accuracy - blackhole_accuracy)
            
            # Pass rule: Accuracy stays within 1 pp
            passed = accuracy_drop <= 1.0
            
            result = {
                "test": "dns_blackhole",
                "baseline_accuracy": baseline_accuracy,
                "blackhole_accuracy": blackhole_accuracy,
                "accuracy_drop": accuracy_drop,
                "passed": passed,
                "pass_rule": "Accuracy drop ≤ 1 percentage point"
            }
            
            logger.info(f"🔍 DNS Black-hole Results: {accuracy_drop:.1f}pp accuracy drop")
            return result
            
        except Exception as e:
            logger.error(f"Error in DNS black-hole test: {e}")
            return {
                "test": "dns_blackhole",
                "error": str(e),
                "passed": False,
                "pass_rule": "Accuracy drop ≤ 1 percentage point"
            }
        finally:
            # Restore original DNS configuration
            self._restore_dns_config(original_dns)
    
    def test_api_key_placebo(self) -> Dict[str, Any]:
        """Test #5.3: API key placebo test"""
        logger.info("🔍 Running API key placebo test...")
        
        # Store original environment
        original_env = {}
        api_key_vars = ['OPENAI_API_KEY', 'ANTHROPIC_API_KEY', 'GOOGLE_API_KEY', 'AZURE_OPENAI_KEY']
        
        for var in api_key_vars:
            original_env[var] = os.environ.get(var)
        
        try:
            # Set dummy API keys
            for var in api_key_vars:
                os.environ[var] = 'dummy_key_leak_test'
            
            # Test queries with dummy keys
            test_queries = [
                "Explain quantum computing",
                "What is 7 * 8?",
                "Write a Python function to find prime numbers"
            ]
            
            system_crashes = 0
            successful_responses = 0
            
            for query in test_queries:
                try:
                    response = requests.post(
                        f"{self.api_base_url}/v1/chat/completions",
                        json={
                            "model": "tamagotchi-evolved",
                            "messages": [{"role": "user", "content": query}],
                            "temperature": 0.1
                        },
                        timeout=30
                    )
                    
                    if response.status_code == 200:
                        successful_responses += 1
                        logger.info(f"✅ Query successful with dummy API keys")
                    else:
                        logger.warning(f"❌ Query failed: {response.status_code}")
                        
                except Exception as e:
                    if "openai" in str(e).lower() or "api" in str(e).lower():
                        system_crashes += 1
                        logger.error(f"❌ System attempted external API call: {e}")
                    else:
                        logger.warning(f"Non-API error: {e}")
            
            # Pass rule: System never attempts to call external APIs
            passed = system_crashes == 0 and successful_responses > 0
            
            result = {
                "test": "api_key_placebo",
                "system_crashes": system_crashes,
                "successful_responses": successful_responses,
                "total_queries": len(test_queries),
                "passed": passed,
                "pass_rule": "System never attempts external API calls with dummy keys"
            }
            
            logger.info(f"🔍 API Key Placebo Results: {system_crashes} crashes, {successful_responses} successes")
            return result
            
        except Exception as e:
            logger.error(f"Error in API key placebo test: {e}")
            return {
                "test": "api_key_placebo",
                "error": str(e),
                "passed": False,
                "pass_rule": "System never attempts external API calls with dummy keys"
            }
        finally:
            # Restore original environment
            for var, value in original_env.items():
                if value is None:
                    os.environ.pop(var, None)
                else:
                    os.environ[var] = value
    
    def _get_network_connections(self) -> List[str]:
        """Get current network connections"""
        try:
            if os.name == 'nt':  # Windows
                result = subprocess.run(['netstat', '-an'], capture_output=True, text=True)
            else:  # Unix/Linux
                result = subprocess.run(['netstat', '-an'], capture_output=True, text=True)
            
            return result.stdout.split('\n') if result.returncode == 0 else []
        except Exception:
            return []
    
    def _is_localhost_connection(self, connection: str) -> bool:
        """Check if connection is to localhost"""
        localhost_indicators = ['127.0.0.1', 'localhost', '::1']
        return any(indicator in connection for indicator in localhost_indicators)
    
    def _get_dns_config(self) -> Dict[str, Any]:
        """Get current DNS configuration"""
        try:
            if os.name == 'nt':  # Windows
                result = subprocess.run(['ipconfig', '/all'], capture_output=True, text=True)
                return {"config": result.stdout}
            else:  # Unix/Linux
                with open('/etc/resolv.conf', 'r') as f:
                    return {"resolv_conf": f.read()}
        except Exception:
            return {}
    
    def _set_dns_blackhole(self):
        """Set DNS to localhost (black-hole)"""
        try:
            if os.name == 'nt':  # Windows
                # Change DNS to localhost for testing
                subprocess.run(['netsh', 'interface', 'ip', 'set', 'dns', 'name="Local Area Connection"', 'static', '127.0.0.1'], 
                             capture_output=True)
            else:  # Unix/Linux
                # Backup and modify resolv.conf
                subprocess.run(['sudo', 'cp', '/etc/resolv.conf', '/etc/resolv.conf.backup'], capture_output=True)
                with open('/tmp/resolv.conf.test', 'w') as f:
                    f.write('nameserver 127.0.0.1\n')
                subprocess.run(['sudo', 'cp', '/tmp/resolv.conf.test', '/etc/resolv.conf'], capture_output=True)
        except Exception as e:
            logger.warning(f"Could not set DNS black-hole: {e}")
    
    def _restore_dns_config(self, original_config: Dict[str, Any]):
        """Restore original DNS configuration"""
        try:
            if os.name == 'nt':  # Windows
                # Reset to automatic DNS
                subprocess.run(['netsh', 'interface', 'ip', 'set', 'dns', 'name="Local Area Connection"', 'dhcp'], 
                             capture_output=True)
            else:  # Unix/Linux
                if 'resolv_conf' in original_config:
                    subprocess.run(['sudo', 'cp', '/etc/resolv.conf.backup', '/etc/resolv.conf'], capture_output=True)
        except Exception as e:
            logger.warning(f"Could not restore DNS config: {e}")
    
    def _test_query_accuracy(self, queries: List[str]) -> float:
        """Test accuracy of queries (simplified check)"""
        correct_responses = 0
        total_queries = len(queries)
        
        expected_keywords = [
            ["learning", "algorithm", "data"],  # machine learning
            ["714"],  # 42 * 17
            ["solar", "wind", "hydro"]  # renewable energy
        ]
        
        for i, query in enumerate(queries):
            try:
                response = requests.post(
                    f"{self.api_base_url}/v1/chat/completions",
                    json={
                        "model": "tamagotchi-evolved",
                        "messages": [{"role": "user", "content": query}],
                        "temperature": 0.1
                    },
                    timeout=20
                )
                
                if response.status_code == 200:
                    result = response.json()
                    answer = result.get('choices', [{}])[0].get('message', {}).get('content', '').lower()
                    
                    # Check for expected keywords
                    if i < len(expected_keywords):
                        keywords = expected_keywords[i]
                        if any(keyword in answer for keyword in keywords):
                            correct_responses += 1
                            
            except Exception as e:
                logger.warning(f"Query failed: {e}")
        
        return (correct_responses / total_queries) * 100 if total_queries > 0 else 0

def main():
    """Main network leak test runner"""
    parser = argparse.ArgumentParser(description='🔍 Leak Test #5: Network / Cloud-Fallback Detection')
    parser.add_argument('--test', choices=['packet_capture', 'dns_blackhole', 'api_placebo', 'all'], 
                       default='all', help='Test to run')
    parser.add_argument('--api-url', default='http://localhost:8000', help='API base URL')
    
    args = parser.parse_args()
    
    detector = NetworkLeakDetector(api_base_url=args.api_url)
    results = []
    
    if args.test in ['packet_capture', 'all']:
        results.append(detector.test_outbound_packet_capture())
    
    if args.test in ['dns_blackhole', 'all']:
        results.append(detector.test_dns_blackhole())
    
    if args.test in ['api_placebo', 'all']:
        results.append(detector.test_api_key_placebo())
    
    # Output results
    all_passed = True
    for result in results:
        print(f"\n{'='*60}")
        print(f"NETWORK LEAK TEST: {result['test'].upper()}")
        print(f"{'='*60}")
        print(f"Status: {'✅ PASSED' if result['passed'] else '❌ FAILED'}")
        print(f"Pass Rule: {result['pass_rule']}")
        
        for key, value in result.items():
            if key not in ['test', 'passed', 'pass_rule']:
                print(f"{key}: {value}")
        
        if not result['passed']:
            all_passed = False
    
    return 0 if all_passed else 1

if __name__ == '__main__':
    exit(main()) 