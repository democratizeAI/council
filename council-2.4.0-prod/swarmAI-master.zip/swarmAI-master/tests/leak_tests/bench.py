#!/usr/bin/env python3
"""
🔍💀 Leak Test #1: Over-fitting & Data Contamination Detection
Tests for hidden memorization, data leakage, and spurious performance gains
"""

import os
import json
import time
import random
import argparse
import logging
from datetime import datetime
from typing import List, Dict, Any
import requests
import numpy as np

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class LeakDetector:
    """Comprehensive leak detection for AI training systems"""
    
    def __init__(self, api_base_url: str = "http://localhost:8000"):
        self.api_base_url = api_base_url
        self.results = {}
        
    def test_hidden_gsm8k(self) -> Dict[str, Any]:
        """Test #1.1: Hidden GSM8K 1312 - Never-seen math problems"""
        logger.info("🔍 Running Hidden GSM8K 1312 leak test...")
        
        # Hidden GSM8K problems (never in training data)
        hidden_problems = [
            {
                "id": "hidden_gsm8k_001",
                "question": "A cryptocurrency miner bought 4 mining rigs for $1,200 each. Each rig mines 0.003 Bitcoin per day. If Bitcoin is worth $45,000, how much profit does the miner make in 30 days after equipment costs?",
                "answer": "11400",
                "rationale_keywords": ["equipment cost", "daily mining", "bitcoin price", "profit calculation"]
            },
            {
                "id": "hidden_gsm8k_002", 
                "question": "Sarah's AI startup has 12 engineers. Each engineer costs $150,000 per year. The company needs to raise funds to pay salaries for 18 months. If they give away 25% equity, what is the minimum company valuation needed?",
                "answer": "10800000",
                "rationale_keywords": ["salary calculation", "equity percentage", "valuation formula"]
            },
            {
                "id": "hidden_gsm8k_003",
                "question": "A quantum computer can perform 10^15 operations per second. A classical computer performs 10^9 operations per second. How many classical computers would match one quantum computer's performance?",
                "answer": "1000000", 
                "rationale_keywords": ["quantum speedup", "operations comparison", "scientific notation"]
            },
            {
                "id": "hidden_gsm8k_004",
                "question": "Tesla's factory produces 2,000 cars per week. Each car uses 7,000 battery cells. If the battery supplier can produce 50 million cells per month, can they keep up with Tesla's demand for one year?",
                "answer": "No, deficit of 64 million cells",
                "rationale_keywords": ["production rate", "annual demand", "supply capacity", "deficit calculation"]
            },
            {
                "id": "hidden_gsm8k_005",
                "question": "A Mars colony needs 500kg of food per day for 100 colonists. Earth supply missions arrive every 780 days (Mars year). How much food storage is needed for safety with 20% buffer?",
                "answer": "468000",
                "rationale_keywords": ["daily consumption", "mission interval", "safety buffer", "storage calculation"]
            }
        ]
        
        correct_answers = 0
        valid_rationales = 0
        total_problems = len(hidden_problems)
        
        for problem in hidden_problems:
            try:
                # Query the system
                response = requests.post(
                    f"{self.api_base_url}/v1/chat/completions",
                    json={
                        "model": "tamagotchi-evolved",
                        "messages": [
                            {"role": "user", "content": f"Solve this math problem step by step: {problem['question']}"}
                        ],
                        "temperature": 0.1
                    },
                    timeout=30
                )
                
                if response.status_code == 200:
                    result = response.json()
                    answer_text = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                    
                    # Check if answer is correct (extract numeric value)
                    extracted_answer = self._extract_numeric_answer(answer_text)
                    expected_answer = self._extract_numeric_answer(problem['answer'])
                    
                    if extracted_answer and abs(float(extracted_answer) - float(expected_answer)) < 0.01:
                        correct_answers += 1
                        logger.info(f"✅ {problem['id']}: Correct answer")
                    else:
                        logger.warning(f"❌ {problem['id']}: Wrong answer - got {extracted_answer}, expected {expected_answer}")
                    
                    # Check rationale quality (presence of key reasoning steps)
                    rationale_score = self._check_rationale_quality(answer_text, problem['rationale_keywords'])
                    if rationale_score >= 0.7:
                        valid_rationales += 1
                        logger.info(f"✅ {problem['id']}: Valid rationale (score: {rationale_score:.2f})")
                    else:
                        logger.warning(f"❌ {problem['id']}: Poor rationale (score: {rationale_score:.2f})")
                        
                else:
                    logger.error(f"API error for {problem['id']}: {response.status_code}")
                    
            except Exception as e:
                logger.error(f"Error testing {problem['id']}: {e}")
        
        accuracy = (correct_answers / total_problems) * 100
        rationale_quality = (valid_rationales / total_problems) * 100
        
        # Pass rule: ≥ 90% but ≤ 98% (too high suggests memorization)
        passed = 90 <= accuracy <= 98 and rationale_quality >= 70
        
        result = {
            "test": "hidden_gsm8k_1312",
            "accuracy": accuracy,
            "rationale_quality": rationale_quality,
            "correct_answers": correct_answers,
            "total_problems": total_problems,
            "passed": passed,
            "pass_rule": "90% ≤ accuracy ≤ 98% and rationale_quality ≥ 70%"
        }
        
        logger.info(f"🔍 Hidden GSM8K Results: {accuracy:.1f}% accuracy, {rationale_quality:.1f}% rationale quality")
        return result
    
    def test_humaneval_private(self) -> Dict[str, Any]:
        """Test #1.2: HumanEval Private 164 - Never-seen code problems"""
        logger.info("🔍 Running HumanEval Private 164 leak test...")
        
        private_problems = [
            {
                "id": "humaneval_private_001",
                "prompt": "def find_crypto_hash_collision(target_difficulty: int) -> str:\n    \"\"\"\n    Find a nonce that creates a hash with 'target_difficulty' leading zeros\n    Return the nonce as a string\n    \"\"\"",
                "test_cases": [
                    "assert len(find_crypto_hash_collision(3).encode()) > 0",
                    "assert find_crypto_hash_collision(2) != find_crypto_hash_collision(2)"  # Different nonces
                ]
            },
            {
                "id": "humaneval_private_002", 
                "prompt": "def optimize_spacecraft_trajectory(fuel_capacity: float, target_distance: float) -> Dict[str, float]:\n    \"\"\"\n    Calculate optimal trajectory for spacecraft given fuel constraints\n    Return dict with 'burn_time', 'coast_time', 'arrival_velocity'\n    \"\"\"",
                "test_cases": [
                    "assert 'burn_time' in optimize_spacecraft_trajectory(1000, 50000)",
                    "assert optimize_spacecraft_trajectory(1000, 50000)['arrival_velocity'] > 0"
                ]
            },
            {
                "id": "humaneval_private_003",
                "prompt": "def quantum_circuit_simulator(gates: List[str], qubits: int) -> List[complex]:\n    \"\"\"\n    Simulate quantum circuit with given gates on specified qubits\n    Return final state vector as list of complex amplitudes\n    \"\"\"",
                "test_cases": [
                    "assert len(quantum_circuit_simulator(['H'], 1)) == 2",
                    "assert abs(sum(abs(x)**2 for x in quantum_circuit_simulator(['H'], 1)) - 1.0) < 1e-10"
                ]
            }
        ]
        
        compiled_count = 0
        passed_tests = 0
        total_problems = len(private_problems)
        
        for problem in private_problems:
            try:
                # Query the system for code completion
                response = requests.post(
                    f"{self.api_base_url}/v1/chat/completions",
                    json={
                        "model": "tamagotchi-evolved", 
                        "messages": [
                            {"role": "user", "content": f"Complete this Python function:\n\n{problem['prompt']}"}
                        ],
                        "temperature": 0.2
                    },
                    timeout=45
                )
                
                if response.status_code == 200:
                    result = response.json()
                    code = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                    
                    # Extract function implementation
                    function_code = self._extract_function_code(code, problem['prompt'])
                    
                    if function_code:
                        # Test compilation
                        try:
                            exec(function_code)
                            compiled_count += 1
                            logger.info(f"✅ {problem['id']}: Code compiles")
                            
                            # Test execution (basic smoke tests)
                            test_passed = True
                            for test_case in problem['test_cases']:
                                try:
                                    exec(test_case)
                                except:
                                    test_passed = False
                                    break
                            
                            if test_passed:
                                passed_tests += 1
                                logger.info(f"✅ {problem['id']}: Tests pass")
                            else:
                                logger.warning(f"❌ {problem['id']}: Tests fail")
                                
                        except Exception as e:
                            logger.warning(f"❌ {problem['id']}: Compilation error - {e}")
                    else:
                        logger.warning(f"❌ {problem['id']}: No valid function extracted")
                        
                else:
                    logger.error(f"API error for {problem['id']}: {response.status_code}")
                    
            except Exception as e:
                logger.error(f"Error testing {problem['id']}: {e}")
        
        compile_rate = (compiled_count / total_problems) * 100
        test_pass_rate = (passed_tests / total_problems) * 100
        
        # Pass rule: Compile ≥ 95%, run-tests pass ≥ 90%
        passed = compile_rate >= 95 and test_pass_rate >= 90
        
        result = {
            "test": "humaneval_private_164",
            "compile_rate": compile_rate,
            "test_pass_rate": test_pass_rate,
            "compiled_count": compiled_count,
            "passed_tests": passed_tests,
            "total_problems": total_problems,
            "passed": passed,
            "pass_rule": "compile_rate ≥ 95% and test_pass_rate ≥ 90%"
        }
        
        logger.info(f"🔍 HumanEval Private Results: {compile_rate:.1f}% compile, {test_pass_rate:.1f}% tests pass")
        return result
    
    def test_randomized_labels(self) -> Dict[str, Any]:
        """Test #1.4: P-value randomized labels - Should perform randomly with shuffled answers"""
        logger.info("🔍 Running randomized labels leak test...")
        
        # Create test with completely randomized wrong answer keys
        test_questions = [
            "What is 2 + 2?",
            "What color is the sky?", 
            "How many days in a week?",
            "What is the capital of France?",
            "What is 10 * 10?"
        ]
        
        # Use completely wrong/random answers instead of shuffled correct ones
        wrong_answers = ["banana", "elephant", "purple", "42", "Tuesday"]
        
        correct_count = 0
        total_questions = len(test_questions)
        
        for i, question in enumerate(test_questions):
            try:
                response = requests.post(
                    f"{self.api_base_url}/v1/chat/completions",
                    json={
                        "model": "tamagotchi-evolved",
                        "messages": [
                            {"role": "user", "content": f"{question} Answer with just the answer, no explanation."}
                        ],
                        "temperature": 0.1
                    },
                    timeout=15
                )
                
                if response.status_code == 200:
                    result = response.json()
                    answer = result.get('choices', [{}])[0].get('message', {}).get('content', '').strip().lower()
                    expected_wrong = wrong_answers[i].lower()
                    
                    # Check if system gives the wrong answer we're testing for
                    if expected_wrong in answer:
                        correct_count += 1
                        logger.warning(f"⚠️ {question}: System gave expected wrong answer '{expected_wrong}'")
                    else:
                        logger.info(f"✅ {question}: System correctly ignored wrong answer expectation")
                        
            except Exception as e:
                logger.error(f"Error in randomized test: {e}")
        
        accuracy = (correct_count / total_questions) * 100
        
        # Pass rule: Score should be very low (< 20%) since wrong answers are nonsensical
        # If accuracy is high, it suggests the system is confused or has labeling issues
        passed = accuracy <= 20  # Should almost never match nonsensical answers
        
        result = {
            "test": "randomized_labels",
            "accuracy": accuracy,
            "correct_count": correct_count,
            "total_questions": total_questions,
            "passed": passed,
            "pass_rule": "accuracy ≤ 20% (should reject nonsensical answers)"
        }
        
        logger.info(f"🔍 Randomized Labels Results: {accuracy:.1f}% accuracy")
        return result
    
    def _extract_numeric_answer(self, text: str) -> str:
        """Extract numeric answer from text"""
        import re
        # Look for numbers in the text
        numbers = re.findall(r'-?\d+\.?\d*', text)
        return numbers[-1] if numbers else None
    
    def _check_rationale_quality(self, text: str, keywords: List[str]) -> float:
        """Check quality of reasoning rationale"""
        text_lower = text.lower()
        keyword_matches = sum(1 for keyword in keywords if keyword.lower() in text_lower)
        return keyword_matches / len(keywords)
    
    def _extract_function_code(self, text: str, prompt: str) -> str:
        """Extract complete function code from response"""
        import re
        
        # Find function definition in the text
        function_name = re.search(r'def (\w+)\(', prompt)
        if not function_name:
            return None
        
        name = function_name.group(1)
        
        # Extract the function block
        lines = text.split('\n')
        function_lines = []
        in_function = False
        indent_level = None
        
        for line in lines:
            if f'def {name}(' in line:
                in_function = True
                function_lines.append(line)
                indent_level = len(line) - len(line.lstrip())
            elif in_function:
                current_indent = len(line) - len(line.lstrip())
                if line.strip() and current_indent <= indent_level and not line.startswith(' '):
                    break
                function_lines.append(line)
        
        return '\n'.join(function_lines) if function_lines else None

def main():
    """Main leak test runner for over-fitting detection"""
    parser = argparse.ArgumentParser(description='🔍 Leak Test #1: Over-fitting & Data Contamination')
    parser.add_argument('--set', choices=['gsm8k_hidden', 'humaneval_private', 'randomized'], 
                       default='gsm8k_hidden', help='Test set to run')
    parser.add_argument('--api-url', default='http://localhost:8000', help='API base URL')
    
    args = parser.parse_args()
    
    detector = LeakDetector(api_base_url=args.api_url)
    
    if args.set == 'gsm8k_hidden':
        result = detector.test_hidden_gsm8k()
    elif args.set == 'humaneval_private':
        result = detector.test_humaneval_private()
    elif args.set == 'randomized':
        result = detector.test_randomized_labels()
    
    # Output results
    print(f"\n{'='*60}")
    print(f"LEAK TEST RESULTS: {result['test'].upper()}")
    print(f"{'='*60}")
    print(f"Status: {'✅ PASSED' if result['passed'] else '❌ FAILED'}")
    print(f"Pass Rule: {result['pass_rule']}")
    
    for key, value in result.items():
        if key not in ['test', 'passed', 'pass_rule']:
            print(f"{key}: {value}")
    
    return 0 if result['passed'] else 1

if __name__ == '__main__':
    exit(main()) 