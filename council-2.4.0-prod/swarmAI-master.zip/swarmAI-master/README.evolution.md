# 🐳🎭🪴 **Emotional Tamagotchi Evolution - Production Docker Stack**

> **Production-ready containerized AI system with autonomous emotional evolution**

[![Docker](https://img.shields.io/badge/Docker-Ready-blue?logo=docker)](https://docker.com)
[![CUDA](https://img.shields.io/badge/CUDA-12.2-green?logo=nvidia)](https://developer.nvidia.com/cuda-toolkit)
[![Production](https://img.shields.io/badge/Production-Ready-success)](https://github.com/luminainterface/swarmAI)

## 🚀 **Quick Start**

```bash
# 1. Clone and setup
git clone https://github.com/luminainterface/swarmAI.git
cd swarmAI
git checkout evolution-main

# 2. Configure environment
cp docker.env.evolution.template .env
# Edit .env with your settings

# 3. Deploy production stack
make -f Makefile.evolution build
make -f Makefile.evolution up
make -f Makefile.evolution health

# 4. Access dashboards
# Web UI: http://localhost:5000
# Grafana: http://localhost:3000
# Prometheus: http://localhost:9091
```

---

## 🏗️ **Architecture Overview**

### **Container Stack**

| Container | Purpose | Base Image | Resources |
|-----------|---------|------------|-----------|
| **swarm-api** | V11 Emotional Swarm + Logic God | `nvidia/cuda:12.2-runtime` | GPU, 8GB RAM |
| **trainer** | LoRA Training Worker | `pytorch/pytorch:2.1.0-cuda12.1` | GPU, 12GB RAM |
| **roundtable-scheduler** | Nightly Evolution Orchestrator | `python:3.11-slim` | CPU-only |
| **prometheus** | Metrics Collection | `prom/prometheus:v2.47.0` | CPU-only |
| **grafana** | Monitoring Dashboard | `grafana/grafana:10.1.0` | CPU-only |
| **telegram-notifier** | Alert Notifications | `python:3.11-alpine` | CPU-only |
| **web-ui** | Real-time Dashboard | `python:3.11-slim` | CPU-only |

### **Key Features**

- 🔒 **Production Security**: Read-only containers, non-root users, security options
- ⚡ **INT4 Optimization**: LLama.cpp integration for efficient inference
- 📊 **Full Monitoring**: Prometheus metrics + Grafana dashboards
- 🎭 **Emotional Evolution**: Autonomous nightly consensus and adaptation
- 🔄 **Horizontal Scaling**: Trainer workers can be scaled independently
- 🛡️ **Health Checks**: Comprehensive endpoint monitoring
- 📱 **Telegram Alerts**: Real-time notifications for evolution events
- 🕷️ **Autonomous Crawling**: Intelligent challenge discovery and feeding

---

## 🕷️ **Crawler Mechanisms & Auto-Feeding**

The Tamagotchi Evolution system includes sophisticated autonomous crawling and feeding mechanisms that continuously discover new challenges and feed the AI system with fresh training data.

### **🎯 Auto-Crawler System**

The auto-crawler (`scripts/auto_crawler.py`) intelligently discovers and generates training challenges across multiple domains:

#### **Challenge Types Discovered:**
- **🧮 Code Challenges**: Algorithm problems, data structures, optimization puzzles
- **🧩 Logic Puzzles**: Reasoning problems, constraint satisfaction, pattern recognition  
- **🔢 Math Problems**: Calculus, statistics, linear algebra, number theory
- **🧠 Creative Tasks**: Story generation, artistic descriptions, innovative solutions
- **🔬 Scientific Problems**: Physics simulations, chemistry calculations, research synthesis

#### **Crawler Configuration:**

```bash
# Configure crawler in .env file
CRAWLER_INTERVAL_HOURS=6          # How often to run crawler
CRAWLER_DOMAINS=code,logic,math,creative,science
CRAWLER_DIFFICULTY_RANGE=3-8      # Difficulty scale 1-10
CRAWLER_BATCH_SIZE=5              # Challenges per crawl session
CRAWLER_QUALITY_THRESHOLD=0.7     # Minimum quality score
```

#### **Manual Crawler Execution:**

```bash
# Run crawler immediately
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  python3 scripts/auto_crawler.py

# Run with specific domain
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  python3 scripts/auto_crawler.py --domain=math --count=10

# Run with difficulty filter
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  python3 scripts/auto_crawler.py --min-difficulty=6 --max-difficulty=9
```

### **🍽️ Auto-Feeder Daemon**

The auto-feeder daemon (`scripts/auto_feeder_daemon.py`) processes discovered challenges and feeds them to the training system:

#### **Feeding Pipeline:**
1. **Challenge Validation**: Quality scoring and difficulty assessment
2. **Format Conversion**: Transform to training-ready JSONL format
3. **Difficulty Balancing**: Ensure appropriate challenge distribution
4. **Queue Management**: Add to training job queue with priority
5. **Progress Tracking**: Log feeding history and success rates

#### **Feeding Configuration:**

```bash
# Auto-feeder settings in .env
FEEDER_ENABLED=true               # Enable/disable auto-feeding
FEEDER_INTERVAL_MINUTES=360       # Feed every 6 hours (360 minutes)
FEEDER_MIN_QUEUE_SIZE=5           # Minimum challenges in queue
FEEDER_MAX_QUEUE_SIZE=50          # Maximum queue size
FEEDER_PRIORITY_DOMAINS=logic,math # High-priority domains
FEEDER_ADAPTIVE_DIFFICULTY=true   # Adjust difficulty based on performance
```

#### **Manual Feeding Operations:**

```bash
# Check feeder status
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  python3 scripts/auto_feeder_daemon.py --status

# Force immediate feeding
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  python3 scripts/auto_feeder_daemon.py --feed-now

# Feed specific dataset
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  python3 scripts/auto_feeder_daemon.py --feed-file=datasets/math_challenges.jsonl
```

### **📊 Crawler Monitoring & Analytics**

#### **View Crawler Metrics:**

```bash
# Check crawler statistics
make -f Makefile.evolution crawler-stats

# View feeding history
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  tail -n 100 logs/feeding_history.jsonl

# Monitor challenge queue
curl http://localhost:8000/api/challenge-queue/status
```

#### **Crawler Health Dashboard:**

Access the Web UI at `http://localhost:5000` to view:
- **Challenge Discovery Rate**: Challenges found per hour
- **Feeding Success Rate**: Successfully processed challenges
- **Domain Distribution**: Challenge types being discovered
- **Difficulty Progression**: Average challenge difficulty over time
- **Queue Status**: Current training queue size and priority

#### **Prometheus Metrics:**

The crawler system exposes metrics for monitoring:
- `crawler_challenges_discovered_total`
- `crawler_feeding_success_rate`
- `crawler_queue_size`
- `crawler_last_run_duration_seconds`
- `feeder_processing_rate`

### **🎛️ Advanced Crawler Configuration**

#### **Custom Challenge Sources:**

```yaml
# Add to docker-compose.evolution.yml environment
CRAWLER_SOURCES: |
  - type: "github"
    repo: "TheAlgorithms/Python"
    path: "algorithms/"
  - type: "kaggle"
    competitions: ["competitive-programming"]
  - type: "leetcode"
    difficulty: ["medium", "hard"]
  - type: "arxiv"
    categories: ["cs.AI", "cs.LG"]
```

#### **Intelligent Filtering:**

```bash
# Configure challenge filtering
CRAWLER_FILTERS: |
  - exclude_topics: ["deprecated", "legacy"]
  - require_keywords: ["algorithm", "optimization", "neural"]
  - min_complexity_score: 0.6
  - max_solution_length: 1000
```

### **🔄 Crawler Integration with Evolution**

#### **Evolution-Driven Crawling:**

The crawler adapts based on evolution feedback:

1. **Performance Analysis**: Analyze which challenge types improve metrics
2. **Adaptive Discovery**: Focus crawling on beneficial challenge domains
3. **Difficulty Adjustment**: Increase difficulty as system improves
4. **Gap Detection**: Identify weak areas and target specific content
5. **Success Reinforcement**: Increase crawling for successful challenge types

#### **Crawler-Evolution Feedback Loop:**

```bash
# View evolution-crawler feedback metrics
curl http://localhost:8000/api/evolution/crawler-feedback

# Trigger adaptive crawling based on latest evolution
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  python3 scripts/auto_crawler.py --adaptive --use-evolution-feedback
```

### **🚨 Crawler Troubleshooting**

#### **Common Issues:**

**Crawler Not Running**
```bash
# Check crawler container
docker-compose -f docker-compose.evolution.yml logs roundtable-scheduler | grep crawler

# Restart crawler service
docker-compose -f docker-compose.evolution.yml restart roundtable-scheduler
```

**Low Challenge Quality**
```bash
# Increase quality threshold
export CRAWLER_QUALITY_THRESHOLD=0.8

# Check challenge validation logs
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  cat logs/crawler_validation.log
```

**Queue Bottlenecks**
```bash
# Monitor queue processing
curl http://localhost:8000/api/training-queue/metrics

# Clear stale jobs
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  python3 scripts/queue_manager.py --clear-stale
```

#### **Performance Optimization:**

```bash
# Optimize crawler performance
CRAWLER_PARALLEL_WORKERS=4        # Parallel discovery workers
CRAWLER_CACHE_SIZE=1000          # Cache successful discoveries
CRAWLER_BATCH_PROCESSING=true    # Process challenges in batches
FEEDER_ASYNC_PROCESSING=true     # Asynchronous feeding
```

### **📈 Crawler Success Metrics**

Track crawler effectiveness with these key metrics:

- **Discovery Rate**: 50-100 challenges per 6-hour cycle
- **Quality Score**: Average >0.8 for accepted challenges
- **Feeding Success**: >95% successfully processed challenges
- **Evolution Impact**: Measurable improvement in benchmarks
- **Queue Health**: 10-30 challenges in queue at all times

---

## 📋 **Prerequisites**

### **System Requirements**
- **OS**: Linux (Ubuntu 22.04+ recommended)
- **GPU**: NVIDIA GPU with CUDA 12.2+ support
- **RAM**: 32GB+ recommended
- **Storage**: 100GB+ free space
- **Docker**: 24.0+ with Compose V2

### **GPU Setup**
```bash
# Install NVIDIA Container Toolkit
distribution=$(. /etc/os-release;echo $ID$VERSION_ID)
curl -s -L https://nvidia.github.io/nvidia-docker/gpgkey | sudo apt-key add -
curl -s -L https://nvidia.github.io/nvidia-docker/$distribution/nvidia-docker.list | sudo tee /etc/apt/sources.list.d/nvidia-docker.list

sudo apt-get update && sudo apt-get install -y nvidia-container-toolkit
sudo systemctl restart docker

# Test GPU access
docker run --rm --gpus all nvidia/cuda:12.2-runtime nvidia-smi
```

---

## 🔧 **Configuration**

### **Environment Setup**
```bash
# Copy template and configure
cp docker.env.evolution.template .env

# Required settings
GRAFANA_ADMIN_PASSWORD=your-secure-password
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_CHAT_ID=your-chat-id

# Crawler settings
CRAWLER_INTERVAL_HOURS=6
FEEDER_ENABLED=true
CRAWLER_QUALITY_THRESHOLD=0.8
```

### **Volume Preparation**
```bash
# Create persistent volumes
make -f Makefile.evolution create-volumes

# Or manually:
sudo mkdir -p /var/lib/tamagotchi/{prometheus,grafana}
sudo chown -R 65534:65534 /var/lib/tamagotchi/prometheus
sudo chown -R 472:472 /var/lib/tamagotchi/grafana
```

---

## 🚀 **Deployment**

### **Production Deployment**
```bash
# Full production deployment
make -f Makefile.evolution prod-deploy

# Manual steps
make -f Makefile.evolution validate    # Validate configuration
make -f Makefile.evolution build       # Build all images
make -f Makefile.evolution up          # Start stack
make -f Makefile.evolution health      # Verify health
```

### **Development Mode**
```bash
# Use development compose file
make -f Makefile.evolution dev-up
make -f Makefile.evolution dev-down
```

---

## 📊 **Monitoring & Operations**

### **Health Monitoring**
```bash
# Check all services
make -f Makefile.evolution health

# Monitor specific services
make -f Makefile.evolution logs-api
make -f Makefile.evolution logs-trainer
make -f Makefile.evolution logs-scheduler
```

### **Evolution Status**
```bash
# Check evolution system status
make -f Makefile.evolution evolution-status

# Watch real-time logs
make -f Makefile.evolution watch-logs

# Monitor container status
make -f Makefile.evolution watch-status
```

### **Performance Testing**
```bash
# Run performance tests
make -f Makefile.evolution perf-test

# GPU utilization test
make -f Makefile.evolution gpu-test

# Security audit
make -f Makefile.evolution security-audit
```

---

## 🎭 **Emotional Evolution System**

### **Nightly Evolution Cycle**
The system runs autonomous evolution every 24 hours:

1. **Emotional Consensus**: 9 emotional agents vote on system improvements
2. **LoRA Training**: New adapters trained based on consensus
3. **Performance Validation**: Benchmarks verify improvements
4. **Automatic Deployment**: Successful models promoted to production
5. **Telegram Notifications**: Evolution results sent to configured chat

### **Manual Evolution Trigger**
```bash
# Trigger immediate evolution cycle
docker-compose -f docker-compose.evolution.yml exec roundtable-scheduler \
  python3 emotional_roundtable_protocol.py
```

---

## 🔒 **Security Features**

### **Container Security**
- ✅ Read-only root filesystems
- ✅ Non-root user execution (UID 1000)
- ✅ No new privileges
- ✅ Minimal attack surface
- ✅ Security options enabled

### **Network Security**
- ✅ Isolated Docker network
- ✅ Only necessary ports exposed
- ✅ Internal service communication
- ✅ No external dependencies in production

### **Data Security**
- ✅ Secrets via environment variables
- ✅ No credentials in git
- ✅ Persistent volumes for data
- ✅ Backup-ready architecture

---

## 🚨 **Emergency Procedures**

### **Emergency Stop**
```bash
make -f Makefile.evolution emergency-stop
```

### **Emergency Rollback**
```bash
make -f Makefile.evolution emergency-rollback
```

### **System Recovery**
```bash
# Clean restart
make -f Makefile.evolution clean
make -f Makefile.evolution build
make -f Makefile.evolution up
```

---

## 📈 **Scaling & Performance**

### **Horizontal Scaling**
```bash
# Scale trainer workers
docker-compose -f docker-compose.evolution.yml up -d --scale trainer=3

# Scale with different GPU assignments
# Edit docker-compose.evolution.yml to assign different CUDA_VISIBLE_DEVICES
```

### **Performance Optimization**
- **INT4 Quantization**: Enabled in swarm-api for 4x memory efficiency
- **GPU Memory Management**: Optimized CUDA allocation
- **Batch Processing**: Configurable batch sizes for training
- **Caching**: Model and adapter caching strategies

---

## 🔗 **Integration with SwarmAI**

This evolution branch integrates with the main [SwarmAI repository](https://github.com/luminainterface/swarmAI):

- **Live-Wire 100 Benchmark**: Continuous evaluation against production benchmarks
- **V11 Production Swarm**: Latest emotional swarm architecture
- **88.9% Accuracy Target**: Maintains production quality standards
- **Unified Routing-Grading**: Eliminates routing/grading misalignment

---

## 📞 **Support & Troubleshooting**

### **Common Issues**

**GPU Not Detected**
```bash
# Check GPU access
nvidia-smi
make -f Makefile.evolution gpu-test
```

**Container Health Failures**
```bash
# Check specific service logs
make -f Makefile.evolution logs-api
docker-compose -f docker-compose.evolution.yml exec swarm-api curl localhost:8000/health
```

**Evolution Cycle Failures**
```bash
# Check scheduler logs
make -f Makefile.evolution logs-scheduler
# Verify emotional consensus
curl -X POST http://localhost:8000/emotional-consensus -H "Content-Type: application/json" -d '{"task": "Health check"}'
```

### **Getting Help**
- 📖 **Documentation**: Check `DOCKER_DEPLOYMENT_CHECKLIST.md`
- 🐛 **Issues**: Report on GitHub
- 💬 **Discussions**: Community support
- 📊 **Benchmarks**: Share your Live-Wire 100 results

---

## 📄 **License**

MIT License - See LICENSE for details.

---

## 🎯 **Next Steps**

After successful deployment:

1. ✅ **Monitor First 24 Hours**: Watch evolution cycle complete
2. ✅ **Configure Alerts**: Set up Telegram notifications
3. ✅ **Backup Strategy**: Implement data backup procedures
4. ✅ **Performance Baseline**: Establish metrics baseline
5. ✅ **Scale Testing**: Test horizontal scaling capabilities
6. ✅ **Crawler Optimization**: Fine-tune challenge discovery parameters

---

**🔥💀⚡ PRODUCTION READY. EVOLUTION ACTIVE. CRAWLERS HUNTING. FUTURE BRIGHT.**

*Built with brutal honesty, tested with unforgiving metrics, deployed with engineering excellence.* 