#!/usr/bin/env python3
"""
🔥💀⚔️ CODE COMPLEXITY TEST - SPRINT S-4 ⚔️💀🔥
===============================================
MISSION: Validate code-complexity gap solutions
TARGET: Dynamic programming, algorithm design, edge-case I/O
STRATEGY: 20-problem test slice with compilation and unit test validation
EXPECTED GAIN: +20pp on HumanEval
"""

import time
import json
import requests
import ast
import re
import subprocess
import sys
import tempfile
import os
from typing import List, Dict, Any

class CodeComplexityTest:
    """Code complexity test slice for Sprint S-4 validation"""
    
    def __init__(self, server_url: str = "http://localhost:8000/query"):
        self.server_url = server_url
        
        self.test_problems = [
            # Dynamic Programming Problems
            {
                "query": "def fibonacci_dp(n): # Implement fibonacci using dynamic programming for O(n) time complexity",
                "type": "dynamic_programming",
                "difficulty": "medium",
                "category": "classic_dp",
                "expected_patterns": ["dp", "for", "range", "return"],
                "test_inputs": [5, 10, 0, 1],
                "expected_outputs": [5, 55, 0, 1]
            },
            {
                "query": "Write a function to solve the 0/1 knapsack problem using dynamic programming",
                "type": "dynamic_programming", 
                "difficulty": "hard",
                "category": "optimization_dp",
                "expected_patterns": ["dp", "weights", "values", "capacity"],
                "test_description": "knapsack optimization"
            },
            {
                "query": "def longest_common_subsequence(text1, text2): # LCS using DP",
                "type": "dynamic_programming",
                "difficulty": "medium",
                "category": "string_dp",
                "expected_patterns": ["dp", "len", "text1", "text2"],
                "test_inputs": [("abcde", "ace"), ("abc", "abc")],
                "expected_outputs": [3, 3]
            },
            {
                "query": "Create a function for longest increasing subsequence using dynamic programming",
                "type": "dynamic_programming",
                "difficulty": "hard", 
                "category": "sequence_dp",
                "expected_patterns": ["dp", "increasing", "subsequence"],
                "test_description": "LIS optimization"
            },
            {
                "query": "def coin_change(coins, amount): # Minimum coins needed using DP",
                "type": "dynamic_programming",
                "difficulty": "medium",
                "category": "classic_dp",
                "expected_patterns": ["dp", "coins", "amount", "min"],
                "test_inputs": [([1,3,4], 6), ([2], 3)],
                "expected_outputs": [2, -1]
            },
            
            # Algorithm Design Problems
            {
                "query": "Implement merge sort algorithm with O(n log n) complexity",
                "type": "algorithm_design",
                "difficulty": "medium",
                "category": "sorting_algorithms",
                "expected_patterns": ["merge_sort", "merge", "mid", "left", "right"],
                "test_inputs": [[64, 34, 25, 12, 22, 11, 90], [5, 2, 4, 6, 1, 3]],
                "expected_outputs": [[11, 12, 22, 25, 34, 64, 90], [1, 2, 3, 4, 5, 6]]
            },
            {
                "query": "Write a quick sort implementation with proper partitioning",
                "type": "algorithm_design",
                "difficulty": "medium",
                "category": "sorting_algorithms", 
                "expected_patterns": ["quick_sort", "partition", "pivot"],
                "test_description": "quicksort with partitioning"
            },
            {
                "query": "def binary_search_tree_insert(root, val): # BST insertion with balancing consideration",
                "type": "algorithm_design",
                "difficulty": "hard",
                "category": "tree_algorithms",
                "expected_patterns": ["TreeNode", "left", "right", "val"],
                "test_description": "BST operations"
            },
            {
                "query": "Implement depth-first search for graphs using adjacency list",
                "type": "algorithm_design",
                "difficulty": "medium",
                "category": "graph_algorithms",
                "expected_patterns": ["dfs", "visited", "graph", "adjacency"],
                "test_description": "graph traversal"
            },
            {
                "query": "Create a function to find shortest path using Dijkstra's algorithm",
                "type": "algorithm_design",
                "difficulty": "hard",
                "category": "graph_algorithms",
                "expected_patterns": ["dijkstra", "priority", "queue", "distance"],
                "test_description": "shortest path optimization"
            },
            
            # Edge-Case I/O Problems  
            {
                "query": "def robust_json_parser(json_string): # Handle malformed JSON, empty input, nested structures",
                "type": "edge_case_io",
                "difficulty": "hard",
                "category": "input_validation",
                "expected_patterns": ["json", "try", "except", "parse"],
                "test_inputs": ['{"a": 1}', '{"malformed": }', '', 'null'],
                "expected_behaviors": ["success", "error_handling", "error_handling", "success"]
            },
            {
                "query": "Write a CSV parser that handles quoted fields, escaped characters, and edge cases",
                "type": "edge_case_io",
                "difficulty": "medium", 
                "category": "text_processing",
                "expected_patterns": ["csv", "quote", "escape", "split"],
                "test_description": "robust CSV parsing"
            },
            {
                "query": "def safe_division(a, b): # Handle division by zero, infinity, NaN cases",
                "type": "edge_case_io",
                "difficulty": "easy",
                "category": "numeric_edge_cases",
                "expected_patterns": ["if", "zero", "float", "inf"],
                "test_inputs": [(10, 2), (10, 0), (0, 0), (float('inf'), 2)],
                "expected_behaviors": ["normal", "zero_division", "indeterminate", "infinity"]
            },
            {
                "query": "Create a function to validate and sanitize user input for SQL injection prevention",
                "type": "edge_case_io",
                "difficulty": "hard",
                "category": "security_validation", 
                "expected_patterns": ["sanitize", "escape", "sql", "injection"],
                "test_description": "input sanitization"
            },
            {
                "query": "def memory_efficient_file_reader(filename, chunk_size=1024): # Read large files without memory overflow",
                "type": "edge_case_io",
                "difficulty": "medium",
                "category": "memory_management",
                "expected_patterns": ["chunk", "yield", "file", "open"],
                "test_description": "streaming file processing"
            },
            
            # Complex Algorithm Combinations
            {
                "query": "Implement A* pathfinding algorithm with heuristic function",
                "type": "complex_algorithm",
                "difficulty": "hard",
                "category": "advanced_algorithms",
                "expected_patterns": ["astar", "heuristic", "f_score", "g_score"],
                "test_description": "advanced pathfinding"
            },
            {
                "query": "def sliding_window_maximum(nums, k): # Find maximum in each sliding window efficiently",
                "type": "complex_algorithm", 
                "difficulty": "hard",
                "category": "optimization_algorithms",
                "expected_patterns": ["deque", "window", "maximum", "sliding"],
                "test_inputs": [([1,3,-1,-3,5,3,6,7], 3), ([1], 1)],
                "expected_outputs": [[3,3,5,5,6,7], [1]]
            },
            {
                "query": "Create a Trie data structure with insert, search, and prefix matching",
                "type": "complex_algorithm",
                "difficulty": "medium",
                "category": "advanced_data_structures", 
                "expected_patterns": ["TrieNode", "children", "is_end", "prefix"],
                "test_description": "trie implementation"
            },
            {
                "query": "def regex_match(text, pattern): # Implement regex matching with . and * support",
                "type": "complex_algorithm",
                "difficulty": "hard",
                "category": "string_algorithms",
                "expected_patterns": ["regex", "match", "pattern", "recursive"],
                "test_inputs": [("aa", "a"), ("aa", "a*"), ("ab", ".*")],
                "expected_outputs": [False, True, True]
            },
            {
                "query": "Implement LRU Cache with O(1) get and put operations",
                "type": "complex_algorithm",
                "difficulty": "hard", 
                "category": "advanced_data_structures",
                "expected_patterns": ["LRU", "cache", "OrderedDict", "capacity"],
                "test_description": "efficient caching"
            }
        ]
    
    def test_single_code_problem(self, problem: dict) -> dict:
        """Test a single code problem against the server"""
        start_time = time.time()
        
        try:
            response = requests.post(
                self.server_url,
                json={"query": problem["query"]},
                timeout=30  # Longer timeout for code generation
            )
            
            if response.status_code == 200:
                result = response.json()
                text = result.get("text", "")
                method = result.get("method", "unknown")
                
                # Extract code from response
                extracted_code = self.extract_code_from_response(text)
                
                # Analyze code quality
                code_analysis = self.analyze_code_quality(extracted_code, problem)
                
                # Check for expected patterns
                has_patterns = self.check_expected_patterns(extracted_code, problem.get("expected_patterns", []))
                
                # Test compilation
                compile_result = self.test_code_compilation(extracted_code)
                
                # Run functional tests if available
                functional_result = self.run_functional_tests(extracted_code, problem)
                
                # Check for code complexity indicators
                uses_advanced_method = any(method_type in method for method_type in [
                    "deepseek", "coder", "two_pass", "compile_retry"
                ])
                
                success = (
                    result.get("success", False) and
                    compile_result["syntax_valid"] and
                    has_patterns and
                    len(extracted_code.strip()) > 20  # Non-trivial code
                )
                
                return {
                    "query": problem["query"],
                    "type": problem["type"],
                    "category": problem["category"],
                    "difficulty": problem["difficulty"],
                    "response": result,
                    "extracted_code": extracted_code,
                    "code_analysis": code_analysis,
                    "has_expected_patterns": has_patterns,
                    "compile_result": compile_result,
                    "functional_result": functional_result,
                    "uses_advanced_method": uses_advanced_method,
                    "success": success,
                    "latency_ms": result.get("latency_ms", 0),
                    "total_time_ms": (time.time() - start_time) * 1000,
                    "method": method,
                    "confidence": result.get("confidence", 0.0)
                }
            else:
                return self.create_error_result(problem, f"HTTP {response.status_code}", start_time)
                
        except Exception as e:
            return self.create_error_result(problem, str(e), start_time)
    
    def extract_code_from_response(self, text: str) -> str:
        """Extract code from server response"""
        
        # Look for code blocks
        code_patterns = [
            r'```python\n(.*?)\n```',
            r'```\n(.*?)\n```',
            r'URGENT CODE RESULT:\n(.*?)(?:\n\n|\Z)',
            r'DEEPSEEK CODE RESULT:\n(.*?)(?:\n\n|\Z)',
            r'def\s+\w+[^:]*:.*?(?=\n\n|\Z)',
        ]
        
        for pattern in code_patterns:
            try:
                match = re.search(pattern, text, re.DOTALL)
                if match:
                    if match.groups():
                        return match.group(1).strip()
                    else:
                        return match.group(0).strip()
            except Exception as e:
                print(f"   Warning: Pattern failed: {e}")
                continue
        
        # If no explicit code block, try to extract function definitions
        lines = text.split('\n')
        code_lines = []
        in_code = False
        
        for line in lines:
            if line.strip().startswith('def ') or line.strip().startswith('class '):
                in_code = True
            
            if in_code:
                code_lines.append(line)
                
                # Stop at empty line after code
                if not line.strip() and code_lines:
                    break
        
        if code_lines:
            return '\n'.join(code_lines).strip()
        
        # Fallback: return the whole text if it looks like code
        if 'def ' in text or 'return ' in text:
            return text.strip()
        
        return ""
    
    def analyze_code_quality(self, code: str, problem: dict) -> dict:
        """Analyze code quality metrics"""
        
        if not code:
            return {"error": "No code found"}
        
        try:
            # Parse AST for analysis
            tree = ast.parse(code)
            
            # Count various code elements
            functions = len([node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)])
            classes = len([node for node in ast.walk(tree) if isinstance(node, ast.ClassDef)])
            loops = len([node for node in ast.walk(tree) if isinstance(node, (ast.For, ast.While))])
            conditionals = len([node for node in ast.walk(tree) if isinstance(node, ast.If)])
            returns = len([node for node in ast.walk(tree) if isinstance(node, ast.Return)])
            
            # Calculate complexity score
            complexity_score = functions + classes * 2 + loops + conditionals + returns * 0.5
            
            # Check for dynamic programming patterns
            has_dp_pattern = any(pattern in code.lower() for pattern in [
                'dp[', 'memo[', 'cache[', 'table[', 'dynamic'
            ])
            
            # Check for algorithm patterns
            has_algorithm_pattern = any(pattern in code.lower() for pattern in [
                'sort', 'search', 'traverse', 'visit', 'merge', 'partition'
            ])
            
            # Line count and documentation
            lines = [line for line in code.split('\n') if line.strip()]
            line_count = len(lines)
            has_docstring = '"""' in code or "'''" in code
            has_comments = any(line.strip().startswith('#') for line in lines)
            
            return {
                "syntax_valid": True,
                "functions": functions,
                "classes": classes,
                "loops": loops,
                "conditionals": conditionals,
                "returns": returns,
                "complexity_score": complexity_score,
                "has_dp_pattern": has_dp_pattern,
                "has_algorithm_pattern": has_algorithm_pattern,
                "line_count": line_count,
                "has_docstring": has_docstring,
                "has_comments": has_comments,
                "quality_score": self.calculate_quality_score(complexity_score, line_count, has_dp_pattern, has_algorithm_pattern)
            }
            
        except SyntaxError as e:
            return {"error": f"Syntax error: {e}", "syntax_valid": False}
        except Exception as e:
            return {"error": f"Analysis error: {e}", "syntax_valid": False}
    
    def calculate_quality_score(self, complexity: float, lines: int, has_dp: bool, has_algo: bool) -> float:
        """Calculate overall code quality score"""
        
        score = 0.0
        
        # Complexity bonus (up to 30 points)
        score += min(30, complexity * 3)
        
        # Line count bonus (up to 20 points)
        score += min(20, lines * 0.5)
        
        # Pattern bonuses
        if has_dp:
            score += 25  # DP pattern bonus
        if has_algo:
            score += 25  # Algorithm pattern bonus
        
        return min(100, score)
    
    def check_expected_patterns(self, code: str, patterns: List[str]) -> bool:
        """Check if code contains expected patterns"""
        
        if not patterns:
            return True
        
        code_lower = code.lower()
        found_patterns = sum(1 for pattern in patterns if pattern.lower() in code_lower)
        
        # Require at least 60% of patterns to be present
        return found_patterns >= len(patterns) * 0.6
    
    def test_code_compilation(self, code: str) -> dict:
        """Test if code compiles successfully"""
        
        if not code:
            return {"syntax_valid": False, "error": "No code provided"}
        
        try:
            # Test syntax by parsing
            ast.parse(code)
            
            # Test execution in a safe environment
            exec_result = self.safe_code_execution(code)
            
            return {
                "syntax_valid": True,
                "execution_result": exec_result,
                "compilable": True
            }
            
        except SyntaxError as e:
            return {
                "syntax_valid": False,
                "error": str(e),
                "compilable": False
            }
        except Exception as e:
            return {
                "syntax_valid": True,
                "error": str(e),
                "compilable": False
            }
    
    def safe_code_execution(self, code: str) -> dict:
        """Safely execute code with timeout"""
        
        try:
            # Create temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(code)
                temp_file = f.name
            
            # Execute with timeout
            result = subprocess.run(
                [sys.executable, "-c", f"exec(open('{temp_file}').read())"],
                capture_output=True,
                text=True,
                timeout=3
            )
            
            # Clean up
            os.unlink(temp_file)
            
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode
            }
            
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "Execution timeout"}
        except Exception as e:
            return {"success": False, "error": f"Execution error: {e}"}
    
    def run_functional_tests(self, code: str, problem: dict) -> dict:
        """Run functional tests if test cases are provided"""
        
        test_inputs = problem.get("test_inputs", [])
        expected_outputs = problem.get("expected_outputs", [])
        
        if not test_inputs or not expected_outputs:
            return {"skipped": "No test cases provided"}
        
        try:
            # Extract function name from code
            func_match = re.search(r'def\s+(\w+)\s*\(', code)
            if not func_match:
                return {"error": "No function found in code"}
            
            func_name = func_match.group(1)
            
            # Execute code and test function
            local_namespace = {}
            exec(code, local_namespace)
            
            if func_name not in local_namespace:
                return {"error": f"Function {func_name} not found after execution"}
            
            func = local_namespace[func_name]
            test_results = []
            
            for i, (test_input, expected) in enumerate(zip(test_inputs, expected_outputs)):
                try:
                    if isinstance(test_input, (list, tuple)) and len(test_input) > 1:
                        # Multiple arguments
                        result = func(*test_input)
                    else:
                        # Single argument
                        result = func(test_input)
                    
                    passed = result == expected
                    test_results.append({
                        "test_case": i,
                        "input": test_input,
                        "expected": expected,
                        "actual": result,
                        "passed": passed
                    })
                    
                except Exception as e:
                    test_results.append({
                        "test_case": i,
                        "input": test_input,
                        "expected": expected,
                        "error": str(e),
                        "passed": False
                    })
            
            passed_tests = sum(1 for test in test_results if test.get("passed", False))
            total_tests = len(test_results)
            
            return {
                "total_tests": total_tests,
                "passed_tests": passed_tests,
                "success_rate": passed_tests / total_tests if total_tests > 0 else 0,
                "test_results": test_results
            }
            
        except Exception as e:
            return {"error": f"Functional test error: {e}"}
    
    def create_error_result(self, problem: dict, error: str, start_time: float) -> dict:
        """Create standardized error result"""
        return {
            "query": problem["query"],
            "type": problem["type"],
            "category": problem["category"],
            "difficulty": problem["difficulty"],
            "response": {"error": error},
            "extracted_code": "",
            "code_analysis": {"error": error},
            "has_expected_patterns": False,
            "compile_result": {"syntax_valid": False, "error": error},
            "functional_result": {"error": error},
            "uses_advanced_method": False,
            "success": False,
            "latency_ms": 0,
            "total_time_ms": (time.time() - start_time) * 1000,
            "method": "error",
            "confidence": 0.0
        }
    
    def run_code_complexity_test(self) -> dict:
        """Run the complete code complexity test"""
        print("🔥💀⚔️ CODE COMPLEXITY TEST - SPRINT S-4 ⚔️💀🔥")
        print("=" * 60)
        
        start_time = time.time()
        results = []
        
        for i, problem in enumerate(self.test_problems):
            print(f"\n📝 Test {i+1}/20: {problem['category'].upper()}")
            print(f"    Type: {problem['type']}, Difficulty: {problem['difficulty']}")
            print(f"    Query: {problem['query'][:80]}...")
            
            result = self.test_single_code_problem(problem)
            results.append(result)
            
            # Show immediate feedback
            status = "✅ PASS" if result["success"] else "❌ FAIL"
            method = result.get('method', 'unknown')
            advanced_indicator = "🧠" if result.get('uses_advanced_method', False) else "🤖"
            
            print(f"    {status} {advanced_indicator}: Method: {method}")
            
            if result.get('code_analysis', {}).get('syntax_valid', False):
                quality = result['code_analysis'].get('quality_score', 0)
                complexity = result['code_analysis'].get('complexity_score', 0)
                print(f"    Quality: {quality:.1f}/100, Complexity: {complexity:.1f}")
            
            if result.get('compile_result', {}).get('syntax_valid', False):
                print(f"    ✅ Compilation: SUCCESS")
            else:
                error = result.get('compile_result', {}).get('error', 'Unknown')[:50]
                print(f"    ❌ Compilation: {error}...")
            
            if result.get('functional_result', {}).get('success_rate'):
                success_rate = result['functional_result']['success_rate']
                print(f"    🧪 Functional Tests: {success_rate:.1%}")
        
        # Calculate comprehensive statistics
        total_time = time.time() - start_time
        passed = sum(1 for r in results if r["success"])
        accuracy = passed / len(results)
        avg_latency = sum(r["latency_ms"] for r in results) / len(results)
        avg_confidence = sum(r["confidence"] for r in results) / len(results)
        
        # Advanced method usage
        advanced_method_usage = sum(1 for r in results if r.get("uses_advanced_method", False))
        advanced_usage_rate = advanced_method_usage / len(results)
        
        # Compilation success rate
        compilation_success = sum(1 for r in results if r.get("compile_result", {}).get("syntax_valid", False))
        compilation_rate = compilation_success / len(results)
        
        # Code quality metrics
        quality_scores = [r.get("code_analysis", {}).get("quality_score", 0) for r in results if r.get("code_analysis", {}).get("syntax_valid", False)]
        avg_quality = sum(quality_scores) / len(quality_scores) if quality_scores else 0
        
        # Break down by type, category, and difficulty
        type_stats = self.calculate_breakdown_stats(results, "type")
        category_stats = self.calculate_breakdown_stats(results, "category")
        difficulty_stats = self.calculate_breakdown_stats(results, "difficulty")
        method_stats = self.calculate_breakdown_stats(results, "method")
        
        print(f"\n🔥💀⚔️ CODE COMPLEXITY RESULTS - SPRINT S-4 ⚔️💀🔥")
        print("=" * 60)
        print(f"⚡ OVERALL ACCURACY: {accuracy:.1%} ({passed}/{len(results)})")
        print(f"⚡ AVERAGE LATENCY: {avg_latency:.1f}ms")
        print(f"⚡ AVERAGE CONFIDENCE: {avg_confidence:.2f}")
        print(f"⚡ COMPILATION SUCCESS: {compilation_rate:.1%} ({compilation_success}/{len(results)})")
        print(f"⚡ TOTAL TEST TIME: {total_time:.1f}s")
        print(f"🧠 ADVANCED METHOD USAGE: {advanced_usage_rate:.1%} ({advanced_method_usage}/{len(results)})")
        print(f"📊 AVERAGE CODE QUALITY: {avg_quality:.1f}/100")
        print()
        
        print("📊 BREAKDOWN BY TYPE:")
        for type_name, stats in type_stats.items():
            type_accuracy = stats["passed"] / stats["total"]
            print(f"   {type_name}: {type_accuracy:.1%} ({stats['passed']}/{stats['total']})")
        print()
        
        print("📊 BREAKDOWN BY CATEGORY:")
        for category, stats in category_stats.items():
            cat_accuracy = stats["passed"] / stats["total"]
            print(f"   {category}: {cat_accuracy:.1%} ({stats['passed']}/{stats['total']})")
        print()
        
        print("📊 BREAKDOWN BY DIFFICULTY:")
        for difficulty, stats in sorted(difficulty_stats.items()):
            diff_accuracy = stats["passed"] / stats["total"]
            print(f"   {difficulty}: {diff_accuracy:.1%} ({stats['passed']}/{stats['total']})")
        print()
        
        print("🔬 BREAKDOWN BY METHOD:")
        for method, stats in method_stats.items():
            method_accuracy = stats["passed"] / stats["total"]
            print(f"   {method}: {method_accuracy:.1%} ({stats['passed']}/{stats['total']})")
        
        return {
            "overall_accuracy": accuracy,
            "total_passed": passed,
            "total_problems": len(results),
            "avg_latency_ms": avg_latency,
            "avg_confidence": avg_confidence,
            "compilation_success_rate": compilation_rate,
            "compilation_success_count": compilation_success,
            "total_time_s": total_time,
            "advanced_method_usage_rate": advanced_usage_rate,
            "advanced_method_count": advanced_method_usage,
            "avg_code_quality": avg_quality,
            "type_breakdown": type_stats,
            "category_breakdown": category_stats,
            "difficulty_breakdown": difficulty_stats,
            "method_breakdown": method_stats,
            "detailed_results": results
        }
    
    def calculate_breakdown_stats(self, results: List[dict], field: str) -> dict:
        """Calculate breakdown statistics for a given field"""
        stats = {}
        
        for result in results:
            value = result.get(field, "unknown")
            if value not in stats:
                stats[value] = {"total": 0, "passed": 0}
            stats[value]["total"] += 1
            if result["success"]:
                stats[value]["passed"] += 1
        
        return stats

def main():
    """Run code complexity test"""
    tester = CodeComplexityTest()
    results = tester.run_code_complexity_test()
    
    # Save results
    with open("code_complexity_results.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\n💾 Results saved to code_complexity_results.json")
    
    # Sprint S-4 success criteria
    target_accuracy = 0.80  # 80% target for complex code problems
    target_latency = 5000.0  # <5s target for code generation
    target_compilation = 0.90  # 90% compilation success (key metric)
    target_advanced_usage = 0.70  # 70% should use advanced methods
    
    print(f"\n🎯 SPRINT S-4 SUCCESS CRITERIA:")
    
    if results["overall_accuracy"] >= target_accuracy:
        print(f"✅ ACCURACY TARGET MET: {results['overall_accuracy']:.1%} >= {target_accuracy:.1%}")
    else:
        print(f"🚨 ACCURACY TARGET MISSED: {results['overall_accuracy']:.1%} < {target_accuracy:.1%}")
    
    if results["avg_latency_ms"] <= target_latency:
        print(f"✅ LATENCY TARGET MET: {results['avg_latency_ms']:.1f}ms <= {target_latency}ms")
    else:
        print(f"🚨 LATENCY TARGET MISSED: {results['avg_latency_ms']:.1f}ms > {target_latency}ms")
    
    if results["compilation_success_rate"] >= target_compilation:
        print(f"✅ COMPILATION TARGET MET: {results['compilation_success_rate']:.1%} >= {target_compilation:.1%}")
    else:
        print(f"🚨 COMPILATION TARGET MISSED: {results['compilation_success_rate']:.1%} < {target_compilation:.1%}")
    
    if results["advanced_method_usage_rate"] >= target_advanced_usage:
        print(f"✅ ADVANCED METHOD TARGET MET: {results['advanced_method_usage_rate']:.1%} >= {target_advanced_usage:.1%}")
    else:
        print(f"🚨 ADVANCED METHOD TARGET MISSED: {results['advanced_method_usage_rate']:.1%} < {target_advanced_usage:.1%}")
    
    # Overall Sprint S-4 assessment
    targets_met = sum([
        results["overall_accuracy"] >= target_accuracy,
        results["avg_latency_ms"] <= target_latency,
        results["compilation_success_rate"] >= target_compilation,
        results["advanced_method_usage_rate"] >= target_advanced_usage
    ])
    
    if targets_met >= 3:
        print(f"\n🎉 SPRINT S-4 SUCCESS: {targets_met}/4 targets met!")
        print(f"🚀 Expected +20pp HumanEval gain achieved!")
    else:
        print(f"\n⚠️ SPRINT S-4 PARTIAL: {targets_met}/4 targets met")

if __name__ == "__main__":
    main() 