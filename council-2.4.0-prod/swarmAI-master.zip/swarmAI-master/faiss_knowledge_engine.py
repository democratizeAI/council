#!/usr/bin/env python3
"""
🔥💀⚔️ FAISS KNOWLEDGE ENGINE - SPRINT S-3 ⚔️💀🔥
==================================================
MISSION: Knowledge-Depth Gap solution via FAISS
TARGET: Wiki500k + Ten Thousand QA Facts (≈800MB INT8)
STRATEGY: Dense retrieval for causal chains & "why did" questions
"""

import os
import json
import time
import numpy as np
from typing import Dict, Any, List, Optional, Tuple
import hashlib
import pickle

# FAISS imports with fallback
try:
    import faiss
    FAISS_AVAILABLE = True
except ImportError:
    FAISS_AVAILABLE = False
    print("⚠️ FAISS not available - install with: pip install faiss-cpu")

# Sentence transformer for embeddings
try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False
    print("⚠️ sentence-transformers not available - install with: pip install sentence-transformers")

class FAISSKnowledgeEngine:
    """FAISS-based knowledge retrieval engine for causal reasoning"""
    
    def __init__(self, 
                 model_name: str = "all-MiniLM-L6-v2",
                 index_path: str = "knowledge_index",
                 knowledge_db_path: str = "knowledge_db.pkl"):
        
        self.model_name = model_name
        self.index_path = index_path
        self.knowledge_db_path = knowledge_db_path
        
        # Initialize components
        self.encoder = None
        self.index = None
        self.knowledge_db = []
        self.embedding_dim = 384  # Default for all-MiniLM-L6-v2
        
        # Initialize if dependencies available
        if SENTENCE_TRANSFORMERS_AVAILABLE:
            print(f"🧠 Loading sentence transformer: {model_name}")
            self.encoder = SentenceTransformer(model_name)
            self.embedding_dim = self.encoder.get_sentence_embedding_dimension()
        
        # Load existing index if available
        self.load_index()
    
    def create_sample_knowledge_base(self) -> List[Dict[str, Any]]:
        """Create sample knowledge base for Sprint S-3 demonstration"""
        
        knowledge_facts = [
            # Causal chain examples
            {
                "id": "causal_001",
                "question": "Why did the Roman Empire fall?",
                "answer": "The Roman Empire fell due to a combination of factors: economic decline from debasement of currency, military pressure from barbarian invasions, political instability with frequent civil wars, administrative challenges in governing vast territories, and the rise of Christianity changing social structures.",
                "type": "causal_chain",
                "entities": ["Roman Empire", "economy", "barbarians", "politics", "Christianity"],
                "keywords": ["fall", "decline", "empire", "causes", "history"]
            },
            {
                "id": "causal_002", 
                "question": "Why did the 2008 financial crisis happen?",
                "answer": "The 2008 financial crisis was caused by: subprime mortgage lending to unqualified borrowers, securitization of risky mortgages into complex derivatives, excessive leverage by financial institutions, regulatory failures, and global interconnectedness that spread the crisis worldwide.",
                "type": "causal_chain",
                "entities": ["financial crisis", "mortgages", "derivatives", "banks", "regulation"],
                "keywords": ["crisis", "financial", "mortgage", "banking", "causes"]
            },
            {
                "id": "causal_003",
                "question": "Why do neural networks work so well for image recognition?",
                "answer": "Neural networks excel at image recognition because: convolutional layers detect local patterns and edges, pooling layers provide translation invariance, deep architectures learn hierarchical representations from simple to complex features, backpropagation enables end-to-end optimization, and large datasets provide sufficient examples for generalization.",
                "type": "technical_causal",
                "entities": ["neural networks", "convolution", "pooling", "backpropagation", "datasets"],
                "keywords": ["neural", "image", "recognition", "convolution", "deep learning"]
            },
            
            # Historical facts
            {
                "id": "hist_001",
                "question": "When was the Transformer architecture introduced?",
                "answer": "The Transformer architecture was introduced in 2017 by Vaswani et al. in the paper 'Attention Is All You Need', revolutionizing natural language processing by replacing recurrent networks with self-attention mechanisms.",
                "type": "historical_fact",
                "entities": ["Transformer", "Vaswani", "attention", "2017", "NLP"],
                "keywords": ["transformer", "attention", "2017", "vaswani", "nlp"]
            },
            {
                "id": "hist_002",
                "question": "Who invented the World Wide Web?",
                "answer": "Tim Berners-Lee invented the World Wide Web in 1989 while working at CERN. He created the first web browser, web server, and website, and developed the fundamental technologies: HTML, HTTP, and URLs.",
                "type": "historical_fact", 
                "entities": ["Tim Berners-Lee", "World Wide Web", "CERN", "1989", "HTML", "HTTP"],
                "keywords": ["web", "berners-lee", "cern", "internet", "html", "http"]
            },
            
            # Scientific explanations
            {
                "id": "sci_001",
                "question": "Why is the sky blue?",
                "answer": "The sky appears blue due to Rayleigh scattering. As sunlight enters Earth's atmosphere, it collides with gas molecules. Blue light has a shorter wavelength than other colors, causing it to scatter more in all directions, making the sky appear blue to our eyes.",
                "type": "scientific_explanation",
                "entities": ["Rayleigh scattering", "wavelength", "atmosphere", "sunlight", "molecules"],
                "keywords": ["sky", "blue", "scattering", "wavelength", "atmosphere"]
            },
            {
                "id": "sci_002",
                "question": "Why do objects fall to Earth?",
                "answer": "Objects fall to Earth due to gravity, a fundamental force described by Einstein's General Relativity. Mass curves spacetime, and objects follow the straightest possible path through this curved spacetime, which appears as acceleration toward massive objects like Earth.",
                "type": "scientific_explanation", 
                "entities": ["gravity", "Einstein", "General Relativity", "spacetime", "mass"],
                "keywords": ["gravity", "fall", "einstein", "relativity", "mass", "spacetime"]
            },
            
            # Technical Q&A
            {
                "id": "tech_001",
                "question": "Why use Docker containers?",
                "answer": "Docker containers provide: consistent environments across development/production, isolation between applications, efficient resource usage compared to VMs, easy scaling and deployment, and simplified dependency management through containerized packaging.",
                "type": "technical_explanation",
                "entities": ["Docker", "containers", "deployment", "isolation", "scaling"],
                "keywords": ["docker", "containers", "deployment", "isolation", "devops"]
            },
            {
                "id": "tech_002",
                "question": "Why is HTTPS important?",
                "answer": "HTTPS is crucial because it: encrypts data transmission preventing eavesdropping, authenticates server identity preventing man-in-the-middle attacks, ensures data integrity preventing tampering, and is required for modern web features like service workers and payment APIs.",
                "type": "technical_explanation",
                "entities": ["HTTPS", "encryption", "authentication", "security", "SSL/TLS"],
                "keywords": ["https", "security", "encryption", "ssl", "authentication"]
            },
            
            # Programming concepts
            {
                "id": "prog_001", 
                "question": "Why use functional programming?",
                "answer": "Functional programming offers: immutable data structures reducing bugs, pure functions enabling easier testing and reasoning, composability for building complex systems from simple parts, and natural parallelization due to lack of shared state.",
                "type": "programming_concept",
                "entities": ["functional programming", "immutability", "pure functions", "composability"],
                "keywords": ["functional", "programming", "immutable", "pure", "functions"]
            },
            {
                "id": "prog_002",
                "question": "Why use version control?",
                "answer": "Version control systems provide: complete history of code changes, ability to revert to previous versions, branching for parallel development, collaboration mechanisms for teams, and backup/recovery capabilities for code repositories.",
                "type": "programming_concept",
                "entities": ["version control", "Git", "branching", "collaboration", "history"],
                "keywords": ["version", "control", "git", "history", "collaboration"]
            }
        ]
        
        return knowledge_facts
    
    def build_index(self, knowledge_facts: List[Dict[str, Any]] = None) -> bool:
        """Build FAISS index from knowledge facts"""
        
        if not FAISS_AVAILABLE or not SENTENCE_TRANSFORMERS_AVAILABLE:
            print("❌ Cannot build index - missing dependencies")
            return False
        
        if knowledge_facts is None:
            knowledge_facts = self.create_sample_knowledge_base()
        
        print(f"🔥 Building FAISS index with {len(knowledge_facts)} knowledge facts...")
        start_time = time.time()
        
        # Prepare texts for embedding
        texts = []
        for fact in knowledge_facts:
            # Combine question and answer for richer embeddings
            combined_text = f"{fact['question']} {fact['answer']}"
            texts.append(combined_text)
        
        # Generate embeddings
        print("🧠 Generating embeddings...")
        embeddings = self.encoder.encode(texts, convert_to_tensor=False, show_progress_bar=True)
        embeddings = np.array(embeddings).astype(np.float32)
        
        # Create FAISS index with INT8 quantization for 800MB target
        print("🗂️ Creating quantized FAISS index...")
        
        # For small datasets, use flat index; for larger ones use quantized index
        if len(embeddings) < 1000:
            print("📊 Using flat index for small dataset...")
            self.index = faiss.IndexFlatL2(self.embedding_dim)
        else:
            # Use IVF with PQ for compression only with larger datasets
            quantizer = faiss.IndexFlatL2(self.embedding_dim)
            nlist = min(100, len(knowledge_facts) // 10)  # Number of clusters
            m = 8  # Number of sub-quantizers for PQ
            nbits = 8  # 8 bits per sub-quantizer (INT8)
            
            self.index = faiss.IndexIVFPQ(quantizer, self.embedding_dim, nlist, m, nbits)
            
            # Train the index
            if len(embeddings) >= nlist * 39:  # FAISS requirement: at least 39 points per cluster
                print("🏋️ Training FAISS index...")
                self.index.train(embeddings)
            else:
                # Fallback to flat index for insufficient training data
                print("📊 Insufficient data for clustering - using flat index...")
                self.index = faiss.IndexFlatL2(self.embedding_dim)
        
        # Add embeddings to index
        self.index.add(embeddings)
        
        # Store knowledge database
        self.knowledge_db = knowledge_facts
        
        # Save to disk
        self.save_index()
        
        build_time = time.time() - start_time
        index_size = self.get_index_size_mb()
        
        print(f"✅ FAISS index built successfully!")
        print(f"   📊 {len(knowledge_facts)} facts indexed")
        print(f"   ⚡ Build time: {build_time:.2f}s")
        print(f"   💾 Index size: {index_size:.1f}MB")
        print(f"   🎯 Target: 800MB (headroom: {800-index_size:.1f}MB)")
        
        return True
    
    def get_index_size_mb(self) -> float:
        """Estimate FAISS index size in MB"""
        if self.index is None:
            return 0.0
        
        # Rough estimate: embeddings + overhead
        num_vectors = self.index.ntotal
        bytes_per_vector = self.embedding_dim * 4  # float32
        
        if hasattr(self.index, 'pq'):
            # Compressed index - much smaller
            bytes_per_vector = self.index.pq.M * self.index.pq.nbits // 8
        
        total_bytes = num_vectors * bytes_per_vector
        return total_bytes / (1024 * 1024)
    
    def save_index(self) -> bool:
        """Save FAISS index and knowledge database to disk"""
        try:
            if self.index is not None and FAISS_AVAILABLE:
                faiss.write_index(self.index, f"{self.index_path}.faiss")
            
            with open(self.knowledge_db_path, 'wb') as f:
                pickle.dump(self.knowledge_db, f)
            
            print(f"💾 Knowledge index saved to {self.index_path}.faiss")
            return True
            
        except Exception as e:
            print(f"❌ Failed to save index: {e}")
            return False
    
    def load_index(self) -> bool:
        """Load FAISS index and knowledge database from disk"""
        try:
            if os.path.exists(f"{self.index_path}.faiss") and FAISS_AVAILABLE:
                self.index = faiss.read_index(f"{self.index_path}.faiss")
                print(f"✅ FAISS index loaded from {self.index_path}.faiss")
            
            if os.path.exists(self.knowledge_db_path):
                with open(self.knowledge_db_path, 'rb') as f:
                    self.knowledge_db = pickle.load(f)
                print(f"✅ Knowledge database loaded ({len(self.knowledge_db)} facts)")
            
            return True
            
        except Exception as e:
            print(f"⚠️ Failed to load index: {e}")
            return False
    
    def search_knowledge(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        """Search knowledge base for relevant facts"""
        
        if not FAISS_AVAILABLE or not SENTENCE_TRANSFORMERS_AVAILABLE:
            return []
        
        if self.index is None or len(self.knowledge_db) == 0:
            # Try to build index if not available
            if not self.build_index():
                return []
        
        try:
            # Generate query embedding
            query_embedding = self.encoder.encode([query], convert_to_tensor=False)
            query_embedding = np.array(query_embedding).astype(np.float32)
            
            # Search FAISS index
            scores, indices = self.index.search(query_embedding, k)
            
            # Retrieve matching facts
            results = []
            for i, (score, idx) in enumerate(zip(scores[0], indices[0])):
                if idx < len(self.knowledge_db):
                    fact = self.knowledge_db[idx].copy()
                    fact['similarity_score'] = float(score)
                    fact['rank'] = i + 1
                    results.append(fact)
            
            return results
            
        except Exception as e:
            print(f"❌ Knowledge search failed: {e}")
            return []
    
    def answer_why_question(self, question: str) -> Dict[str, Any]:
        """Answer causal 'why' questions using knowledge retrieval"""
        start_time = time.time()
        
        # Search for relevant knowledge
        relevant_facts = self.search_knowledge(question, k=3)
        
        if not relevant_facts:
            return {
                "success": False,
                "text": f"No knowledge found for: {question}",
                "confidence": 0.0,
                "method": "knowledge_search_failed",
                "latency_ms": (time.time() - start_time) * 1000
            }
        
        # Find best matching fact
        best_fact = relevant_facts[0]
        
        # Check if it's a causal question
        is_causal = any(word in question.lower() for word in ["why", "how", "what caused", "reason", "because"])
        
        if is_causal and best_fact.get('type', '').endswith('causal') or best_fact.get('type') == 'causal_chain':
            confidence = 0.95
            method = "causal_knowledge_retrieval"
        elif is_causal:
            confidence = 0.85
            method = "general_knowledge_retrieval" 
        else:
            confidence = 0.75
            method = "factual_knowledge_retrieval"
        
        # Format response
        answer = best_fact['answer']
        if len(relevant_facts) > 1:
            # Add context from additional facts
            additional_context = " ".join([f["answer"][:100] + "..." for f in relevant_facts[1:]])
            answer = f"{answer} Additional context: {additional_context}"
        
        return {
            "success": True,
            "text": f"KNOWLEDGE RESULT: {answer}",
            "confidence": confidence,
            "method": method,
            "latency_ms": (time.time() - start_time) * 1000,
            "sources": [f["id"] for f in relevant_facts[:3]],
            "knowledge_type": best_fact.get('type', 'unknown'),
            "similarity_score": best_fact.get('similarity_score', 0.0)
        }

# Global knowledge engine instance
knowledge_engine = FAISSKnowledgeEngine()

def faiss_knowledge_solve(question: str) -> Dict[str, Any]:
    """Global function for FAISS knowledge solving"""
    return knowledge_engine.answer_why_question(question)

if __name__ == "__main__":
    # Test the FAISS knowledge engine
    print("🔥💀⚔️ FAISS KNOWLEDGE ENGINE TEST - SPRINT S-3 ⚔️💀🔥")
    
    # Initialize and build index
    engine = FAISSKnowledgeEngine()
    
    if not engine.build_index():
        print("❌ Failed to build knowledge index")
        exit(1)
    
    # Test queries
    test_queries = [
        "Why did the Roman Empire fall?",
        "Why do neural networks work well for images?",
        "Why is the sky blue?",
        "Why use Docker containers?",
        "What caused the 2008 financial crisis?",
        "Why is HTTPS important?",
        "How does gravity work?",
        "Why use functional programming?"
    ]
    
    print(f"\n🧪 Testing {len(test_queries)} knowledge queries...")
    
    for query in test_queries:
        print(f"\n📝 Query: {query}")
        result = engine.answer_why_question(query)
        
        if result['success']:
            print(f"✅ Answer: {result['text'][:100]}...")
            print(f"   Confidence: {result['confidence']:.2f}")
            print(f"   Method: {result['method']}")
            print(f"   Latency: {result['latency_ms']:.1f}ms")
        else:
            print(f"❌ Failed: {result['text']}") 