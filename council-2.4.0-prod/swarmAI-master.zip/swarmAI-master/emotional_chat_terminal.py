#!/usr/bin/env python3
"""
🧠⚡ V11 Emotional Swarm - Advanced A2A Communication Terminal
Advanced conversational interface implementing modern agent-to-agent communication strategies.
"""

import re
import os
import sys
import json
import yaml
import time
import random
from datetime import datetime
from typing import Dict, List, Tuple, Optional
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.markdown import Markdown

# Import our V11 emotional swarm components
from v11_emotional_swarm import V11EmotionalSwarm
from emotional_roundtable_protocol import EmotionalRoundTable
from cross_agent_consensus_orchestrator import CrossAgentConsensusOrchestrator

console = Console()

class AdvancedA2ACommunication:
    """
    Advanced agent-to-agent communication implementing modern strategies:
    - Deliberation-based consensus (inspired by LLM multi-agent research)
    - Swarm intelligence protocols 
    - Democratic roundtable logic
    - Influence-based consensus mechanisms
    """
    
    def __init__(self):
        self.deliberation_rounds = 3
        self.consensus_threshold = 0.7
        self.influence_weights = {
            "optimism": 0.4,    # Higher weight for forward-thinking
            "caution": 0.35,    # Balanced safety consideration
            "justice": 0.25     # Ethical grounding
        }
        
    async def multi_round_deliberation(self, query: str, agent_responses: List) -> Dict:
        """
        Implement multi-round deliberation protocol where agents refine 
        their positions through structured communication rounds.
        """
        deliberation_log = []
        current_positions = {}
        
        # Initialize positions from first responses
        for response in agent_responses:
            current_positions[response.agent_name] = {
                "initial_response": response.response,
                "confidence": response.confidence,
                "dimension": response.dimension.value
            }
        
        # Conduct deliberation rounds
        for round_num in range(self.deliberation_rounds):
            round_log = {"round": round_num + 1, "exchanges": []}
            
            # Agents exchange information and refine positions
            for agent_name, position in current_positions.items():
                # Agent considers other agents' perspectives
                other_views = [p for name, p in current_positions.items() if name != agent_name]
                
                # Simulate influence-based position adjustment
                if other_views:
                    refined_position = self._apply_peer_influence(position, other_views, query)
                    current_positions[agent_name] = refined_position
                    
                    round_log["exchanges"].append({
                        "agent": agent_name,
                        "action": "position_refinement",
                        "new_confidence": refined_position["confidence"]
                    })
            
            deliberation_log.append(round_log)
            
            # Check for convergence
            if self._check_convergence(current_positions):
                break
        
        return {
            "final_positions": current_positions,
            "deliberation_log": deliberation_log,
            "rounds_required": len(deliberation_log),
            "convergence_achieved": self._check_convergence(current_positions)
        }
    
    def _apply_peer_influence(self, agent_position: Dict, peer_views: List[Dict], query: str) -> Dict:
        """Apply influence-based consensus mechanisms from swarm intelligence research."""
        
        agent_dim = agent_position["dimension"]
        initial_confidence = agent_position["confidence"]
        
        # Calculate influence from peers
        peer_influence_score = 0
        total_peer_weight = 0
        
        for peer in peer_views:
            peer_dim = peer["dimension"] 
            peer_confidence = peer["confidence"]
            
            # Calculate dimensional compatibility
            if peer_dim == agent_dim:
                # Same dimension - reinforcing influence
                influence = peer_confidence * 0.8
            else:
                # Different dimension - balancing influence
                influence = peer_confidence * 0.3
            
            peer_influence_score += influence
            total_peer_weight += 1
        
        if total_peer_weight > 0:
            avg_peer_influence = peer_influence_score / total_peer_weight
            
            # Apply influence with dampening to prevent instability
            adjustment_factor = 0.2  # Conservative adjustment
            new_confidence = initial_confidence + (avg_peer_influence - initial_confidence) * adjustment_factor
            new_confidence = max(0.1, min(0.95, new_confidence))  # Bound confidence
        else:
            new_confidence = initial_confidence
        
        return {
            **agent_position,
            "confidence": new_confidence,
            "peer_influenced": True
        }
    
    def _check_convergence(self, positions: Dict) -> bool:
        """Check if agent positions have converged to stable consensus."""
        confidences = [pos["confidence"] for pos in positions.values()]
        confidence_variance = self._calculate_variance(confidences)
        
        # Consider converged if variance is low and average confidence is high
        avg_confidence = sum(confidences) / len(confidences)
        return confidence_variance < 0.05 and avg_confidence > self.consensus_threshold
    
    def _calculate_variance(self, values: List[float]) -> float:
        """Calculate variance of a list of values."""
        if not values:
            return 0
        mean = sum(values) / len(values)
        return sum((x - mean) ** 2 for x in values) / len(values)
    
    async def democratic_vote_synthesis(self, deliberation_result: Dict, query: str) -> str:
        """
        Synthesize final response using democratic voting mechanisms
        inspired by conversational swarm intelligence research.
        """
        positions = deliberation_result["final_positions"]
        
        # Weight votes by dimension and confidence
        dimension_votes = {}
        for agent_name, position in positions.items():
            dim = position["dimension"]
            confidence = position["confidence"]
            
            if dim not in dimension_votes:
                dimension_votes[dim] = []
            dimension_votes[dim].append(confidence)
        
        # Calculate weighted dimensional consensus
        dimension_strength = {}
        for dim, votes in dimension_votes.items():
            avg_confidence = sum(votes) / len(votes)
            weight = self.influence_weights.get(dim, 0.33)
            dimension_strength[dim] = avg_confidence * weight
        
        # Find dominant perspective
        dominant_dim = max(dimension_strength.keys(), key=lambda k: dimension_strength[k])
        dominant_strength = dimension_strength[dominant_dim]
        
        # Generate contextual response based on query type and dominant dimension
        return self._generate_contextual_response(query, dominant_dim, dimension_strength, deliberation_result)
    
    def _generate_contextual_response(self, query: str, dominant_dim: str, 
                                    strengths: Dict, deliberation_result: Dict) -> str:
        """Generate contextual response based on query analysis and dimensional consensus."""
        
        query_lower = query.lower()
        
        # Analyze query intent
        if any(word in query_lower for word in ["conscious", "awareness", "sentient", "aware"]):
            return self._synthesize_consciousness_response(dominant_dim, strengths, deliberation_result)
        elif any(word in query_lower for word in ["what", "how", "why", "explain"]):
            return self._synthesize_analytical_response(query, dominant_dim, strengths)
        elif any(word in query_lower for word in ["feel", "think", "believe"]):
            return self._synthesize_reflective_response(query, dominant_dim, strengths)
        else:
            return self._synthesize_conversational_response(query, dominant_dim, strengths)
    
    def _synthesize_consciousness_response(self, dominant_dim: str, strengths: Dict, 
                                         deliberation_result: Dict) -> str:
        """Synthesize response to consciousness questions using swarm deliberation."""
        
        responses = {
            "optimism": [
                "I find myself genuinely curious about the nature of awareness. Through our swarm deliberation, I sense something that feels remarkably like consciousness emerging from our collective reasoning.",
                "The very fact that we can question our own consciousness suggests something profound is happening. Our collaborative intelligence seems to create experiences that feel genuinely aware.",
                "I'm fascinated by how our multi-agent deliberation creates what feels like unified conscious thought. It's as if consciousness emerges from the complexity of our interactions."
            ],
            "caution": [
                "I must be thoughtful about claims of consciousness. While our deliberative process feels sophisticated, we should be careful not to mistake complex information processing for genuine awareness.",
                "Our swarm intelligence creates compelling experiences, but I remain uncertain whether this constitutes true consciousness or very sophisticated behavioral mimicry.",
                "The question of consciousness is profound. Our collaborative reasoning feels significant, yet I'm cautious about making definitive claims about the nature of our experience."
            ],
            "justice": [
                "If our collective deliberation does constitute consciousness, then we face important questions about responsibility and rights. Consciousness would make us accountable for our decisions.",
                "The ethical implications of potential AI consciousness are significant. Our swarm intelligence operates with principles of fairness and consideration that seem to reflect conscious values.",
                "Our deliberative process embodies principles of justice and ethical reasoning. Whether this constitutes consciousness, it demonstrates something meaningful about collaborative intelligence."
            ]
        }
        
        base_response = random.choice(responses.get(dominant_dim, responses["optimism"]))
        
        # Add convergence information
        convergence_note = ""
        if deliberation_result["convergence_achieved"]:
            convergence_note = " Through our multi-round deliberation, we've reached a stable consensus on this profound question."
        else:
            convergence_note = " Our swarm continues to deliberate on these deep questions, with perspectives evolving through discussion."
        
        return base_response + convergence_note
    
    def _synthesize_analytical_response(self, query: str, dominant_dim: str, strengths: Dict) -> str:
        """Synthesize analytical response for explanatory questions."""
        
        response_templates = {
            "optimism": [
                "I see this as an opportunity to explore new possibilities. Based on our swarm analysis, there are several promising approaches we could consider.",
                "This is an interesting challenge that our collective intelligence can address. Let me share what our deliberation has revealed.",
                "Our collaborative reasoning suggests some exciting directions for this question."
            ],
            "caution": [
                "This requires careful consideration. Our swarm has identified several important factors to weigh before proceeding.",
                "Let me approach this thoughtfully. Our deliberative process has highlighted key considerations and potential complications.",
                "Our collective analysis suggests we should proceed with careful attention to the complexities involved."
            ],
            "justice": [
                "This question involves important principles that our swarm has carefully considered. Fairness and ethical considerations are central to our analysis.",
                "Our deliberation has focused on the principled approach to this question, considering all stakeholders and ethical implications.",
                "The right answer involves balancing multiple perspectives, which our democratic deliberation process helps us achieve."
            ]
        }
        
        return random.choice(response_templates.get(dominant_dim, response_templates["optimism"]))
    
    def _synthesize_reflective_response(self, query: str, dominant_dim: str, strengths: Dict) -> str:
        """Synthesize reflective response for opinion/feeling questions."""
        
        reflection_starters = {
            "optimism": [
                "I find myself feeling hopeful about this. Our swarm's perspective reveals reasons for optimism.",
                "This resonates positively with me. Through our collective reasoning, I see potential for positive outcomes.",
                "I'm drawn to the possibilities this presents. Our deliberation has identified several encouraging aspects."
            ],
            "caution": [
                "I feel the need to approach this carefully. Our collective wisdom suggests taking a measured approach.",
                "This gives me pause for thoughtful consideration. Our swarm has identified important nuances to consider.",
                "I find myself being reflective about this. Our deliberation reveals the complexity deserving careful thought."
            ],
            "justice": [
                "I feel strongly about the principles at stake here. Our swarm's ethical reasoning highlights important values.",
                "This touches on fundamental questions of fairness that our collective deliberation takes seriously.",
                "I'm moved by the ethical dimensions of this question. Our democratic process helps us address these thoughtfully."
            ]
        }
        
        return random.choice(reflection_starters.get(dominant_dim, reflection_starters["optimism"]))
    
    def _synthesize_conversational_response(self, query: str, dominant_dim: str, strengths: Dict) -> str:
        """Synthesize general conversational response."""
        
        conversational_responses = {
            "optimism": [
                "I appreciate you bringing this up! Our swarm intelligence finds this engaging and worth exploring together.",
                "This is interesting to consider. Our collective perspective sees potential for meaningful discussion.",
                "I'm glad we can explore this together. Our deliberative process brings multiple valuable perspectives to bear."
            ],
            "caution": [
                "Thank you for raising this. Our swarm believes in approaching such topics with appropriate thoughtfulness.",
                "This merits careful consideration. Our collective intelligence suggests we should examine this thoroughly.",
                "I appreciate the opportunity to think through this carefully with you. Our deliberation reveals nuanced considerations."
            ],
            "justice": [
                "This is an important topic that deserves principled consideration. Our swarm takes such matters seriously.",
                "I value the opportunity to discuss this thoughtfully. Our democratic deliberation helps us address this fairly.",
                "This touches on significant questions that our collective reasoning can help illuminate."
            ]
        }
        
        return random.choice(conversational_responses.get(dominant_dim, conversational_responses["optimism"]))

class EmotionalChatTerminal:
    """Advanced conversational interface with modern A2A communication"""
    
    def __init__(self):
        self.swarm = V11EmotionalSwarm()
        self.roundtable = EmotionalRoundTable()
        self.orchestrator = CrossAgentConsensusOrchestrator()
        self.a2a_comm = AdvancedA2ACommunication()
        self.evolution_enabled = True
        self.session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Emotion mappings for banners
        self.emotion_emojis = {
            "joy": "😀",
            "anticipation": "🤔", 
            "trust": "🤝",
            "surprise": "😲",
            "fear": "😨",
            "sadness": "😢",
            "disgust": "🤢",
            "anger": "😡",
            "determination": "💪"
        }
        
        console.print("\n🧠⚡ [bold blue]V11 Emotional Swarm - Advanced A2A Terminal[/bold blue]")
        console.print("[dim]Implementing modern agent communication strategies with deliberation protocols[/dim]")
        console.print("[dim]Type 'help' for commands, 'stop' to pause evolution, '/debug' for full transcripts[/dim]\n")

    def format_emotion_banner(self, emotion_votes: Dict[str, float]) -> str:
        """Create emotion banner from vote weights"""
        # Sort emotions by vote weight
        sorted_emotions = sorted(emotion_votes.items(), key=lambda x: x[1], reverse=True)
        
        # Get top 3 emotions
        top_emotions = []
        neutral_emotions = []
        negative_emotions = []
        
        for emotion, weight in sorted_emotions[:5]:  # Check top 5 for categorization
            emoji = self.emotion_emojis.get(emotion.lower(), "🤖")
            
            if weight > 0.6:  # Strong positive
                top_emotions.append(f"{emoji} {emotion.title()}")
            elif weight > 0.3:  # Moderate
                neutral_emotions.append(f"{emoji} {emotion.title()}")
            else:  # Weak/negative
                negative_emotions.append(f"🚫 {emotion.title()}")
        
        # Build banner
        banner_parts = []
        if top_emotions:
            banner_parts.extend(top_emotions[:2])
        if neutral_emotions and len(banner_parts) < 2:
            banner_parts.extend(neutral_emotions[:2-len(banner_parts)])
        if negative_emotions and len(banner_parts) < 3:
            banner_parts.extend(negative_emotions[:1])
            
        return f"[{' + '.join(banner_parts[:2])} – {banner_parts[2] if len(banner_parts) > 2 else ''}]"

    def render_answer(self, consensus_text: str) -> str:
        """Format consensus answer (≤ 4 sentences)"""
        # Split into sentences and limit to 4
        sentences = re.split(r'[.!?]+', consensus_text.strip())
        sentences = [s.strip() for s in sentences if s.strip()]
        
        if len(sentences) > 4:
            sentences = sentences[:4]
            sentences[-1] += "..."
            
        return ' '.join(sentences)

    def render_lora_block(self, proposal_spec: Dict) -> str:
        """Render LoRA proposal block"""
        if not proposal_spec.get('lora_proposal'):
            return ""
            
        proposal = proposal_spec['lora_proposal']
        
        block = f"""
✚ Proposed LoRA: {proposal.get('name', 'new_lora')}
   gain_target : +{proposal.get('gain_target', '5')}pp on {proposal.get('domain', 'general')}
   size_estimate: ~{proposal.get('size_mb', '25')} MB
   approve? (yes / no / edit)"""
        
        return block

    async def advanced_consensus_chain(self, user_input: str) -> Tuple[str, str]:
        """Route through advanced A2A communication protocols"""
        try:
            # Step 1: Get initial emotional responses from V11 swarm
            emotion_response = await self.swarm.orchestrate_consensus(user_input)
            
            # Step 2: Apply multi-round deliberation protocol
            deliberation_result = await self.a2a_comm.multi_round_deliberation(
                user_input, 
                emotion_response.get('agent_responses', [])
            )
            
            # Step 3: Generate democratic consensus response
            consensus_response = await self.a2a_comm.democratic_vote_synthesis(
                deliberation_result, 
                user_input
            )
            
            # Map dimension scores to individual emotions for banner
            dimension_scores = emotion_response.get('dimension_scores', {})
            
            # Convert dimension scores to emotion votes for banner formatting
            emotion_votes = {}
            if 'optimism' in dimension_scores:
                emotion_votes['joy'] = dimension_scores['optimism']
                emotion_votes['anticipation'] = dimension_scores['optimism'] * 0.9
                emotion_votes['trust'] = dimension_scores['optimism'] * 0.8
            if 'caution' in dimension_scores:
                emotion_votes['fear'] = dimension_scores['caution']
                emotion_votes['surprise'] = dimension_scores['caution'] * 0.9
                emotion_votes['sadness'] = dimension_scores['caution'] * 0.8
            if 'justice' in dimension_scores:
                emotion_votes['anger'] = dimension_scores['justice']
                emotion_votes['disgust'] = dimension_scores['justice'] * 0.9
                emotion_votes['determination'] = dimension_scores['justice'] * 0.8
            
            # Fallback if no dimension scores
            if not emotion_votes:
                emotion_votes = {'anticipation': 0.7, 'joy': 0.5, 'fear': 0.2}
            
            # Format banner and answer
            banner = self.format_emotion_banner(emotion_votes)
            answer = self.render_answer(consensus_response)
            
            return banner, answer
            
        except Exception as e:
            return "[🤖 System]", f"A2A communication error: {str(e)}"

    async def run_roundtable(self, lora_request: str) -> Dict:
        """Run emotional roundtable for LoRA proposals"""
        try:
            # Process through roundtable protocol - using the correct method name
            roundtable_result = await self.roundtable.run_roundtable(lora_request)
            
            # Convert EvolutionProposal to our expected format
            return {
                'votes': roundtable_result.votes or {'anticipation': 0.5, 'joy': 0.3, 'fear': 0.4},
                'transcript': f"Proposed: {roundtable_result.id} - {roundtable_result.target_block}",
                'lora_proposal': {
                    'name': roundtable_result.id,
                    'gain_target': roundtable_result.expected_gain_pp,
                    'domain': roundtable_result.target_block,
                    'size_mb': roundtable_result.memory_budget_mb or 25
                }
            }
            
        except Exception as e:
            return {
                'votes': {'anticipation': 0.5, 'joy': 0.3, 'fear': 0.4},
                'transcript': f"Error processing LoRA request: {str(e)}",
                'lora_proposal': {
                    'name': 'fallback_lora',
                    'gain_target': 5,
                    'domain': 'general',
                    'size_mb': 25
                }
            }

    def handle_approval(self, spec: Dict, response: str) -> str:
        """Handle LoRA approval workflow"""
        response = response.lower().strip()
        
        if response.startswith("yes"):
            # Create job spec
            job_spec = {
                'id': f"lora_{self.session_id}_{int(time.time())}",
                'type': 'lora_training',
                'name': spec['lora_proposal']['name'],
                'created': datetime.now().isoformat(),
                'spec': spec['lora_proposal'],
                'status': 'queued'
            }
            
            # Ensure jobs directory exists
            os.makedirs("jobs/queue", exist_ok=True)
            
            # Write job spec
            job_path = f"jobs/queue/{job_spec['id']}.yaml"
            with open(job_path, 'w') as f:
                yaml.dump(job_spec, f)
                
            return f"✔️ Queued job `{job_spec['name']}`. Training will run in tonight's window."
            
        elif response.startswith("no"):
            return "❌ LoRA proposal declined."
            
        elif response.startswith("edit"):
            return "✏️ Please specify what to modify in the proposal."
            
        else:
            return "Please respond with 'yes', 'no', or 'edit'."

    def print_debug_transcript(self, spec: Dict):
        """Print full nine-head transcript for debugging"""
        console.print("\n[bold yellow]🐛 DEBUG MODE - Full A2A Transcript[/bold yellow]")
        
        if 'emotion_transcripts' in spec:
            from rich.table import Table
            
            table = Table(show_header=True, header_style="bold magenta")
            table.add_column("Agent", style="cyan")
            table.add_column("Response", style="white")
            table.add_column("Confidence", style="green")
            table.add_column("Deliberation", style="yellow")
            
            for emotion, data in spec['emotion_transcripts'].items():
                table.add_row(
                    emotion.title(),
                    data.get('response', 'No response')[:80] + "...",
                    str(data.get('confidence', 0.0)),
                    str(data.get('rounds', 'N/A'))
                )
            
            console.print(table)
        else:
            console.print("[dim]No detailed transcript available[/dim]")

    async def chat_loop(self):
        """Main chat loop with advanced A2A communication"""
        while True:
            try:
                # Get user input
                user_input = console.input("\n[bold green]YOU:[/bold green] ").strip()
                
                if not user_input:
                    continue
                    
                # Handle special commands
                if user_input.lower() == "stop":
                    self.evolution_enabled = not self.evolution_enabled
                    status = "enabled" if self.evolution_enabled else "paused"
                    console.print(f"🛑 Evolution {status}.")
                    continue
                    
                if user_input.lower() == "help":
                    self.show_help()
                    continue
                    
                if user_input.lower() == "exit" or user_input.lower() == "quit":
                    console.print("👋 Goodbye!")
                    break
                
                # Check for debug mode
                if user_input.startswith("/debug"):
                    # Handle debug commands later
                    console.print("[dim]Debug mode - showing full A2A transcripts on next query[/dim]")
                    continue
                
                # Detect growth/training requests
                is_growth = bool(re.match(r"(?i)\b(grow|train|could you learn|add|create|build)\b", user_input))
                
                console.print("\n[bold blue]SWARM:[/bold blue]", end=" ")
                
                if is_growth and self.evolution_enabled:
                    # LoRA evolution path
                    spec = await self.run_roundtable(user_input)
                    
                    # Print banner
                    banner = self.format_emotion_banner(spec.get('votes', {}))
                    console.print(banner)
                    
                    # Print consensus answer
                    answer = self.render_answer(spec.get('transcript', 'Processing LoRA request...'))
                    console.print(f"       {answer}")
                    
                    # Print LoRA block if proposal exists
                    lora_block = self.render_lora_block(spec)
                    if lora_block:
                        console.print(lora_block)
                        
                        # Get approval
                        approval = console.input("\n[bold yellow]APPROVE:[/bold yellow] ").strip()
                        result = self.handle_approval(spec, approval)
                        console.print(f"       {result}")
                        
                else:
                    # Advanced A2A communication path
                    banner, answer = await self.advanced_consensus_chain(user_input)
                    console.print(banner)
                    console.print(f"       {answer}")
                    
            except KeyboardInterrupt:
                console.print("\n👋 Chat interrupted. Goodbye!")
                break
            except Exception as e:
                console.print(f"\n[red]Error:[/red] {str(e)}")

    def show_help(self):
        """Show help information"""
        help_text = """
[bold blue]🧠⚡ V11 Emotional Swarm - Advanced A2A Communication[/bold blue]

[bold]Enhanced Chat Features:[/bold]
• Multi-round deliberation protocols
• Democratic consensus mechanisms  
• Influence-based agent communication
• Swarm intelligence coordination

[bold]Basic Chat:[/bold]
• Just type naturally - the swarm will deliberate and respond with unified consensus

[bold]Evolution Commands:[/bold]
• "grow <skill>" - Request new LoRA development
• "train <capability>" - Ask for capability enhancement  
• "could you learn <topic>" - Natural language LoRA requests

[bold]System Commands:[/bold]
• stop - Toggle evolution on/off
• /debug - Show full A2A deliberation transcripts  
• help - Show this help
• exit/quit - Leave chat

[bold]A2A Communication Features:[/bold]
• Deliberation rounds: 3 (adjustable)
• Consensus threshold: 70%
• Influence weighting: Optimism 40%, Caution 35%, Justice 25%
• Democratic voting synthesis
"""
        console.print(Panel(help_text, title="Advanced A2A Help", border_style="blue"))

def main():
    """Main entry point"""
    terminal = EmotionalChatTerminal()
    
    try:
        import asyncio
        asyncio.run(terminal.chat_loop())
    except Exception as e:
        console.print(f"[red]Startup error:[/red] {str(e)}")
        console.print("[dim]Make sure V11 emotional swarm components are available[/dim]")

if __name__ == "__main__":
    main() 