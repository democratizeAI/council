#!/usr/bin/env python3
"""
🔥💀⚔️ ROUTE AUDIT - VERIFY INTEGRATED DISPATCHER ⚔️💀🔥
===========================================================
MISSION: Test integrated dispatcher routing on Boss-200 samples
TARGET: ≥90% precision & recall on random sample
STRATEGY: Sample questions, test routing, validate accuracy
"""

import sys
import os
import random
import argparse
from typing import List, Dict, Tuple

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from router_intent import detect_block

class RouteAuditor:
    """Audit dispatcher routing on Boss-200 style questions"""
    
    def __init__(self):
        # Sample questions from each category (Boss-200 style)
        self.questions = {
            "math": [
                "Calculate 15! factorial",
                "What is 25% of 240?", 
                "Calculate 7!",
                "What is 2^10?",
                "What is the square root of 144?",
                "Calculate 8 * 7 * 6 * 5",
                "What is 40% of 150?",
                "Calculate 12 * 13",
                "What is 15% of 200?",
                "Calculate 9!",
                "What is 75% of 80?",
                "Calculate 6!",
                "What is 11 * 12?",
                "What is 2^8?",
                "Calculate 10 * 11",
                "What is 50% of 120?",
                "Calculate factorial of 8",
                "What is 30% of 500?",
                "Calculate 13 * 14",
                "What is 25% of 400?"
            ],
            "code": [
                "Write a Python function to calculate factorial",
                "Implement binary search in Python",
                "Write a function to reverse a string",
                "Implement bubble sort algorithm", 
                "Write a function to check if number is prime",
                "Write a function to merge two sorted lists",
                "Algorithm to find maximum in list",
                "Write a function to count vowels",
                "Implement merge sort",
                "Write a function to check palindrome",
                "Binary search in rotated array",
                "Quick sort implementation",
                "Write a function for fibonacci sequence",
                "Implement stack data structure",
                "Write a function to find GCD",
                "Breadth first search algorithm",
                "Write a function to validate JSON",
                "Implement queue using stacks",
                "Write a function for binary tree traversal",
                "Graph shortest path algorithm"
            ],
            "knowledge": [
                "What is the capital of France?",
                "Who wrote Romeo and Juliet?", 
                "What is the chemical symbol for gold?",
                "In what year did World War II end?",
                "What is the largest planet in our solar system?",
                "What is the capital of Germany?",
                "Who wrote Hamlet?",
                "What is the capital of Japan?",
                "Chemical symbol for silver",
                "When did WWII start?",
                "What is the capital of Brazil?",
                "Who wrote The Great Gatsby?",
                "What is the chemical symbol for iron?",
                "What year was the internet invented?",
                "What is the smallest planet?",
                "What is the capital of Canada?",
                "Who painted the Mona Lisa?",
                "What is the chemical symbol for sodium?",
                "When was the Berlin Wall built?",
                "What is the capital of Australia?"
            ],
            "logic": [
                "A job starts at 09:00 and takes 6 hours", 
                "Schedule three jobs with constraints",
                "Job A before job B, job C after B",
                "What is the earliest start time?",
                "Jobs must not overlap",
                "Schedule tasks with dependencies", 
                "Temporal ordering problem",
                "Constraint satisfaction scheduling",
                "Before and after job relationships",
                "Parallel job scheduling",
                "Resource allocation timing",
                "Sequential task ordering",
                "Overlapping schedule conflicts",
                "Earliest finish time calculation",
                "Latest start time for completion",
                "Critical path scheduling",
                "Dependency chain optimization",
                "Multi-resource job placement",
                "Time window constraints",
                "Priority-based task scheduling"
            ]
        }
    
    def sample_questions(self, limit: int = 40, random_seed: int = 42) -> List[Tuple[str, str]]:
        """Sample questions randomly from each category"""
        
        random.seed(random_seed)
        samples = []
        
        questions_per_category = limit // 4
        remainder = limit % 4
        
        for i, (category, question_list) in enumerate(self.questions.items()):
            # Add extra question to first few categories if remainder
            num_questions = questions_per_category + (1 if i < remainder else 0)
            
            # Sample questions from this category
            category_samples = random.sample(question_list, min(num_questions, len(question_list)))
            
            for question in category_samples:
                samples.append((question, category))
        
        # Shuffle the final list
        random.shuffle(samples)
        
        return samples
    
    def audit_routing(self, samples: List[Tuple[str, str]]) -> Dict[str, float]:
        """Audit routing accuracy on sample questions"""
        
        print("🔥💀⚔️ ROUTE AUDIT")
        print("=" * 50)
        print(f"📊 Testing {len(samples)} randomly sampled questions")
        print()
        
        correct = 0
        total = len(samples)
        category_stats = {}
        
        for question, expected_category in samples:
            predicted_category = detect_block(question)
            is_correct = predicted_category == expected_category
            
            if is_correct:
                correct += 1
            
            # Track per-category stats
            if expected_category not in category_stats:
                category_stats[expected_category] = {"correct": 0, "total": 0}
            
            category_stats[expected_category]["total"] += 1
            if is_correct:
                category_stats[expected_category]["correct"] += 1
            
            status = "✅" if is_correct else "❌"
            print(f"{status} {question[:50]:50} | Expected: {expected_category:9} | Got: {predicted_category}")
        
        overall_accuracy = correct / total
        
        print(f"\n📈 CATEGORY BREAKDOWN:")
        for category, stats in category_stats.items():
            cat_accuracy = stats["correct"] / stats["total"]
            print(f"   {category:9}: {stats['correct']:2}/{stats['total']:2} = {cat_accuracy:.1%}")
        
        print(f"\n🎯 OVERALL: {correct}/{total} = {overall_accuracy:.1%}")
        
        if overall_accuracy >= 0.9:
            print("✅ ROUTING EXCELLENT - Ready for production")
        elif overall_accuracy >= 0.8:
            print("⚠️ ROUTING GOOD - Minor tuning recommended")
        else:
            print("❌ ROUTING NEEDS WORK - Major patterns missing")
        
        return {
            "accuracy": overall_accuracy,
            "precision": overall_accuracy,  # Simplified for this audit
            "recall": overall_accuracy,
            "category_stats": category_stats
        }

def main():
    """Main audit entry point"""
    
    parser = argparse.ArgumentParser(description="Audit dispatcher routing accuracy")
    parser.add_argument("--sample", type=int, default=40, help="Number of questions to sample")
    parser.add_argument("--random", action="store_true", help="Use random sampling")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    
    args = parser.parse_args()
    
    auditor = RouteAuditor()
    
    if args.random:
        samples = auditor.sample_questions(limit=args.sample, random_seed=args.seed)
    else:
        # Use first N questions from each category
        samples = []
        per_category = args.sample // 4
        for category, questions in auditor.questions.items():
            for i in range(min(per_category, len(questions))):
                samples.append((questions[i], category))
    
    results = auditor.audit_routing(samples)
    
    # Return appropriate exit code for CI/CD
    return 0 if results["accuracy"] >= 0.9 else 1

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code) 