#!/usr/bin/env python3
"""
Feed code challenges to the Tamagotchi evolution system
"""

import os
import json
import yaml
from datetime import datetime

def create_code_job():
    """Create a new code evolution job"""
    
    # Sample coding problems
    code_problems = [
        {
            "problem": "Write a function to reverse a string",
            "solution": "def reverse_string(s): return s[::-1]",
            "difficulty": "basic"
        },
        {
            "problem": "Write a function to check if a number is prime",
            "solution": "def is_prime(n): return n > 1 and all(n % i != 0 for i in range(2, int(n**0.5) + 1))",
            "difficulty": "medium"
        },
        {
            "problem": "Write a function to find the factorial of a number",
            "solution": "def factorial(n): return 1 if n <= 1 else n * factorial(n - 1)",
            "difficulty": "basic"
        },
        {
            "problem": "Write a function to sort a list using bubble sort",
            "solution": "def bubble_sort(arr): [arr[i], arr[j]] := [arr[j], arr[i]] for i in range(len(arr)) for j in range(i+1, len(arr)) if arr[i] > arr[j]; return arr",
            "difficulty": "medium"
        },
        {
            "problem": "Write a function to find the longest common substring",
            "solution": "def lcs(s1, s2): return max((s1[i:j] for i in range(len(s1)) for j in range(i+1, len(s1)+1) if s1[i:j] in s2), key=len, default='')",
            "difficulty": "hard"
        }
    ]
    
    # Create job configuration
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    job_id = f"code_feed_{timestamp}"
    
    job_config = {
        "job_id": job_id,
        "model_name": "gpt2",
        "dataset_type": "code_challenge",
        "learning_rate": 5e-5,
        "num_epochs": 3,
        "batch_size": 4,
        "max_length": 256,
        "target_modules": ["c_attn", "c_proj"],
        "lora_r": 16,
        "lora_alpha": 32,
        "lora_dropout": 0.1,
        "created_at": datetime.now().isoformat(),
        "source": "code_feeding"
    }
    
    # Create dataset
    dataset_path = f"datasets/{job_id}.jsonl"
    os.makedirs("datasets", exist_ok=True)
    
    with open(dataset_path, 'w', encoding='utf-8') as f:
        for problem in code_problems:
            entry = {
                "input": f"Coding Challenge: {problem['problem']}",
                "output": f"Solution: {problem['solution']}",
                "metadata": {
                    "difficulty": problem['difficulty'],
                    "source": "code_feeding"
                }
            }
            f.write(json.dumps(entry) + '\n')
    
    job_config["dataset_path"] = dataset_path
    
    # Save job to queue
    queue_dir = "jobs/queue"
    os.makedirs(queue_dir, exist_ok=True)
    
    job_file = os.path.join(queue_dir, f"{job_id}.yaml")
    with open(job_file, 'w', encoding='utf-8') as f:
        yaml.dump(job_config, f, default_flow_style=False)
    
    print(f"✅ Created code evolution job: {job_id}")
    print(f"💻 Dataset: {len(code_problems)} coding problems")
    print(f"📁 Job file: {job_file}")
    
    return job_id

if __name__ == "__main__":
    create_code_job() 