#!/usr/bin/env python3
"""
Feed reasoning puzzles to the Tamagotchi evolution system
"""

import os
import json
import yaml
from datetime import datetime

def create_reasoning_job():
    """Create a new reasoning evolution job"""
    
    # Sample reasoning problems
    reasoning_problems = [
        {
            "problem": "If all cats are mammals, and all mammals are animals, then all cats are animals. True or false?",
            "solution": "True. This is a valid syllogism using transitive reasoning.",
            "difficulty": "basic"
        },
        {
            "problem": "A man lives on the 20th floor. Every morning he takes the elevator down. When he comes home, he takes the elevator to the 10th floor and walks the rest, except on rainy days when he takes it all the way. Why?",
            "solution": "He's too short to reach the button for the 20th floor, except when he has an umbrella on rainy days.",
            "difficulty": "hard"
        },
        {
            "problem": "If it takes 5 machines 5 minutes to make 5 widgets, how long would it take 100 machines to make 100 widgets?",
            "solution": "5 minutes. Each machine makes 1 widget in 5 minutes.",
            "difficulty": "medium"
        },
        {
            "problem": "You have two coins that add up to 30 cents. One is not a nickel. What are the two coins?",
            "solution": "A quarter and a nickel. One (the quarter) is not a nickel.",
            "difficulty": "medium"
        },
        {
            "problem": "What comes next in the sequence: 2, 6, 12, 20, 30, ?",
            "solution": "42. The pattern is n(n+1) where n increases by 1 each time.",
            "difficulty": "medium"
        }
    ]
    
    # Create job configuration
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    job_id = f"reasoning_feed_{timestamp}"
    
    job_config = {
        "job_id": job_id,
        "model_name": "gpt2",
        "dataset_type": "reasoning_challenge",
        "learning_rate": 5e-5,
        "num_epochs": 3,
        "batch_size": 4,
        "max_length": 256,
        "target_modules": ["c_attn", "c_proj"],
        "lora_r": 16,
        "lora_alpha": 32,
        "lora_dropout": 0.1,
        "created_at": datetime.now().isoformat(),
        "source": "reasoning_feeding"
    }
    
    # Create dataset
    dataset_path = f"datasets/{job_id}.jsonl"
    os.makedirs("datasets", exist_ok=True)
    
    with open(dataset_path, 'w', encoding='utf-8') as f:
        for problem in reasoning_problems:
            entry = {
                "input": f"Reasoning Problem: {problem['problem']}",
                "output": f"Solution: {problem['solution']}",
                "metadata": {
                    "difficulty": problem['difficulty'],
                    "source": "reasoning_feeding"
                }
            }
            f.write(json.dumps(entry) + '\n')
    
    job_config["dataset_path"] = dataset_path
    
    # Save job to queue
    queue_dir = "jobs/queue"
    os.makedirs(queue_dir, exist_ok=True)
    
    job_file = os.path.join(queue_dir, f"{job_id}.yaml")
    with open(job_file, 'w', encoding='utf-8') as f:
        yaml.dump(job_config, f, default_flow_style=False)
    
    print(f"✅ Created reasoning evolution job: {job_id}")
    print(f"🧠 Dataset: {len(reasoning_problems)} reasoning puzzles")
    print(f"📁 Job file: {job_file}")
    
    return job_id

if __name__ == "__main__":
    create_reasoning_job() 