#!/usr/bin/env python3
"""Test serve.py directly to see what's happening"""

import requests
import json

def test_serve_endpoint():
    """Test the serve.py endpoint directly"""
    
    test_queries = [
        "hey!",
        "Not a lot, just chilling.",
        "What's 7 factorial?",
        "Write a function to check if a number is prime",
        "What's the capital of France?"
    ]
    
    for query in test_queries:
        print(f"\n🔍 Testing: '{query}'")
        print("-" * 50)
        
        try:
            response = requests.post(
                "http://localhost:8000/query",
                json={"query": query},
                timeout=2.0
            )
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ Success: {result.get('method', 'unknown')}")
                print(f"📝 Response: {result.get('text', '')[:100]}...")
                print(f"⚡ Latency: {result.get('latency_ms', 0):.0f}ms")
                print(f"🎯 Confidence: {result.get('confidence', 0):.2f}")
            else:
                print(f"❌ Error {response.status_code}: {response.text}")
                
        except Exception as e:
            print(f"💥 Exception: {e}")

if __name__ == "__main__":
    test_serve_endpoint() 