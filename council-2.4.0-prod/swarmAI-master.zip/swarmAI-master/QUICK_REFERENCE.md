# 🪴 **TAMAGOTCHI QUICK REFERENCE**

## **Daily Commands (30 seconds)**
```bash
python evolve.py --status              # Overall health
python scripts/monitor_evolution.py    # Real-time progress  
python scripts/shake_down.py --quick   # Safety check
```

## **Start/Stop System**
```bash
# Start autonomous evolution
python trainer/trainer_worker.py --watch-queue &

# Stop everything  
pkill -f trainer_worker.py

# Emergency stop
Ctrl+C
```

## **Feed Your Tamagotchi**
```bash
python scripts/seed_math_evolution.py      # Math challenges
python scripts/seed_code_evolution.py      # Code problems
python scripts/seed_reasoning_evolution.py # Logic puzzles
```

## **Health Indicators**
| **Metric** | **Good** | **Warning** | **Critical** |
|------------|----------|-------------|--------------|
| Pending Jobs | 1-5 | >10 | >20 |
| Validation Success | >20% | 5-20% | <5% |
| Latency | <50ms | 50-100ms | >100ms |
| Disk Usage | <1GB | 1-1.8GB | >1.8GB |

## **Emergency Actions**
```bash
python evolve.py --rollback-last        # Undo last promotion
python evolve.py --emergency-rollback   # Full system reset
python evolve.py --restore-checkpoint   # Restore specific state
```

## **Weekly Maintenance**
```bash
python scripts/shake_down.py --full     # Complete audit
python evolve.py --prune-old            # Clean old files
head -20 evolution_checksums.txt        # Review changes
```

---
**Remember**: A healthy Tamagotchi should show steady but slowing progress. Plateaus are normal! 🌱 