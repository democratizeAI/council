#!/usr/bin/env python3
"""Debug routing between router and server"""

from router_intent import detect_block
from serve import detect_problem_type

def test_routing():
    test_queries = [
        "Calculate 7!",
        "What is 25% of 240?",
        "Write a Python function",
        "Who wrote Hamlet?",
        "Schedule three jobs"
    ]
    
    print("🔍 ROUTING DEBUG TEST")
    print("=" * 50)
    
    for query in test_queries:
        router_result = detect_block(query)
        server_result = detect_problem_type(query)
        
        print(f"Query: {query}")
        print(f"  Router: {router_result}")
        print(f"  Server: {server_result}")
        print()

if __name__ == "__main__":
    test_routing() 