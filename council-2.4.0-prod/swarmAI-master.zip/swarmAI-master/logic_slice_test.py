#!/usr/bin/env python3
"""
🔥💀⚔️ LOGIC SLICE TEST - SPRINT S-2 ⚔️💀🔥
==============================================
MISSION: Validate multi-hop logic reasoning
TARGET: 10-problem logic slice with <20ms latency each
"""

import time
import json
import requests
from typing import List, Dict, Any

class LogicSliceTest:
    """Multi-hop logic test slice for Sprint S-2 validation"""
    
    def __init__(self, server_url: str = "http://localhost:8000/query"):
        self.server_url = server_url
        
        self.test_problems = [
            # Transitive inequalities
            {
                "query": "If A > B and B > C, what can we conclude about A and C?",
                "expected_keywords": ["transitive", "a > c", "greater"],
                "type": "inequality_chain",
                "difficulty": "easy"
            },
            
            # Universal quantification (syllogism)
            {
                "query": "If all cats are mammals and all mammals are animals, are all cats animals?",
                "expected_keywords": ["yes", "cats are animals", "syllogistic"],
                "type": "universal_quantification",
                "difficulty": "medium"
            },
            
            # Conditional reasoning (modus ponens)
            {
                "query": "If all programmers drink coffee and John is a programmer, does John drink coffee?",
                "expected_keywords": ["yes", "john drinks coffee", "universal instantiation"],
                "type": "conditional_reasoning",
                "difficulty": "easy"
            },
            
            # Multi-step temporal reasoning
            {
                "query": "A job starts at 09:00 and takes 6 hours. Another job starts 2 hours after the first finishes and needs 4 hours. When does the second job end?",
                "expected_keywords": ["21:00", "17:00", "temporal"],
                "type": "temporal_chain",
                "difficulty": "medium"
            },
            
            # Complex logical chain
            {
                "query": "If all birds can fly and all eagles are birds, can all eagles fly?",
                "expected_keywords": ["yes", "eagles", "fly"],
                "type": "universal_quantification",
                "difficulty": "easy"
            },
            
            # Numerical sequence reasoning
            {
                "query": "What comes next in the sequence: 2, 4, 8, 16, ?",
                "expected_keywords": ["32", "powers", "double"],
                "type": "pattern_recognition",
                "difficulty": "easy"
            },
            
            # Logical fallacy detection
            {
                "query": "If it's raining, then the ground is wet. The ground is wet. Is it raining?",
                "expected_keywords": ["not necessarily", "maybe", "fallacy"],
                "type": "logical_fallacy",
                "difficulty": "hard"
            },
            
            # Multi-step implication
            {
                "query": "If P implies Q, and Q implies R, what can we conclude about P and R?",
                "expected_keywords": ["p implies r", "transitive", "implication"],
                "type": "transitive_implication", 
                "difficulty": "medium"
            },
            
            # Clock angle problem
            {
                "query": "A clock shows 3:15. What is the angle between the hour and minute hands?",
                "expected_keywords": ["7.5", "degrees", "angle"],
                "type": "mathematical_reasoning",
                "difficulty": "hard"
            },
            
            # Fibonacci sequence
            {
                "query": "What is the missing number: 1, 1, 2, 3, 5, 8, ?",
                "expected_keywords": ["13", "fibonacci", "sequence"],
                "type": "pattern_recognition",
                "difficulty": "medium"
            }
        ]
    
    def test_single_logic_problem(self, problem: dict) -> dict:
        """Test a single logic problem against the server"""
        start_time = time.time()
        
        try:
            response = requests.post(
                self.server_url,
                json={"query": problem["query"]},
                timeout=10
            )
            
            if response.status_code == 200:
                result = response.json()
                text = result.get("text", "").lower()
                
                # Check for expected keywords
                has_keywords = any(keyword.lower() in text for keyword in problem["expected_keywords"])
                
                # Check for success indicators
                success = result.get("success", False) and has_keywords and not any(
                    fail_word in text for fail_word in ["error", "failed", "unsupported"]
                )
                
                return {
                    "query": problem["query"],
                    "type": problem["type"],
                    "difficulty": problem["difficulty"],
                    "response": result,
                    "has_expected_keywords": has_keywords,
                    "success": success,
                    "latency_ms": result.get("latency_ms", 0),
                    "total_time_ms": (time.time() - start_time) * 1000,
                    "method": result.get("method", "unknown")
                }
            else:
                return {
                    "query": problem["query"],
                    "type": problem["type"],
                    "difficulty": problem["difficulty"],
                    "response": {"error": f"HTTP {response.status_code}"},
                    "has_expected_keywords": False,
                    "success": False,
                    "latency_ms": 0,
                    "total_time_ms": (time.time() - start_time) * 1000,
                    "method": "http_error"
                }
                
        except Exception as e:
            return {
                "query": problem["query"],
                "type": problem["type"],
                "difficulty": problem["difficulty"],
                "response": {"error": str(e)},
                "has_expected_keywords": False,
                "success": False,
                "latency_ms": 0,
                "total_time_ms": (time.time() - start_time) * 1000,
                "method": "exception"
            }
    
    def run_logic_slice(self) -> dict:
        """Run the complete logic slice test"""
        print("🔥💀⚔️ LOGIC SLICE TEST - SPRINT S-2 ⚔️💀🔥")
        print("=" * 60)
        
        start_time = time.time()
        results = []
        
        for i, problem in enumerate(self.test_problems):
            print(f"\n📝 Test {i+1}/10: {problem['type'].upper()}")
            print(f"    Query: {problem['query'][:60]}...")
            
            result = self.test_single_logic_problem(problem)
            results.append(result)
            
            # Show immediate feedback
            status = "✅ PASS" if result["success"] else "❌ FAIL"
            method = result.get('method', 'unknown')
            print(f"    {status}: {result['response'].get('text', 'ERROR')[:80]}...")
            print(f"    Method: {method}, Latency: {result['latency_ms']:.1f}ms")
        
        # Calculate summary statistics
        total_time = time.time() - start_time
        passed = sum(1 for r in results if r["success"])
        accuracy = passed / len(results)
        avg_latency = sum(r["latency_ms"] for r in results) / len(results)
        
        # Break down by type and method
        type_stats = {}
        method_stats = {}
        
        for result in results:
            # Type breakdown
            prob_type = result["type"]
            if prob_type not in type_stats:
                type_stats[prob_type] = {"total": 0, "passed": 0}
            type_stats[prob_type]["total"] += 1
            if result["success"]:
                type_stats[prob_type]["passed"] += 1
                
            # Method breakdown
            method = result.get("method", "unknown")
            if method not in method_stats:
                method_stats[method] = {"total": 0, "passed": 0}
            method_stats[method]["total"] += 1
            if result["success"]:
                method_stats[method]["passed"] += 1
        
        print(f"\n🔥💀⚔️ LOGIC SLICE RESULTS - SPRINT S-2 ⚔️💀🔥")
        print("=" * 60)
        print(f"⚡ OVERALL ACCURACY: {accuracy:.1%} ({passed}/{len(results)})")
        print(f"⚡ AVERAGE LATENCY: {avg_latency:.1f}ms")
        print(f"⚡ TOTAL TEST TIME: {total_time:.1f}s")
        print()
        print("📊 BREAKDOWN BY TYPE:")
        for prob_type, stats in type_stats.items():
            type_accuracy = stats["passed"] / stats["total"]
            print(f"   {prob_type}: {type_accuracy:.1%} ({stats['passed']}/{stats['total']})")
        print()
        print("🔬 BREAKDOWN BY METHOD:")
        for method, stats in method_stats.items():
            method_accuracy = stats["passed"] / stats["total"]
            print(f"   {method}: {method_accuracy:.1%} ({stats['passed']}/{stats['total']})")
        
        return {
            "overall_accuracy": accuracy,
            "total_passed": passed,
            "total_problems": len(results),
            "avg_latency_ms": avg_latency,
            "total_time_s": total_time,
            "type_breakdown": type_stats,
            "method_breakdown": method_stats,
            "detailed_results": results
        }

def main():
    """Run logic slice test"""
    tester = LogicSliceTest()
    results = tester.run_logic_slice()
    
    # Save results
    with open("logic_slice_results.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\n💾 Results saved to logic_slice_results.json")
    
    # Sprint S-2 success criteria
    target_accuracy = 0.8  # 80% target (harder than math)
    target_latency = 20.0  # <20ms target for inference
    
    if results["overall_accuracy"] >= target_accuracy:
        print(f"🎯 SPRINT S-2 ACCURACY TARGET MET: {results['overall_accuracy']:.1%} >= {target_accuracy:.1%}")
    else:
        print(f"🚨 SPRINT S-2 ACCURACY TARGET MISSED: {results['overall_accuracy']:.1%} < {target_accuracy:.1%}")
    
    if results["avg_latency_ms"] <= target_latency:
        print(f"⚡ SPRINT S-2 LATENCY TARGET MET: {results['avg_latency_ms']:.1f}ms <= {target_latency}ms")
    else:
        print(f"🚨 SPRINT S-2 LATENCY TARGET MISSED: {results['avg_latency_ms']:.1f}ms > {target_latency}ms")

if __name__ == "__main__":
    main() 