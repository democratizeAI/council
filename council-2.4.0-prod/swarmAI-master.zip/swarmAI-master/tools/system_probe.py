#!/usr/bin/env python3
"""
🔥💀⚡ SYSTEM PROBE - Hardware Configuration Analysis
=====================================================

Generates comprehensive JSON report for swarm optimization.
Critical for RTX 4070 VRAM budget planning and performance tuning.

Usage:
    python tools/system_probe.py
    python tools/system_probe.py --output swarm_system_report.json
"""

import json
import platform
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Dict, Any, Optional

try:
    import psutil
except ImportError:
    print("⚠️ psutil not found. Install with: pip install psutil")
    sys.exit(1)

try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    import GPUtil
    GPUTIL_AVAILABLE = True
except ImportError:
    GPUTIL_AVAILABLE = False

def run_command(cmd: str) -> tuple[bool, str]:
    """Run shell command and return success, output"""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        return result.returncode == 0, result.stdout.strip() if result.returncode == 0 else result.stderr.strip()
    except Exception as e:
        return False, str(e)

def get_nvidia_info() -> Dict[str, Any]:
    """Get NVIDIA GPU information via nvidia-smi"""
    nvidia_info = {
        "driver_version": None,
        "cuda_version": None,
        "gpus": [],
        "nvidia_smi_available": False
    }
    
    # Try nvidia-smi
    success, output = run_command("nvidia-smi --query-gpu=name,memory.total,memory.free,memory.used,utilization.gpu,temperature.gpu,power.draw,pci.bus_id --format=csv,noheader,nounits")
    
    if success:
        nvidia_info["nvidia_smi_available"] = True
        
        # Get driver and CUDA version
        success_ver, version_output = run_command("nvidia-smi")
        if success_ver and "Driver Version:" in version_output:
            lines = version_output.split('\n')
            for line in lines:
                if "Driver Version:" in line and "CUDA Version:" in line:
                    parts = line.split('|')
                    for part in parts:
                        if "Driver Version:" in part:
                            nvidia_info["driver_version"] = part.split("Driver Version:")[1].split()[0]
                        if "CUDA Version:" in part:
                            nvidia_info["cuda_version"] = part.split("CUDA Version:")[1].split()[0]
        
        # Parse GPU info
        for line in output.split('\n'):
            if line.strip():
                parts = [p.strip() for p in line.split(',')]
                if len(parts) >= 8:
                    gpu_info = {
                        "name": parts[0],
                        "memory_total_mb": int(parts[1]) if parts[1].isdigit() else 0,
                        "memory_free_mb": int(parts[2]) if parts[2].isdigit() else 0,
                        "memory_used_mb": int(parts[3]) if parts[3].isdigit() else 0,
                        "utilization_percent": int(parts[4]) if parts[4].isdigit() else 0,
                        "temperature_c": int(parts[5]) if parts[5].isdigit() else 0,
                        "power_draw_w": float(parts[6]) if parts[6].replace('.', '').isdigit() else 0,
                        "pci_bus_id": parts[7]
                    }
                    
                    # Calculate usable VRAM (total - OS reserve)
                    total_mb = gpu_info["memory_total_mb"]
                    if total_mb > 0:
                        # RTX 4070 has 12GB, usable ~10.5GB (1.5GB OS reserve)
                        # GTX 1080 has 8GB, usable ~7GB (1GB OS reserve)
                        if "RTX 4070" in gpu_info["name"]:
                            gpu_info["usable_vram_mb"] = total_mb - 1500
                        elif "GTX 1080" in gpu_info["name"]:
                            gpu_info["usable_vram_mb"] = total_mb - 1000
                        else:
                            gpu_info["usable_vram_mb"] = int(total_mb * 0.85)  # Conservative 15% reserve
                    
                    nvidia_info["gpus"].append(gpu_info)
    
    return nvidia_info

def get_pytorch_info() -> Dict[str, Any]:
    """Get PyTorch and CUDA information"""
    pytorch_info = {
        "torch_available": TORCH_AVAILABLE,
        "torch_version": None,
        "cuda_available": False,
        "cuda_version": None,
        "device_count": 0,
        "devices": []
    }
    
    if TORCH_AVAILABLE:
        pytorch_info["torch_version"] = torch.__version__
        pytorch_info["cuda_available"] = torch.cuda.is_available()
        
        if torch.cuda.is_available():
            pytorch_info["cuda_version"] = torch.version.cuda
            pytorch_info["device_count"] = torch.cuda.device_count()
            
            for i in range(torch.cuda.device_count()):
                device_props = torch.cuda.get_device_properties(i)
                device_info = {
                    "index": i,
                    "name": device_props.name,
                    "total_memory_mb": device_props.total_memory // 1024 // 1024,
                    "major": device_props.major,
                    "minor": device_props.minor,
                    "multi_processor_count": device_props.multi_processor_count
                }
                pytorch_info["devices"].append(device_info)
    
    return pytorch_info

def get_system_info() -> Dict[str, Any]:
    """Get general system information"""
    # CPU info
    cpu_info = {
        "model": platform.processor(),
        "architecture": platform.architecture()[0],
        "cores_physical": psutil.cpu_count(logical=False),
        "cores_logical": psutil.cpu_count(logical=True),
        "frequency_mhz": psutil.cpu_freq().current if psutil.cpu_freq() else None
    }
    
    # Memory info
    memory = psutil.virtual_memory()
    memory_info = {
        "total_gb": round(memory.total / 1024**3, 2),
        "available_gb": round(memory.available / 1024**3, 2),
        "used_gb": round(memory.used / 1024**3, 2),
        "percent": memory.percent
    }
    
    # Disk info
    disk = psutil.disk_usage('/')
    disk_info = {
        "total_gb": round(disk.total / 1024**3, 2),
        "free_gb": round(disk.free / 1024**3, 2),
        "used_gb": round(disk.used / 1024**3, 2),
        "percent": round((disk.used / disk.total) * 100, 1)
    }
    
    return {
        "platform": {
            "system": platform.system(),
            "release": platform.release(),
            "version": platform.version(),
            "machine": platform.machine(),
            "python_version": platform.python_version()
        },
        "cpu": cpu_info,
        "memory": memory_info,
        "disk": disk_info
    }

def get_pcie_info() -> Dict[str, Any]:
    """Get PCIe bandwidth and lane information"""
    pcie_info = {
        "lspci_available": False,
        "nvidia_devices": []
    }
    
    # Try to get PCIe info via lspci
    success, output = run_command("lspci -v -s $(lspci | grep -i nvidia | cut -d' ' -f1)")
    
    if success:
        pcie_info["lspci_available"] = True
        
        # Parse PCIe lane info
        lines = output.split('\n')
        current_device = None
        
        for line in lines:
            line = line.strip()
            if "NVIDIA" in line and "VGA" in line:
                current_device = {"device": line}
            elif "LnkCap:" in line and current_device:
                # Extract lane info: LnkCap: Port #0, Speed 8GT/s, Width x16
                if "Width x" in line:
                    width = line.split("Width x")[1].split(',')[0].strip()
                    current_device["pcie_lanes"] = width
                if "Speed " in line:
                    speed = line.split("Speed ")[1].split(',')[0].strip()
                    current_device["pcie_speed"] = speed
                    
                if current_device not in pcie_info["nvidia_devices"]:
                    pcie_info["nvidia_devices"].append(current_device)
                current_device = None
    
    return pcie_info

def get_network_info() -> Dict[str, Any]:
    """Get network interface information"""
    network_info = {
        "interfaces": [],
        "default_gateway": None
    }
    
    # Get network interfaces
    for interface, addrs in psutil.net_if_addrs().items():
        if_info = {"name": interface, "addresses": []}
        for addr in addrs:
            if_info["addresses"].append({
                "family": str(addr.family),
                "address": addr.address,
                "netmask": addr.netmask
            })
        network_info["interfaces"].append(if_info)
    
    # Try to get default gateway
    success, output = run_command("ip route | grep default")
    if success and output:
        network_info["default_gateway"] = output.split()[2] if len(output.split()) > 2 else None
    
    return network_info

def perform_memory_test() -> Dict[str, Any]:
    """Quick memory allocation test to verify available VRAM"""
    test_info = {
        "pytorch_memory_test": False,
        "max_allocatable_mb": 0,
        "error": None
    }
    
    if TORCH_AVAILABLE and torch.cuda.is_available():
        try:
            device = torch.device('cuda:0')
            torch.cuda.empty_cache()
            
            # Try to allocate in 512MB chunks to find max
            allocated_mb = 0
            chunk_size_mb = 512
            tensors = []
            
            while allocated_mb < 16000:  # Max 16GB test
                try:
                    tensor = torch.zeros(chunk_size_mb * 1024 * 1024 // 4, dtype=torch.float32, device=device)
                    tensors.append(tensor)
                    allocated_mb += chunk_size_mb
                except RuntimeError as e:
                    if "out of memory" in str(e).lower():
                        break
                    else:
                        raise e
            
            test_info["pytorch_memory_test"] = True
            test_info["max_allocatable_mb"] = allocated_mb
            
            # Clean up
            del tensors
            torch.cuda.empty_cache()
            
        except Exception as e:
            test_info["error"] = str(e)
    
    return test_info

def generate_optimization_recommendations(system_data: Dict[str, Any]) -> Dict[str, Any]:
    """Generate optimization recommendations based on hardware"""
    recommendations = {
        "vram_budget_mb": 0,
        "recommended_batch_size": 1,
        "suggested_models": [],
        "optimization_flags": [],
        "warnings": []
    }
    
    # Extract GPU info
    if system_data["nvidia"]["gpus"]:
        gpu = system_data["nvidia"]["gpus"][0]  # Primary GPU
        gpu_name = gpu["name"]
        total_vram = gpu.get("memory_total_mb", 0)
        usable_vram = gpu.get("usable_vram_mb", 0)
        
        recommendations["vram_budget_mb"] = usable_vram
        
        # Model recommendations based on GPU
        if "RTX 4070" in gpu_name:
            recommendations["suggested_models"] = [
                "phi2_2_7b_instruct (1.6GB)",
                "mistral_3b_quality (1.9GB)",  
                "openchat_3_5_0_4b (2.4GB)",
                "Multiple <1B heads (0.3-0.6GB each)"
            ]
            recommendations["recommended_batch_size"] = 16
            recommendations["optimization_flags"] = [
                "use_flash_attention=true",
                "use_tensor_cores=true",
                "kv_cache_dtype=fp16"
            ]
        elif "GTX 1080" in gpu_name:
            recommendations["suggested_models"] = [
                "phi2_2_7b_instruct (1.6GB)",
                "Multiple <1B heads (0.3-0.6GB each)",
                "Keep 3B+ models on CPU"
            ]
            recommendations["recommended_batch_size"] = 8
            recommendations["optimization_flags"] = [
                "use_flash_attention=false",
                "force_cpu_fallback=true"
            ]
        
        # Warnings
        if total_vram < 8000:
            recommendations["warnings"].append("Low VRAM detected - consider CPU inference for large models")
        
        if usable_vram < 5000:
            recommendations["warnings"].append("Very low usable VRAM - limit to <1B models only")
    
    return recommendations

def main():
    """Main system probe execution"""
    print("🔥💀⚡ SYSTEM PROBE - Analyzing hardware configuration...")
    print("=" * 60)
    
    start_time = time.time()
    
    # Collect all system information
    system_data = {
        "probe_info": {
            "timestamp": time.time(),
            "probe_version": "1.0.0",
            "execution_time_ms": 0
        },
        "system": get_system_info(),
        "nvidia": get_nvidia_info(),
        "pytorch": get_pytorch_info(),
        "pcie": get_pcie_info(),
        "network": get_network_info(),
        "memory_test": perform_memory_test()
    }
    
    # Generate recommendations
    system_data["recommendations"] = generate_optimization_recommendations(system_data)
    
    # Update execution time
    execution_time = (time.time() - start_time) * 1000
    system_data["probe_info"]["execution_time_ms"] = round(execution_time, 2)
    
    # Print summary
    print(f"\n📊 HARDWARE SUMMARY")
    print("-" * 30)
    
    if system_data["nvidia"]["gpus"]:
        gpu = system_data["nvidia"]["gpus"][0]
        print(f"🎮 GPU: {gpu['name']}")
        print(f"💾 VRAM: {gpu['memory_total_mb']}MB total, {gpu.get('usable_vram_mb', 'unknown')}MB usable")
        print(f"🔥 Utilization: {gpu['utilization_percent']}%")
        print(f"🌡️ Temperature: {gpu['temperature_c']}°C")
    
    print(f"🧠 CPU: {system_data['system']['cpu']['cores_logical']} cores")
    print(f"💽 RAM: {system_data['system']['memory']['total_gb']}GB total, {system_data['system']['memory']['available_gb']}GB available")
    
    if system_data["pytorch"]["cuda_available"]:
        print(f"⚡ PyTorch CUDA: {system_data['pytorch']['cuda_version']} ✅")
    else:
        print(f"⚡ PyTorch CUDA: Not available ❌")
    
    print(f"\n⏱️ Probe completed in {execution_time:.1f}ms")
    
    # Save to file
    output_file = "swarm_system_report.json"
    if len(sys.argv) > 1 and sys.argv[1] == "--output" and len(sys.argv) > 2:
        output_file = sys.argv[2]
    
    with open(output_file, 'w') as f:
        json.dump(system_data, f, indent=2, default=str)
    
    print(f"💾 Report saved to: {output_file}")
    print(f"\n🎯 RECOMMENDATIONS:")
    for rec in system_data["recommendations"]["suggested_models"]:
        print(f"   📦 {rec}")
    
    if system_data["recommendations"]["warnings"]:
        print(f"\n⚠️ WARNINGS:")
        for warning in system_data["recommendations"]["warnings"]:
            print(f"   🚨 {warning}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n🛑 Probe interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n💥 Probe failed: {e}")
        print(f"🔧 Traceback:\n{traceback.format_exc()}")
        sys.exit(1) 