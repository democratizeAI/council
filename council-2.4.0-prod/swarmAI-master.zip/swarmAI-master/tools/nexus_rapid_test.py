#!/usr/bin/env python3
"""
🔥💀⚔️ NEXUS RAPID TEST - SPRINT S-5 ADVANCED EVALUATION ⚔️💀🔥
================================================================
MISSION: Advanced grading system for Mistral-Large-tier accuracy
TARGET: Replace keyword scoring with semantic + unit tests + ROUGE-L
"""

import requests
import time
import json
import random
import re
import ast
import subprocess
import tempfile
import os
from typing import List, Dict, Any, Optional

# 🔥💀⚔️ SPRINT S-5: ADVANCED EVALUATION IMPORTS ⚔️💀🔥
try:
    from sentence_transformers import SentenceTransformer
    import numpy as np
    SEMANTIC_EVAL_AVAILABLE = True
    print("🧠 Semantic evaluation enabled!")
except ImportError:
    SEMANTIC_EVAL_AVAILABLE = False
    print("⚠️ Semantic evaluation disabled - install sentence-transformers for better accuracy")

try:
    import rouge_score
    from rouge_score import rouge_scorer
    ROUGE_AVAILABLE = True
    print("📊 ROUGE evaluation enabled!")
except ImportError:
    ROUGE_AVAILABLE = False
    print("⚠️ ROUGE evaluation disabled - install rouge-score for better accuracy")

class NexusRapidTester:
    """Advanced NEXUS testing with Sprint S-5 evaluation system"""
    
    def __init__(self, nexus_url: str = "http://localhost:8000/query"):
        self.nexus_url = nexus_url
        self.results = []
        
        # 🔥💀⚔️ SPRINT S-5: ADVANCED EVALUATION INITIALIZATION ⚔️💀🔥
        self.semantic_model = None
        self.rouge_scorer = None
        
        if SEMANTIC_EVAL_AVAILABLE:
            try:
                print("🧠 Loading semantic evaluation model...")
                self.semantic_model = SentenceTransformer('all-MiniLM-L6-v2')
                print("✅ Semantic model loaded!")
            except Exception as e:
                print(f"⚠️ Semantic model failed to load: {e}")
                
        if ROUGE_AVAILABLE:
            try:
                self.rouge_scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)
                print("✅ ROUGE scorer loaded!")
            except Exception as e:
                print(f"⚠️ ROUGE scorer failed to load: {e}")
    
    def semantic_similarity(self, text1: str, text2: str) -> float:
        """Calculate semantic similarity between two texts"""
        if not self.semantic_model or not text1.strip() or not text2.strip():
            return 0.0
        
        try:
            embeddings = self.semantic_model.encode([text1.lower(), text2.lower()])
            similarity = np.dot(embeddings[0], embeddings[1]) / (np.linalg.norm(embeddings[0]) * np.linalg.norm(embeddings[1]))
            return float(max(0.0, similarity))  # Ensure non-negative and convert to Python float
        except Exception:
            return 0.0
    
    def rouge_score(self, prediction: str, reference: str) -> float:
        """Calculate ROUGE-L score between prediction and reference"""
        if not self.rouge_scorer or not prediction.strip() or not reference.strip():
            return 0.0
        
        try:
            scores = self.rouge_scorer.score(reference, prediction)
            return float(scores['rougeL'].fmeasure)  # Convert to Python float
        except Exception:
            return 0.0
    
    def extract_code_from_response(self, text: str) -> Optional[str]:
        """Extract Python code from response text"""
        # Look for code blocks
        code_patterns = [
            r'```python\s*(.*?)\s*```',
            r'```\s*(.*?)\s*```', 
            r'def\s+\w+.*?(?=\n\n|\Z)',
            r'class\s+\w+.*?(?=\n\n|\Z)',
        ]
        
        for pattern in code_patterns:
            matches = re.findall(pattern, text, re.DOTALL | re.IGNORECASE)
            if matches:
                return matches[0].strip()
        
        # If no code blocks, return the whole response if it looks like code
        if any(keyword in text.lower() for keyword in ['def ', 'class ', 'import ', 'return ', 'if ', 'for ']):
            return text.strip()
        
        return None
    
    def test_code_execution(self, code: str, test_cases: List[Dict] = None) -> Dict[str, Any]:
        """Test code execution with optional test cases"""
        if not code:
            return {"success": False, "error": "No code provided"}
        
        try:
            # Create a temporary file
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(code)
                temp_file = f.name
            
            # Try to compile the code
            try:
                with open(temp_file, 'r') as f:
                    ast.parse(f.read())
                syntax_valid = True
                syntax_error = None
            except SyntaxError as e:
                syntax_valid = False
                syntax_error = str(e)
            
            # Try to execute basic test
            try:
                result = subprocess.run(
                    ['python', temp_file], 
                    capture_output=True, 
                    text=True, 
                    timeout=5
                )
                execution_success = result.returncode == 0
                execution_error = result.stderr if result.stderr else None
            except subprocess.TimeoutExpired:
                execution_success = False
                execution_error = "Execution timeout"
            except Exception as e:
                execution_success = False
                execution_error = str(e)
            
            # Clean up
            try:
                os.unlink(temp_file)
            except:
                pass
            
            return {
                "success": syntax_valid and execution_success,
                "syntax_valid": syntax_valid,
                "syntax_error": syntax_error,
                "execution_success": execution_success,
                "execution_error": execution_error
            }
            
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def evaluate_math_response(self, response: str, expected_values: List[str]) -> Dict[str, Any]:
        """Advanced evaluation for math responses"""
        # Extract numeric values from response
        numbers = re.findall(r'\b\d+\.?\d*\b', response)
        
        # Check for exact matches
        exact_match = any(expected in response.lower() for expected in [e.lower() for e in expected_values])
        
        # Check for numeric matches
        numeric_match = False
        if numbers and expected_values:
            try:
                response_nums = [float(n) for n in numbers]
                expected_nums = []
                for exp in expected_values:
                    try:
                        expected_nums.append(float(exp))
                    except:
                        continue
                
                for resp_num in response_nums:
                    for exp_num in expected_nums:
                        if abs(resp_num - exp_num) < 0.001:  # Close enough for floating point
                            numeric_match = True
                            break
            except:
                pass
        
        # Semantic similarity with expected values
        semantic_scores = []
        if self.semantic_model:
            for expected in expected_values:
                score = self.semantic_similarity(response, expected)
                semantic_scores.append(score)
        
        max_semantic = max(semantic_scores) if semantic_scores else 0.0
        
        return {
            "exact_match": exact_match,
            "numeric_match": numeric_match,
            "semantic_similarity": max_semantic,
            "overall_score": max(
                1.0 if exact_match else 0.0,
                1.0 if numeric_match else 0.0,
                max_semantic
            )
        }
    
    def evaluate_code_response(self, response: str, keywords: List[str]) -> Dict[str, Any]:
        """Advanced evaluation for code responses"""
        code = self.extract_code_from_response(response)
        
        # Test code execution
        execution_result = self.test_code_execution(code) if code else {"success": False}
        
        # Check for expected keywords/patterns
        keyword_score = 0.0
        if keywords:
            matched_keywords = sum(1 for kw in keywords if kw.lower() in response.lower())
            keyword_score = matched_keywords / len(keywords)
        
        # Semantic similarity for code quality
        semantic_score = 0.0
        if self.semantic_model and keywords:
            keyword_text = " ".join(keywords)
            semantic_score = self.semantic_similarity(response, keyword_text)
        
        return {
            "has_code": bool(code),
            "code_executes": execution_result.get("success", False),
            "syntax_valid": execution_result.get("syntax_valid", False),
            "keyword_score": keyword_score,
            "semantic_score": semantic_score,
            "overall_score": max(
                1.0 if execution_result.get("success", False) else 0.0,  # Only perfect score for execution
                0.8 if execution_result.get("syntax_valid", False) and keyword_score >= 0.5 else 0.0,
                0.6 if bool(code) and keyword_score >= 0.3 else 0.0,  # Code + keywords required
                keyword_score * 0.9 if keyword_score >= 0.7 else keyword_score * 0.5,  # High threshold
                semantic_score * 0.8 if semantic_score >= 0.7 else semantic_score * 0.4  # High threshold
            )
        }
    
    def evaluate_knowledge_response(self, response: str, expected_keywords: List[str]) -> Dict[str, Any]:
        """Advanced evaluation for knowledge responses using ROUGE-L"""
        # Traditional keyword matching
        keyword_score = 0.0
        if expected_keywords:
            matched = sum(1 for kw in expected_keywords if kw.lower() in response.lower())
            keyword_score = matched / len(expected_keywords)
        
        # ROUGE-L scoring
        rouge_scores = []
        if self.rouge_scorer and expected_keywords:
            for keyword in expected_keywords:
                rouge_score = self.rouge_score(response, keyword)
                rouge_scores.append(rouge_score)
        
        max_rouge = max(rouge_scores) if rouge_scores else 0.0
        
        # Semantic similarity
        semantic_scores = []
        if self.semantic_model and expected_keywords:
            for keyword in expected_keywords:
                semantic_score = self.semantic_similarity(response, keyword)
                semantic_scores.append(semantic_score)
        
        max_semantic = max(semantic_scores) if semantic_scores else 0.0
        
        return {
            "keyword_score": keyword_score,
            "rouge_score": max_rouge,
            "semantic_score": max_semantic,
            "overall_score": max(
                keyword_score * 0.9 if keyword_score >= 0.7 else keyword_score * 0.5,  # High threshold
                max_rouge * 1.0 if max_rouge >= 0.7 else max_rouge * 0.6,  # Tighter ROUGE
                max_semantic * 0.9 if max_semantic >= 0.7 else max_semantic * 0.5,  # Tighter semantic
                0.6 if keyword_score >= 0.5 and max_semantic >= 0.5 else 0.0  # Combined threshold
            )
        }
    
    def test_query(self, query: str, expected_keywords: List[str] = None, query_type: str = "general") -> Dict[str, Any]:
        """Test a single query against NEXUS with advanced Sprint S-5 evaluation"""
        start_time = time.time()
        
        try:
            response = requests.post(
                self.nexus_url,
                json={"query": query},
                timeout=15  # Increased timeout for complex operations
            )
            
            if response.status_code == 200:
                result = response.json()
                latency = (time.time() - start_time) * 1000
                
                # Basic response info
                success = result.get("success", False)
                text = result.get("text", "")
                method = result.get("method", "unknown")
                
                # Check for stub patterns
                is_stub = any(stub in text.lower() for stub in [
                    "todo", "implement", "placeholder", "processing query",
                    "unsupported", "not implemented", "stub", "fallback"
                ])
                
                # 🔥💀⚔️ SPRINT S-5: ADVANCED EVALUATION SYSTEM ⚔️💀🔥
                evaluation_result = {"overall_score": 0.0}
                
                if expected_keywords:
                    if query_type == "math":
                        evaluation_result = self.evaluate_math_response(text, expected_keywords)
                    elif query_type == "code":
                        evaluation_result = self.evaluate_code_response(text, expected_keywords)
                    elif query_type == "knowledge":
                        evaluation_result = self.evaluate_knowledge_response(text, expected_keywords)
                    else:
                        # Default: use knowledge evaluation (ROUGE + semantic)
                        evaluation_result = self.evaluate_knowledge_response(text, expected_keywords)
                
                # Advanced accuracy calculation
                advanced_score = evaluation_result.get("overall_score", 0.0)
                # 🔥 SPRINT S-5 FIX #6: TIGHTENED ACCURACY THRESHOLD
                accurate = success and not is_stub and advanced_score >= 0.7  # Stricter threshold
                
                # Legacy keyword check for backward compatibility
                has_expected = True
                if expected_keywords:
                    has_expected = any(keyword.lower() in text.lower() for keyword in expected_keywords)
                
                return {
                    "query": query,
                    "success": success,
                    "text": text,
                    "method": method,
                    "latency_ms": latency,
                    "is_stub": is_stub,
                    "has_expected": has_expected,
                    "accurate": accurate,
                    "query_type": query_type,
                    # Sprint S-5 advanced metrics
                    "evaluation": evaluation_result,
                    "advanced_score": advanced_score,
                    "confidence": min(1.0, advanced_score + (0.2 if success else 0.0))
                }
            else:
                return {
                    "query": query,
                    "success": False,
                    "text": f"HTTP {response.status_code}",
                    "method": "http_error",
                    "latency_ms": (time.time() - start_time) * 1000,
                    "is_stub": True,
                    "has_expected": False,
                    "accurate": False,
                    "query_type": query_type,
                    "evaluation": {"overall_score": 0.0},
                    "advanced_score": 0.0,
                    "confidence": 0.0
                }
                
        except Exception as e:
            return {
                "query": query,
                "success": False,
                "text": f"Error: {e}",
                "method": "exception",
                "latency_ms": (time.time() - start_time) * 1000,
                "is_stub": True,
                "has_expected": False,
                "accurate": False,
                "query_type": query_type,
                "evaluation": {"overall_score": 0.0},
                "advanced_score": 0.0,
                "confidence": 0.0
            }
    
    def calculate_confidence_interval(self, accuracy: float, n: int, confidence_level: float = 0.95) -> tuple:
        """Calculate Wilson score confidence interval for accuracy"""
        if n == 0:
            return (0.0, 0.0)
        
        try:
            import math
            z = 1.96 if confidence_level == 0.95 else 2.576  # 95% or 99%
            
            # Wilson score interval
            p = accuracy
            factor = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n)
            denominator = 1 + z * z / n
            center = (p + z * z / (2 * n)) / denominator
            
            lower = max(0.0, (center - factor / denominator))
            upper = min(1.0, (center + factor / denominator))
            
            return (lower, upper)
        except:
            return (accuracy, accuracy)
    
    def run_math_block(self, limit: int = 20) -> Dict[str, Any]:
        """Test math queries"""
        print("🧮 TESTING MATH BLOCK...")
        
        math_queries = [
            ("Calculate 15!", ["5040", "factorial"]),
            ("What is 30% of 150?", ["45", "percentage"]),
            ("Compute 5^4", ["625", "exponent"]),
            ("What is 12 * 8 * 3?", ["288", "product"]),
            ("Find 20% of 500", ["100", "percentage"]),
            ("Calculate 2^8", ["256", "exponent"]),
            ("What is 9! factorial?", ["362880", "factorial"]),
            ("Compute 75% of 200", ["150", "percentage"]),
            ("What is 6*7*8?", ["336", "product"]),
            ("Calculate 3^6", ["729", "exponent"]),
            ("What is 25% of 80?", ["20", "percentage"]),
            ("Find 4! factorial", ["24", "factorial"]),
            ("Compute 10^3", ["1000", "exponent"]),
            ("What is 15*12?", ["180", "product"]),
            ("Calculate 60% of 250", ["150", "percentage"]),
            ("What is 7^2?", ["49", "exponent"]),
            ("Find 8! exactly", ["40320", "factorial"]),
            ("What is 5*9*2?", ["90", "product"]),
            ("Calculate 40% of 75", ["30", "percentage"]),
            ("Compute 2^12", ["4096", "exponent"])
        ]
        
        results = []
        for i, (query, keywords) in enumerate(math_queries[:limit]):
            if i % 5 == 0:
                print(f"   Progress: {i}/{min(limit, len(math_queries))}")
            
            result = self.test_query(query, keywords, "math")
            results.append(result)
            
            # Show failures immediately
            if not result["accurate"]:
                print(f"   ❌ FAIL: {query[:30]}... → {result['text'][:50]}...")
        
        accuracy = sum(1 for r in results if r["accurate"]) / len(results)
        avg_latency = sum(r["latency_ms"] for r in results) / len(results)
        
        return {
            "block": "math",
            "accuracy": accuracy,
            "avg_latency_ms": avg_latency,
            "total_queries": len(results),
            "results": results
        }
    
    def run_code_block(self, limit: int = 15) -> Dict[str, Any]:
        """Test code generation queries"""
        print("💻 TESTING CODE BLOCK...")
        
        code_queries = [
            ("Write a Python function to reverse a string", ["def", "reverse", "return"]),
            ("Create a function to check if a number is prime", ["def", "prime", "return"]),
            ("Write a binary search function", ["def", "binary", "search"]),
            ("Create a quick sort algorithm", ["def", "sort", "pivot"]),
            ("Write a function to find GCD", ["def", "gcd", "return"]),
            ("Create a stack data structure", ["class", "stack", "push", "pop"]),
            ("Write a function to merge two sorted lists", ["def", "merge", "return"]),
            ("Create a queue implementation", ["class", "queue", "enqueue"]),
            ("Write a function to validate parentheses", ["def", "valid", "return"]),
            ("Create a fibonacci function", ["def", "fibonacci", "return"]),
            ("Write a function to find maximum subarray", ["def", "max", "return"]),
            ("Create a hash table implementation", ["class", "hash", "table"]),
            ("Write a depth-first search function", ["def", "dfs", "return"]),
            ("Create a breadth-first search", ["def", "bfs", "queue"]),
            ("Write a function to rotate an array", ["def", "rotate", "return"])
        ]
        
        results = []
        for i, (query, keywords) in enumerate(code_queries[:limit]):
            if i % 5 == 0:
                print(f"   Progress: {i}/{min(limit, len(code_queries))}")
            
            result = self.test_query(query, keywords, "code")
            results.append(result)
            
            # Show failures immediately
            if not result["accurate"]:
                print(f"   ❌ FAIL: {query[:30]}... → {result['text'][:50]}...")
        
        accuracy = sum(1 for r in results if r["accurate"]) / len(results)
        avg_latency = sum(r["latency_ms"] for r in results) / len(results)
        
        return {
            "block": "code",
            "accuracy": accuracy,
            "avg_latency_ms": avg_latency,
            "total_queries": len(results),
            "results": results
        }
    
    def run_knowledge_block(self, limit: int = 10) -> Dict[str, Any]:
        """Test knowledge/factual queries"""
        print("📚 TESTING KNOWLEDGE BLOCK...")
        
        knowledge_queries = [
            ("What year was the Transformer architecture introduced?", ["2017", "vaswani"]),
            ("Which optimizer is commonly used for large language models?", ["adamw", "adam"]),
            ("What is the context length of GPT-3.5?", ["4096", "tokens"]),
            ("Who invented the attention mechanism?", ["bahdanau", "attention"]),
            ("What is the capital of France?", ["paris"]),
            ("When was Python first released?", ["1991", "python"]),
            ("What is the largest planet in our solar system?", ["jupiter"]),
            ("Who wrote the novel '1984'?", ["orwell", "george"]),
            ("What is the speed of light?", ["299792458", "light"]),
            ("What is the chemical formula for water?", ["h2o", "water"])
        ]
        
        results = []
        for i, (query, keywords) in enumerate(knowledge_queries[:limit]):
            if i % 3 == 0:
                print(f"   Progress: {i}/{min(limit, len(knowledge_queries))}")
            
            result = self.test_query(query, keywords, "knowledge")
            results.append(result)
            
            # Show failures immediately
            if not result["accurate"]:
                print(f"   ❌ FAIL: {query[:30]}... → {result['text'][:50]}...")
        
        accuracy = sum(1 for r in results if r["accurate"]) / len(results)
        avg_latency = sum(r["latency_ms"] for r in results) / len(results)
        
        return {
            "block": "knowledge",
            "accuracy": accuracy,
            "avg_latency_ms": avg_latency,
            "total_queries": len(results),
            "results": results
        }
    
    def run_logic_block(self, limit: int = 10) -> Dict[str, Any]:
        """Test logical reasoning queries"""
        print("🧠 TESTING LOGIC BLOCK...")
        
        logic_queries = [
            ("If A > B and B > C, what can we conclude about A and C?", ["greater", "transitive"]),
            ("A job starts at 09:00 and takes 6 hours. Another job starts 2 hours after the first finishes and needs 4 hours. When does the second job end?", ["17:00", "19:00"]),
            ("If all cats are mammals and all mammals are animals, are all cats animals?", ["yes", "true"]),
            ("What comes next in the sequence: 2, 4, 8, 16, ?", ["32"]),
            ("If it's raining, then the ground is wet. The ground is wet. Is it raining?", ["maybe", "not necessarily"]),
            ("A train leaves at 10:00 traveling 60 mph. Another leaves at 11:00 traveling 80 mph in the same direction. When do they meet?", ["never", "80", "faster"]),
            ("If P implies Q, and Q implies R, what can we conclude about P and R?", ["implies", "transitive"]),
            ("What is the missing number: 1, 1, 2, 3, 5, 8, ?", ["13", "fibonacci"]),
            ("If all programmers drink coffee and John is a programmer, does John drink coffee?", ["yes", "true"]),
            ("A clock shows 3:15. What is the angle between the hour and minute hands?", ["7.5", "degrees"])
        ]
        
        results = []
        for i, (query, keywords) in enumerate(logic_queries[:limit]):
            if i % 3 == 0:
                print(f"   Progress: {i}/{min(limit, len(logic_queries))}")
            
            result = self.test_query(query, keywords, "logic")
            results.append(result)
            
            # Show failures immediately
            if not result["accurate"]:
                print(f"   ❌ FAIL: {query[:30]}... → {result['text'][:50]}...")
        
        accuracy = sum(1 for r in results if r["accurate"]) / len(results)
        avg_latency = sum(r["latency_ms"] for r in results) / len(results)
        
        return {
            "block": "logic",
            "accuracy": accuracy,
            "avg_latency_ms": avg_latency,
            "total_queries": len(results),
            "results": results
        }
    
    def run_full_test(self, math_limit: int = 20, code_limit: int = 15, 
                     knowledge_limit: int = 10, logic_limit: int = 10) -> Dict[str, Any]:
        """Run full NEXUS rapid test with Sprint S-5 advanced evaluation"""
        
        print("🔥💀⚔️ NEXUS SPRINT S-5 ADVANCED EVALUATION TEST ⚔️💀🔥")
        print("=" * 70)
        
        start_time = time.time()
        
        # Test each block
        math_results = self.run_math_block(math_limit)
        code_results = self.run_code_block(code_limit)
        knowledge_results = self.run_knowledge_block(knowledge_limit)
        logic_results = self.run_logic_block(logic_limit)
        
        total_time = time.time() - start_time
        
        # Calculate overall metrics
        all_results = (
            math_results["results"] + 
            code_results["results"] + 
            knowledge_results["results"] + 
            logic_results["results"]
        )
        
        total_queries = len(all_results)
        total_accurate = sum(1 for r in all_results if r["accurate"])
        overall_accuracy = total_accurate / total_queries if total_queries > 0 else 0.0
        overall_latency = sum(r["latency_ms"] for r in all_results) / total_queries if total_queries > 0 else 0.0
        
        # 🔥💀⚔️ SPRINT S-5: ADVANCED METRICS ⚔️💀🔥
        # Advanced scoring
        advanced_scores = [r.get("advanced_score", 0.0) for r in all_results]
        advanced_accuracy = sum(advanced_scores) / len(advanced_scores) if advanced_scores else 0.0
        
        # Confidence intervals
        accuracy_ci = self.calculate_confidence_interval(overall_accuracy, total_queries)
        advanced_ci = self.calculate_confidence_interval(advanced_accuracy, total_queries)
        
        # Method breakdown
        method_counts = {}
        for result in all_results:
            method = result.get("method", "unknown")
            method_counts[method] = method_counts.get(method, 0) + 1
        
        # Identify stub patterns
        stub_count = sum(1 for r in all_results if r["is_stub"])
        
        print("\n🔥💀⚔️ SPRINT S-5 ADVANCED TEST RESULTS ⚔️💀🔥")
        print("=" * 70)
        print(f"⚡ BASIC ACCURACY: {overall_accuracy:.1%} ({total_accurate}/{total_queries})")
        print(f"⚡ ADVANCED ACCURACY: {advanced_accuracy:.1%} (semantic + execution)")
        print(f"⚡ AVERAGE LATENCY: {overall_latency:.1f}ms")
        print(f"⚡ TOTAL TEST TIME: {total_time:.1f}s")
        print(f"🚨 STUB COUNT: {stub_count}/{total_queries}")
        print()
        print("📊 CONFIDENCE INTERVALS (95%):")
        print(f"   Basic: {accuracy_ci[0]:.1%} - {accuracy_ci[1]:.1%}")
        print(f"   Advanced: {advanced_ci[0]:.1%} - {advanced_ci[1]:.1%}")
        print()
        print("📊 BLOCK BREAKDOWN:")
        print(f"   🧮 Math:      {math_results['accuracy']:.1%} ({math_limit} queries)")
        print(f"   💻 Code:      {code_results['accuracy']:.1%} ({code_limit} queries)")
        print(f"   📚 Knowledge: {knowledge_results['accuracy']:.1%} ({knowledge_limit} queries)")
        print(f"   🧠 Logic:     {logic_results['accuracy']:.1%} ({logic_limit} queries)")
        print()
        print("🔧 METHOD BREAKDOWN:")
        for method, count in sorted(method_counts.items(), key=lambda x: x[1], reverse=True):
            percentage = (count / total_queries) * 100
            print(f"   {method}: {count} ({percentage:.1f}%)")
        
        # Sprint S-5 Performance Assessment
        print("\n🎯 SPRINT S-5 PERFORMANCE ASSESSMENT:")
        if advanced_accuracy >= 0.92:
            print("🟢 MISTRAL-LARGE-TIER ACHIEVED! (≥92%)")
        elif advanced_accuracy >= 0.88:
            print("🟡 APPROACHING MISTRAL-LARGE-TIER (88-92%)")
        else:
            print("🔴 BELOW MISTRAL-LARGE-TIER (<88%)")
        
        return {
            "overall_accuracy": overall_accuracy,
            "advanced_accuracy": advanced_accuracy,
            "overall_latency_ms": overall_latency,
            "total_test_time_s": total_time,
            "stub_count": stub_count,
            "total_queries": total_queries,
            "confidence_intervals": {
                "basic": accuracy_ci,
                "advanced": advanced_ci
            },
            "method_breakdown": method_counts,
            "blocks": {
                "math": math_results,
                "code": code_results,
                "knowledge": knowledge_results,
                "logic": logic_results
            },
            "all_results": all_results,
            "sprint_s5_tier": (
                "mistral_large" if advanced_accuracy >= 0.92 else
                "approaching" if advanced_accuracy >= 0.88 else
                "below_target"
            )
        }

def main():
    """Run NEXUS rapid test"""
    import argparse
    
    parser = argparse.ArgumentParser(description="NEXUS Rapid Test")
    parser.add_argument("--math", type=int, default=20, help="Math queries to test")
    parser.add_argument("--code", type=int, default=15, help="Code queries to test") 
    parser.add_argument("--knowledge", type=int, default=10, help="Knowledge queries to test")
    parser.add_argument("--logic", type=int, default=10, help="Logic queries to test")
    parser.add_argument("--url", default="http://localhost:8000/query", help="NEXUS URL")
    
    args = parser.parse_args()
    
    tester = NexusRapidTester(args.url)
    results = tester.run_full_test(args.math, args.code, args.knowledge, args.logic)
    
    # Save results
    with open("nexus_rapid_test_results.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\n💾 Results saved to nexus_rapid_test_results.json")

if __name__ == "__main__":
    main() 