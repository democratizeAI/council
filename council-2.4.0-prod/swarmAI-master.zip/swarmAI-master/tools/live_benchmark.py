#!/usr/bin/env python3
"""
🔥💀⚡ LIVE BENCHMARK - Real-time swarm telemetry capture
========================================================

Runs mixed workload benchmark while capturing real-time metrics.
Critical for verifying RTX 4070 performance under load.

Usage:
    python tools/live_benchmark.py --duration 60
    python tools/live_benchmark.py --duration 60 --capture-interval 2
"""

import asyncio
import json
import requests
import subprocess
import sys
import time
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from typing import Dict, List, Any
import argparse

# Test queries for mixed benchmark
BENCHMARK_QUERIES = [
    # Math queries (dimensional agents)
    {"query": "What is 15 * 23 + 87?", "expected_category": "math"},
    {"query": "Calculate the square root of 144", "expected_category": "math"}, 
    {"query": "What is 2^8?", "expected_category": "math"},
    
    # Code queries
    {"query": "Write a Python function to reverse a string", "expected_category": "code"},
    {"query": "How do I sort a list in Python?", "expected_category": "code"},
    {"query": "Create a for loop that prints numbers 1 to 10", "expected_category": "code"},
    
    # Knowledge queries  
    {"query": "What is the capital of France?", "expected_category": "knowledge"},
    {"query": "Who wrote Romeo and Juliet?", "expected_category": "knowledge"},
    {"query": "What is photosynthesis?", "expected_category": "knowledge"},
    
    # Logic/reasoning queries
    {"query": "If all birds can fly and penguins are birds, can penguins fly?", "expected_category": "logic"},
    {"query": "What comes next in the sequence: 2, 4, 8, 16, ?", "expected_category": "logic"},
    {"query": "Explain the logical fallacy in this statement", "expected_category": "logic"},
    
    # Casual conversation (should be handled locally)
    {"query": "Hey there!", "expected_category": "casual"},
    {"query": "How are you doing?", "expected_category": "casual"},
    {"query": "Good morning!", "expected_category": "casual"},
]

class SystemMonitor:
    """Real-time system monitoring"""
    
    def __init__(self, capture_interval: float = 1.0):
        self.capture_interval = capture_interval
        self.monitoring = False
        self.telemetry_data = []
        
    def start_monitoring(self):
        """Start monitoring in background thread"""
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop)
        self.monitor_thread.start()
        
    def stop_monitoring(self):
        """Stop monitoring and return collected data"""
        self.monitoring = False
        if hasattr(self, 'monitor_thread'):
            self.monitor_thread.join()
        return self.telemetry_data
        
    def _monitor_loop(self):
        """Main monitoring loop"""
        while self.monitoring:
            try:
                telemetry = self._capture_telemetry()
                telemetry['timestamp'] = time.time()
                self.telemetry_data.append(telemetry)
                time.sleep(self.capture_interval)
            except Exception as e:
                print(f"⚠️ Monitoring error: {e}")
                
    def _capture_telemetry(self) -> Dict[str, Any]:
        """Capture current system state"""
        telemetry = {
            "nvidia_smi": None,
            "htop_summary": None,
            "process_info": None
        }
        
        # NVIDIA GPU info
        try:
            result = subprocess.run([
                "nvidia-smi", "--query-gpu=name,memory.total,memory.free,memory.used,utilization.gpu,temperature.gpu,power.draw",
                "--format=csv,noheader,nounits"
            ], capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                if lines:
                    parts = [p.strip() for p in lines[0].split(',')]
                    if len(parts) >= 7:
                        telemetry["nvidia_smi"] = {
                            "name": parts[0],
                            "memory_total_mb": int(parts[1]) if parts[1].isdigit() else 0,
                            "memory_free_mb": int(parts[2]) if parts[2].isdigit() else 0,
                            "memory_used_mb": int(parts[3]) if parts[3].isdigit() else 0,
                            "gpu_utilization": int(parts[4]) if parts[4].isdigit() else 0,
                            "temperature_c": int(parts[5]) if parts[5].isdigit() else 0,
                            "power_draw_w": float(parts[6]) if parts[6].replace('.', '').isdigit() else 0
                        }
        except Exception as e:
            telemetry["nvidia_smi_error"] = str(e)
            
        # CPU and memory info via htop-like command
        try:
            # Use ps for cross-platform compatibility
            result = subprocess.run([
                "ps", "aux", "--sort=-%cpu"
            ], capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:
                    # Find Python processes (likely our swarm)
                    python_processes = []
                    for line in lines[1:11]:  # Top 10 processes
                        if 'python' in line.lower() or 'serve.py' in line:
                            parts = line.split()
                            if len(parts) >= 11:
                                python_processes.append({
                                    "pid": parts[1],
                                    "cpu_percent": parts[2],
                                    "memory_percent": parts[3],
                                    "command": ' '.join(parts[10:])[:50]
                                })
                    
                    telemetry["process_info"] = {
                        "python_processes": python_processes,
                        "total_processes": len(lines) - 1
                    }
        except Exception as e:
            telemetry["process_info_error"] = str(e)
            
        # Memory info
        try:
            result = subprocess.run([
                "free", "-m"
            ], capture_output=True, text=True, timeout=5)
            
            if result.returncode == 0:
                lines = result.stdout.strip().split('\n')
                for line in lines:
                    if line.startswith('Mem:'):
                        parts = line.split()
                        if len(parts) >= 7:
                            telemetry["memory"] = {
                                "total_mb": int(parts[1]),
                                "used_mb": int(parts[2]),
                                "free_mb": int(parts[3]),
                                "available_mb": int(parts[6]) if len(parts) > 6 else int(parts[3])
                            }
                        break
        except Exception:
            # Try alternative for Windows/Mac
            try:
                import psutil
                memory = psutil.virtual_memory()
                telemetry["memory"] = {
                    "total_mb": int(memory.total / 1024 / 1024),
                    "used_mb": int(memory.used / 1024 / 1024),
                    "free_mb": int(memory.available / 1024 / 1024),
                    "available_mb": int(memory.available / 1024 / 1024)
                }
            except Exception as e:
                telemetry["memory_error"] = str(e)
                
        return telemetry

class SwarmBenchmark:
    """Benchmark runner for swarm performance"""
    
    def __init__(self, serve_url: str = "http://localhost:8000"):
        self.serve_url = serve_url
        self.results = []
        
    async def run_benchmark(self, duration_seconds: int, concurrent_requests: int = 4):
        """Run mixed benchmark for specified duration"""
        print(f"🚀 Starting {duration_seconds}s benchmark with {concurrent_requests} concurrent requests")
        
        start_time = time.time()
        query_count = 0
        
        # Use ThreadPoolExecutor for concurrent requests
        with ThreadPoolExecutor(max_workers=concurrent_requests) as executor:
            futures = []
            
            while time.time() - start_time < duration_seconds:
                # Submit requests up to concurrency limit
                while len(futures) < concurrent_requests and time.time() - start_time < duration_seconds:
                    query = BENCHMARK_QUERIES[query_count % len(BENCHMARK_QUERIES)]
                    future = executor.submit(self._execute_query, query, query_count)
                    futures.append(future)
                    query_count += 1
                    
                # Check for completed requests
                completed_futures = [f for f in futures if f.done()]
                for future in completed_futures:
                    try:
                        result = future.result()
                        self.results.append(result)
                    except Exception as e:
                        print(f"❌ Query failed: {e}")
                    futures.remove(future)
                    
                await asyncio.sleep(0.1)  # Small delay to prevent spinning
                
            # Wait for remaining requests
            for future in futures:
                try:
                    result = future.result(timeout=10)
                    self.results.append(result)
                except Exception as e:
                    print(f"❌ Final query failed: {e}")
        
        print(f"✅ Benchmark complete: {len(self.results)} queries processed")
        return self.results
        
    def _execute_query(self, query_info: Dict, query_id: int) -> Dict[str, Any]:
        """Execute single query and measure performance"""
        start_time = time.time()
        
        try:
            # Test both chat integration and direct serve endpoints
            if query_info.get("expected_category") == "casual":
                # Try chat integration first
                response = requests.post(
                    f"{self.serve_url}/chat", 
                    json={"message": query_info["query"]},
                    timeout=30
                )
            else:
                # Use direct query endpoint
                response = requests.post(
                    f"{self.serve_url}/query",
                    json={"query": query_info["query"]},
                    timeout=30
                )
                
            end_time = time.time()
            latency_ms = (end_time - start_time) * 1000
            
            if response.status_code == 200:
                result_data = response.json()
                
                # Extract metrics if available
                metrics = {}
                if isinstance(result_data, dict):
                    metrics = {
                        "prompt_tokens": result_data.get("prompt_tokens", 0),
                        "completion_tokens": result_data.get("completion_tokens", 0),
                        "real_toks_per_sec": result_data.get("real_toks_per_sec", 0),
                        "gpu_vram_mb": result_data.get("gpu_vram_mb", 0),
                        "memory_hits": result_data.get("memory_hits", 0),
                        "model_used": result_data.get("model_used", "unknown"),
                        "category": result_data.get("category", "unknown")
                    }
                
                return {
                    "query_id": query_id,
                    "query": query_info["query"],
                    "expected_category": query_info["expected_category"],
                    "success": True,
                    "latency_ms": latency_ms,
                    "status_code": response.status_code,
                    "response_length": len(str(result_data)),
                    "timestamp": end_time,
                    "metrics": metrics,
                    "response_preview": str(result_data)[:200]
                }
            else:
                return {
                    "query_id": query_id,
                    "query": query_info["query"],
                    "expected_category": query_info["expected_category"],
                    "success": False,
                    "latency_ms": latency_ms,
                    "status_code": response.status_code,
                    "error": response.text[:200],
                    "timestamp": end_time
                }
                
        except Exception as e:
            end_time = time.time()
            latency_ms = (end_time - start_time) * 1000
            
            return {
                "query_id": query_id,
                "query": query_info["query"],
                "expected_category": query_info["expected_category"],
                "success": False,
                "latency_ms": latency_ms,
                "error": str(e),
                "timestamp": end_time
            }

async def main():
    """Main benchmark execution"""
    parser = argparse.ArgumentParser(description="Live swarm benchmark with telemetry")
    parser.add_argument("--duration", type=int, default=60, help="Benchmark duration in seconds")
    parser.add_argument("--capture-interval", type=float, default=1.0, help="Telemetry capture interval")
    parser.add_argument("--concurrent", type=int, default=4, help="Concurrent requests")
    parser.add_argument("--serve-url", default="http://localhost:8000", help="Swarm serve URL")
    parser.add_argument("--output", default="live_benchmark_results.json", help="Output file")
    
    args = parser.parse_args()
    
    print("🔥💀⚡ LIVE SWARM BENCHMARK")
    print("=" * 50)
    print(f"📊 Duration: {args.duration}s")
    print(f"⚡ Concurrent requests: {args.concurrent}")
    print(f"📡 Telemetry interval: {args.capture_interval}s")
    print(f"🎯 Target: {args.serve_url}")
    
    # Test connection first
    try:
        response = requests.get(f"{args.serve_url}/health", timeout=5)
        if response.status_code == 200:
            print("✅ Swarm connection verified")
        else:
            print(f"⚠️ Swarm health check returned {response.status_code}")
    except Exception as e:
        print(f"❌ Cannot connect to swarm: {e}")
        print("💡 Make sure 'python serve.py' is running")
        return
    
    # Start system monitoring
    monitor = SystemMonitor(args.capture_interval)
    monitor.start_monitoring()
    
    # Run benchmark
    benchmark = SwarmBenchmark(args.serve_url)
    start_time = time.time()
    
    try:
        print(f"\n🚀 Starting benchmark...")
        query_results = await benchmark.run_benchmark(args.duration, args.concurrent)
    finally:
        telemetry_data = monitor.stop_monitoring()
    
    end_time = time.time()
    total_duration = end_time - start_time
    
    # Analyze results
    successful_queries = [r for r in query_results if r.get("success", False)]
    failed_queries = [r for r in query_results if not r.get("success", False)]
    
    if successful_queries:
        avg_latency = sum(r["latency_ms"] for r in successful_queries) / len(successful_queries)
        min_latency = min(r["latency_ms"] for r in successful_queries)
        max_latency = max(r["latency_ms"] for r in successful_queries)
    else:
        avg_latency = min_latency = max_latency = 0
    
    # Generate summary
    summary = {
        "benchmark_info": {
            "duration_requested_s": args.duration,
            "duration_actual_s": total_duration,
            "concurrent_requests": args.concurrent,
            "capture_interval_s": args.capture_interval,
            "timestamp": datetime.now().isoformat()
        },
        "performance_summary": {
            "total_queries": len(query_results),
            "successful_queries": len(successful_queries),
            "failed_queries": len(failed_queries),
            "success_rate_percent": (len(successful_queries) / len(query_results) * 100) if query_results else 0,
            "queries_per_second": len(query_results) / total_duration,
            "avg_latency_ms": avg_latency,
            "min_latency_ms": min_latency,
            "max_latency_ms": max_latency
        },
        "telemetry_summary": {
            "telemetry_points": len(telemetry_data),
            "monitoring_duration_s": total_duration
        },
        "query_results": query_results,
        "telemetry_data": telemetry_data
    }
    
    # Add GPU summary if available
    if telemetry_data:
        gpu_data = [t.get("nvidia_smi") for t in telemetry_data if t.get("nvidia_smi")]
        if gpu_data:
            summary["gpu_summary"] = {
                "avg_vram_used_mb": sum(d["memory_used_mb"] for d in gpu_data) / len(gpu_data),
                "max_vram_used_mb": max(d["memory_used_mb"] for d in gpu_data),
                "avg_gpu_utilization": sum(d["gpu_utilization"] for d in gpu_data) / len(gpu_data),
                "max_temperature_c": max(d["temperature_c"] for d in gpu_data),
                "avg_power_draw_w": sum(d["power_draw_w"] for d in gpu_data) / len(gpu_data)
            }
    
    # Print summary
    print(f"\n📊 BENCHMARK RESULTS")
    print("-" * 30)
    print(f"🎯 Queries: {len(query_results)} total, {len(successful_queries)} successful ({summary['performance_summary']['success_rate_percent']:.1f}%)")
    print(f"⚡ Throughput: {summary['performance_summary']['queries_per_second']:.1f} queries/sec")
    print(f"⏱️ Latency: {avg_latency:.1f}ms avg, {min_latency:.1f}ms min, {max_latency:.1f}ms max")
    
    if "gpu_summary" in summary:
        gpu = summary["gpu_summary"]
        print(f"🎮 GPU: {gpu['avg_vram_used_mb']:.0f}MB VRAM avg, {gpu['max_vram_used_mb']:.0f}MB peak")
        print(f"🔥 Utilization: {gpu['avg_gpu_utilization']:.1f}% GPU avg, {gpu['max_temperature_c']:.0f}°C max temp")
    
    print(f"📡 Telemetry: {len(telemetry_data)} data points captured")
    
    # Save results
    with open(args.output, 'w') as f:
        json.dump(summary, f, indent=2, default=str)
    
    print(f"\n💾 Results saved to: {args.output}")
    print("\n🎯 Key files for tuning:")
    print(f"   📊 Benchmark results: {args.output}")
    print(f"   🔧 System probe: python tools/system_probe.py")
    print(f"   📋 Models config: config/models_rtx4070.yaml")

if __name__ == "__main__":
    asyncio.run(main()) 