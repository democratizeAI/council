#!/usr/bin/env python3
"""
🔥💀⚡ INSTRUMENTED TRACE - 10-turn chat with detailed metrics
============================================================

Generates a comprehensive chat trace showing metrics fields.
Critical for validating context-compression and RTX 4070 performance.

Usage:
    python tools/instrumented_trace.py
    python tools/instrumented_trace.py --output instrumented_chat_trace.json
"""

import json
import requests
import time
import sys
from datetime import datetime
from typing import Dict, List, Any
import argparse

# Conversation flow for instrumented trace
CONVERSATION_TURNS = [
    {
        "turn": 1,
        "user": "Hello! I need help with some math problems.",
        "expected_category": "casual",
        "context": "Initial greeting"
    },
    {
        "turn": 2,
        "user": "What is 25 * 16?",
        "expected_category": "math",
        "context": "Simple arithmetic - should use dimensional agent"
    },
    {
        "turn": 3,
        "user": "Now calculate the square root of that result.",
        "expected_category": "math",
        "context": "Follow-up calculation using previous result"
    },
    {
        "turn": 4,
        "user": "Can you write a Python function to calculate factorials?",
        "expected_category": "code",
        "context": "Switch to code generation - should route to code specialist"
    },
    {
        "turn": 5,
        "user": "What's the factorial of 5 using that function?",
        "expected_category": "code",
        "context": "Code execution request - tests code understanding"
    },
    {
        "turn": 6,
        "user": "Who invented the factorial notation?",
        "expected_category": "knowledge",
        "context": "Historical knowledge query - should route to knowledge specialist"
    },
    {
        "turn": 7,
        "user": "If I have 5 books and want to arrange them on a shelf, how many ways can I do this?",
        "expected_category": "math",
        "context": "Combinatorics - tests cross-domain knowledge"
    },
    {
        "turn": 8,
        "user": "Explain the logical reasoning behind that calculation.",
        "expected_category": "logic",
        "context": "Logic explanation - should route to logic specialist"
    },
    {
        "turn": 9,
        "user": "Great! This has been very helpful.",
        "expected_category": "casual",
        "context": "Casual positive feedback"
    },
    {
        "turn": 10,
        "user": "Can you summarize what we discussed and show the mathematical relationship between factorials and permutations?",
        "expected_category": "reasoning",
        "context": "Complex synthesis - tests memory and reasoning"
    }
]

class InstrumentedChat:
    """Instrumented chat session with detailed metrics capture"""
    
    def __init__(self, serve_url: str = "http://localhost:8000"):
        self.serve_url = serve_url
        self.conversation_history = []
        self.session_metrics = {
            "start_time": time.time(),
            "total_turns": 0,
            "total_tokens": 0,
            "total_latency_ms": 0,
            "models_used": set(),
            "categories_hit": set(),
            "memory_interactions": 0
        }
        
    def execute_conversation(self) -> Dict[str, Any]:
        """Execute the full instrumented conversation"""
        print("🔥💀⚡ INSTRUMENTED CHAT TRACE")
        print("=" * 50)
        
        for turn_info in CONVERSATION_TURNS:
            print(f"\n🔄 Turn {turn_info['turn']}: {turn_info['context']}")
            
            turn_result = self._execute_turn(turn_info)
            self.conversation_history.append(turn_result)
            
            # Update session metrics
            self._update_session_metrics(turn_result)
            
            # Brief pause between turns
            time.sleep(0.5)
        
        # Finalize session metrics
        self.session_metrics["end_time"] = time.time()
        self.session_metrics["session_duration_s"] = self.session_metrics["end_time"] - self.session_metrics["start_time"]
        self.session_metrics["models_used"] = list(self.session_metrics["models_used"])
        self.session_metrics["categories_hit"] = list(self.session_metrics["categories_hit"])
        
        return {
            "session_info": {
                "timestamp": datetime.now().isoformat(),
                "conversation_type": "instrumented_trace",
                "total_turns": len(self.conversation_history),
                "trace_version": "1.0.0"
            },
            "session_metrics": self.session_metrics,
            "conversation_history": self.conversation_history
        }
    
    def _execute_turn(self, turn_info: Dict) -> Dict[str, Any]:
        """Execute a single conversation turn with full instrumentation"""
        turn_start = time.time()
        
        turn_result = {
            "turn_number": turn_info["turn"],
            "user_input": turn_info["user"],
            "expected_category": turn_info["expected_category"],
            "context": turn_info["context"],
            "timestamp": turn_start,
            "metrics": {},
            "response": None,
            "error": None,
            "routing_decision": None,
            "performance": {}
        }
        
        try:
            # Determine endpoint based on expected category
            if turn_info["expected_category"] == "casual":
                endpoint = f"{self.serve_url}/chat"
                payload = {"message": turn_info["user"]}
            else:
                endpoint = f"{self.serve_url}/query"
                payload = {"query": turn_info["user"]}
            
            # Add conversation context if we have history
            if self.conversation_history:
                payload["context"] = self._build_context()
            
            print(f"   🎯 Routing to: {endpoint}")
            print(f"   📝 Query: {turn_info['user'][:50]}...")
            
            # Execute request with timing
            request_start = time.time()
            response = requests.post(endpoint, json=payload, timeout=30)
            request_end = time.time()
            
            turn_result["performance"]["request_latency_ms"] = (request_end - request_start) * 1000
            turn_result["performance"]["status_code"] = response.status_code
            
            if response.status_code == 200:
                response_data = response.json()
                turn_result["response"] = response_data
                
                # Extract detailed metrics
                if isinstance(response_data, dict):
                    turn_result["metrics"] = {
                        "prompt_tokens": response_data.get("prompt_tokens", 0),
                        "completion_tokens": response_data.get("completion_tokens", 0),
                        "total_tokens": response_data.get("total_tokens", 0),
                        "real_toks_per_sec": response_data.get("real_toks_per_sec", 0),
                        "gpu_vram_mb": response_data.get("gpu_vram_mb", 0),
                        "memory_hits": response_data.get("memory_hits", 0),
                        "model_used": response_data.get("model_used", "unknown"),
                        "category": response_data.get("category", "unknown"),
                        "confidence_score": response_data.get("confidence_score", 0),
                        "processing_time_ms": response_data.get("processing_time_ms", 0),
                        "context_length": response_data.get("context_length", 0),
                        "cache_hits": response_data.get("cache_hits", 0),
                        "specialist_routing": response_data.get("specialist_routing", {}),
                        "memory_operations": response_data.get("memory_operations", [])
                    }
                    
                    # Routing analysis
                    turn_result["routing_decision"] = {
                        "detected_category": response_data.get("category", "unknown"),
                        "matches_expected": response_data.get("category") == turn_info["expected_category"],
                        "model_selected": response_data.get("model_used", "unknown"),
                        "routing_confidence": response_data.get("confidence_score", 0),
                        "fallback_used": response_data.get("fallback_used", False)
                    }
                    
                    # Extract response text
                    response_text = ""
                    if "text" in response_data:
                        response_text = response_data["text"]
                    elif "response" in response_data:
                        response_text = response_data["response"]
                    elif isinstance(response_data, str):
                        response_text = response_data
                    else:
                        response_text = str(response_data)
                    
                    turn_result["response_text"] = response_text[:200] + "..." if len(response_text) > 200 else response_text
                    turn_result["response_length"] = len(response_text)
                
                print(f"   ✅ Success: {turn_result['performance']['request_latency_ms']:.1f}ms")
                if turn_result["metrics"].get("model_used"):
                    print(f"   🤖 Model: {turn_result['metrics']['model_used']}")
                if turn_result["metrics"].get("real_toks_per_sec"):
                    print(f"   ⚡ Speed: {turn_result['metrics']['real_toks_per_sec']:.1f} tokens/sec")
                    
            else:
                turn_result["error"] = {
                    "status_code": response.status_code,
                    "error_text": response.text[:200]
                }
                print(f"   ❌ Error: {response.status_code}")
                
        except Exception as e:
            turn_result["error"] = {
                "exception": str(e),
                "type": type(e).__name__
            }
            print(f"   💥 Exception: {e}")
        
        # Calculate turn timing
        turn_end = time.time()
        turn_result["performance"]["total_turn_time_ms"] = (turn_end - turn_start) * 1000
        
        return turn_result
    
    def _build_context(self) -> Dict[str, Any]:
        """Build conversation context from history"""
        context = {
            "previous_turns": len(self.conversation_history),
            "recent_categories": [],
            "recent_models": [],
            "conversation_summary": []
        }
        
        # Get last 3 turns for context
        recent_turns = self.conversation_history[-3:] if len(self.conversation_history) >= 3 else self.conversation_history
        
        for turn in recent_turns:
            context["recent_categories"].append(turn.get("routing_decision", {}).get("detected_category", "unknown"))
            context["recent_models"].append(turn.get("metrics", {}).get("model_used", "unknown"))
            context["conversation_summary"].append({
                "turn": turn.get("turn_number"),
                "user": turn.get("user_input", "")[:50],
                "category": turn.get("routing_decision", {}).get("detected_category", "unknown")
            })
        
        return context
    
    def _update_session_metrics(self, turn_result: Dict):
        """Update running session metrics"""
        self.session_metrics["total_turns"] += 1
        
        if turn_result.get("metrics"):
            metrics = turn_result["metrics"]
            self.session_metrics["total_tokens"] += metrics.get("total_tokens", 0)
            
            if metrics.get("model_used"):
                self.session_metrics["models_used"].add(metrics["model_used"])
                
            if metrics.get("category"):
                self.session_metrics["categories_hit"].add(metrics["category"])
                
            if metrics.get("memory_hits", 0) > 0:
                self.session_metrics["memory_interactions"] += metrics["memory_hits"]
        
        if turn_result.get("performance", {}).get("total_turn_time_ms"):
            self.session_metrics["total_latency_ms"] += turn_result["performance"]["total_turn_time_ms"]

def main():
    """Main instrumented trace execution"""
    parser = argparse.ArgumentParser(description="Generate instrumented chat trace")
    parser.add_argument("--serve-url", default="http://localhost:8000", help="Swarm serve URL")
    parser.add_argument("--output", default="instrumented_chat_trace.json", help="Output file")
    
    args = parser.parse_args()
    
    # Test connection first
    try:
        response = requests.get(f"{args.serve_url}/health", timeout=5)
        if response.status_code == 200:
            print("✅ Swarm connection verified")
        else:
            print(f"⚠️ Swarm health check returned {response.status_code}")
            print("Proceeding anyway...")
    except Exception as e:
        print(f"❌ Cannot connect to swarm: {e}")
        print("💡 Make sure 'python serve.py' is running")
        return
    
    # Execute instrumented conversation
    chat = InstrumentedChat(args.serve_url)
    conversation_data = chat.execute_conversation()
    
    # Generate summary
    metrics = conversation_data["session_metrics"]
    print(f"\n📊 SESSION SUMMARY")
    print("-" * 30)
    print(f"🔄 Turns: {metrics['total_turns']}")
    print(f"📝 Total tokens: {metrics['total_tokens']}")
    print(f"⏱️ Total time: {metrics.get('session_duration_s', 0):.1f}s")
    print(f"🤖 Models used: {', '.join(metrics['models_used'])}")
    print(f"🎯 Categories: {', '.join(metrics['categories_hit'])}")
    print(f"🧠 Memory interactions: {metrics['memory_interactions']}")
    
    # Calculate average metrics
    if metrics['total_turns'] > 0:
        avg_latency = metrics['total_latency_ms'] / metrics['total_turns']
        print(f"⚡ Avg latency: {avg_latency:.1f}ms per turn")
        
        if metrics['total_tokens'] > 0 and metrics.get('session_duration_s', 0) > 0:
            tokens_per_sec = metrics['total_tokens'] / metrics['session_duration_s']
            print(f"🚀 Overall throughput: {tokens_per_sec:.1f} tokens/sec")
    
    # Routing accuracy analysis
    routing_accuracy = []
    for turn in conversation_data["conversation_history"]:
        if turn.get("routing_decision"):
            routing_accuracy.append(turn["routing_decision"].get("matches_expected", False))
    
    if routing_accuracy:
        accuracy_pct = (sum(routing_accuracy) / len(routing_accuracy)) * 100
        print(f"🎯 Routing accuracy: {accuracy_pct:.1f}% ({sum(routing_accuracy)}/{len(routing_accuracy)})")
    
    # Save results
    with open(args.output, 'w') as f:
        json.dump(conversation_data, f, indent=2, default=str)
    
    print(f"\n💾 Instrumented trace saved to: {args.output}")
    print("\n🎯 Key metrics for RTX 4070 tuning:")
    print("   📊 Memory usage patterns in VRAM metrics")
    print("   ⚡ Token generation speeds per model")
    print("   🧠 Context compression effectiveness")
    print("   🎯 Specialist routing accuracy")
    print("   🔄 Cross-turn conversation memory")

if __name__ == "__main__":
    main() 