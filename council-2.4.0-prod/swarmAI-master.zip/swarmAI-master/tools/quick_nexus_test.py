#!/usr/bin/env python3
"""
🔥💀⚔️ QUICK NEXUS TEST - VERIFY MATH ROUTING ⚔️💀🔥
=====================================================
MISSION: Test NEXUS math engine is working before Boss-200
TARGET: Verify factorial calculations work correctly
STRATEGY: Quick 10-question math test with latency measurement
"""

import time
import requests
import statistics
from typing import List, Tuple

def test_nexus_math() -> List[Tuple[str, str, float, bool]]:
    """Test NEXUS mathematical capabilities"""
    
    test_cases = [
        ("Calculate 7!", "5040"),
        ("What is 15!?", "1307674368000"),
        ("Calculate 6!", "720"),
        ("What is 25% of 240?", "60"),
        ("Calculate 8 * 7 * 6 * 5", "1680"),
        ("What is 40% of 150?", "60"),
        ("Calculate 9!", "362880"),
        ("What is 75% of 80?", "60"),
        ("Calculate 12 * 13", "156"),
        ("What is 2^10?", "1024")
    ]
    
    print("🔥💀⚔️ QUICK NEXUS MATH TEST")
    print("=" * 40)
    print("🎯 Testing mathematical routing and accuracy")
    
    results = []
    session = requests.Session()
    
    # Warmup
    print("\n🔥 Warming up...")
    for i in range(3):
        session.post("http://localhost:8000/query", json={"query": "ping"})
    
    print("\n⚡ Running math tests...")
    for i, (query, expected) in enumerate(test_cases):
        start = time.time()
        
        try:
            response = session.post(
                "http://localhost:8000/query",
                json={"query": query}  # Let server auto-detect problem type
            )
            latency = (time.time() - start) * 1000
            
            if response.status_code == 200:
                data = response.json()
                response_text = data.get("text", "")
                method = data.get("method", "unknown")
                
                # Check if response contains expected answer
                contains_answer = expected in response_text
                
                status = "✅" if contains_answer else "❌"
                print(f"   {status} Q{i+1}: {query} → {response_text[:50]}...")
                print(f"      Expected: {expected}, Method: {method}, Latency: {latency:.1f}ms")
                
                results.append((query, response_text, latency, contains_answer))
            else:
                print(f"   ❌ Q{i+1}: HTTP {response.status_code}")
                results.append((query, f"HTTP {response.status_code}", 0, False))
                
        except Exception as e:
            print(f"   ❌ Q{i+1}: ERROR - {e}")
            results.append((query, f"ERROR: {e}", 0, False))
    
    session.close()
    return results

def analyze_results(results: List[Tuple[str, str, float, bool]]):
    """Analyze test results"""
    
    correct = sum(1 for _, _, _, is_correct in results if is_correct)
    total = len(results)
    accuracy = correct / total if total > 0 else 0
    
    latencies = [lat for _, _, lat, _ in results if lat > 0]
    avg_latency = statistics.mean(latencies) if latencies else 0
    p95_latency = statistics.quantiles(latencies, n=20)[18] if len(latencies) > 10 else max(latencies) if latencies else 0
    
    print(f"\n📊 QUICK TEST RESULTS:")
    print(f"   🎯 Accuracy: {accuracy:.3f} ({correct}/{total})")
    print(f"   ⚡ Avg latency: {avg_latency:.1f}ms")
    print(f"   ⚡ P95 latency: {p95_latency:.1f}ms")
    
    if accuracy >= 0.8 and p95_latency <= 50:
        print(f"\n✅ NEXUS READY FOR BOSS-200!")
        return True
    else:
        print(f"\n⚠️ NEXUS needs tuning:")
        if accuracy < 0.8:
            print(f"   📊 Accuracy too low: {accuracy:.3f} < 0.8")
        if p95_latency > 50:
            print(f"   ⚡ Latency too high: {p95_latency:.1f}ms > 50ms")
        return False

def main():
    """Run quick NEXUS test"""
    
    results = test_nexus_math()
    ready = analyze_results(results)
    
    if ready:
        print("\n🚀 LAUNCHING BOSS-200 BENCHMARK...")
        # Could automatically launch boss_test.py here
    else:
        print("\n🔧 Fix NEXUS issues before Boss-200")

if __name__ == "__main__":
    main() 