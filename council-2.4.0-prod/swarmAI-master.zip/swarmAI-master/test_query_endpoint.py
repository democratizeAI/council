#!/usr/bin/env python3
import requests
import json

def test_query(payload, description):
    print(f"\n🧪 Testing: {description}")
    print(f"   Payload: {payload}")
    
    try:
        response = requests.post("http://localhost:8000/query", json=payload, timeout=10)
        print(f"   Status: {response.status_code}")
        
        if response.status_code == 200:
            result = response.json()
            print(f"   ✅ Success: {result.get('text', '')[:100]}...")
            print(f"   Method: {result.get('method', 'unknown')}")
            print(f"   Confidence: {result.get('confidence', 0)}")
            return result
        else:
            print(f"   ❌ Error: {response.text[:100]}")
            return None
            
    except Exception as e:
        print(f"   💥 Exception: {e}")
        return None

def main():
    print("🔥 Testing /query endpoint with different payloads...")
    
    # Test different payload formats
    test_cases = [
        ({"query": "Calculate 5!"}, "Math query"),
        ({"query": "Are you conscious?"}, "Philosophy query"),
        ({"task": "Calculate 5!"}, "Task format"),
        ({"message": "Hello"}, "Message format"),
        ({"input": "Test input"}, "Input format"),
        ({"prompt": "What is 2+2?"}, "Prompt format"),
        ({"query": "Hello! My name is Alex", "context": "user introduction"}, "Query with context"),
        ({"query": "What is consciousness?", "type": "philosophical"}, "Query with type"),
    ]
    
    results = []
    for payload, description in test_cases:
        result = test_query(payload, description)
        if result:
            results.append((description, result))
    
    print("\n✅ SUCCESSFUL QUERIES:")
    print("=" * 50)
    for desc, result in results:
        print(f"📌 {desc}")
        print(f"   Method: {result.get('method')}")
        print(f"   Response: {result.get('text', '')[:80]}...")

if __name__ == "__main__":
    main() 