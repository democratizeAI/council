#!/usr/bin/env python3
"""
🔥💀⚔️ SPRINT S-1: CALCULUS SLICE TEST - SYMPY CAS INTEGRATION ⚔️💀🔥
================================================================
MISSION: Test advanced symbolic math with calculus operations
TARGET: ≥ 90% accuracy on symbolic operations (derivatives, integrals, limits)
"""

import time
import json
from lightning_math_engine import lightning_math_solve

class CalculusSliceTester:
    """Test calculus operations with SymPy CAS"""
    
    def __init__(self):
        self.results = []
        
    def run_calculus_slice(self):
        """Run 10-item calculus test slice for Sprint S-1"""
        
        print("🔥💀⚔️ SPRINT S-1: CALCULUS SLICE TEST ⚔️💀🔥")
        print("=" * 60)
        
        # 🧮 CALCULUS TEST PROBLEMS - Sprint S-1 Advanced Math
        calculus_problems = [
            {
                "id": "calc_001",
                "query": "find the derivative of x^2 + 3x + 1",
                "expected_patterns": ["2*x + 3", "2x + 3"],
                "operation": "derivative",
                "difficulty": "basic"
            },
            {
                "id": "calc_002", 
                "query": "integrate x^2 with respect to x",
                "expected_patterns": ["x**3/3", "x^3/3"],
                "operation": "integral",
                "difficulty": "basic"
            },
            {
                "id": "calc_003",
                "query": "differentiate sin(x) with respect to x",
                "expected_patterns": ["cos(x)", "cos(x)"],
                "operation": "derivative",
                "difficulty": "intermediate"
            },
            {
                "id": "calc_004",
                "query": "find the integral of cos(x)",
                "expected_patterns": ["sin(x)", "sin(x)"],
                "operation": "integral", 
                "difficulty": "intermediate"
            },
            {
                "id": "calc_005",
                "query": "compute the limit of (x^2 - 1)/(x - 1) as x approaches 1",
                "expected_patterns": ["2"],
                "operation": "limit",
                "difficulty": "intermediate"
            },
            {
                "id": "calc_006",
                "query": "solve x^2 - 4 = 0 for x",
                "expected_patterns": ["-2", "2"],
                "operation": "solve",
                "difficulty": "basic"
            },
            {
                "id": "calc_007",
                "query": "expand (x + 1)^2",
                "expected_patterns": ["x**2 + 2*x + 1", "x^2 + 2x + 1"],
                "operation": "expand",
                "difficulty": "basic"
            },
            {
                "id": "calc_008",
                "query": "factor x^2 + 5x + 6",
                "expected_patterns": ["(x + 2)", "(x + 3)"],
                "operation": "factor",
                "difficulty": "intermediate"
            },
            {
                "id": "calc_009",
                "query": "find d/dx (e^x * sin(x))",
                "expected_patterns": ["e**x*sin(x) + e**x*cos(x)", "e^x*sin(x) + e^x*cos(x)"],
                "operation": "derivative",
                "difficulty": "advanced"
            },
            {
                "id": "calc_010",
                "query": "integrate x*ln(x) dx",
                "expected_patterns": ["x**2*log(x)/2 - x**2/4", "x^2*ln(x)/2 - x^2/4"],
                "operation": "integral",
                "difficulty": "advanced"
            }
        ]
        
        start_time = time.time()
        total_passed = 0
        
        for i, problem in enumerate(calculus_problems):
            print(f"\n📝 Test {i+1}/10: {problem['id']} ({problem['difficulty']})")
            print(f"   Query: {problem['query']}")
            
            test_start = time.time()
            result = lightning_math_solve(problem["query"])
            test_latency = (time.time() - test_start) * 1000
            
            # Check if result matches expected patterns
            passed = False
            result_text = result.get("text", "").lower()
            
            if result.get("success", False):
                # Check for symbolic result
                symbolic_result = result.get("result_symbolic", "").lower()
                
                # Look for expected patterns in both text and symbolic result
                for pattern in problem["expected_patterns"]:
                    if pattern.lower() in result_text or pattern.lower() in symbolic_result:
                        passed = True
                        break
                
                if passed:
                    print(f"   ✅ PASS: {result.get('method', 'unknown')} ({test_latency:.1f}ms)")
                    print(f"      Result: {result.get('result_symbolic', result.get('text', '')[:100])}")
                    total_passed += 1
                else:
                    print(f"   ❌ FAIL: Expected patterns {problem['expected_patterns']}")
                    print(f"      Got: {result.get('result_symbolic', result.get('text', ''))[:100]}")
            else:
                print(f"   ❌ FAIL: Solver failed - {result.get('error', 'unknown error')}")
            
            # Store result
            self.results.append({
                "problem_id": problem["id"],
                "query": problem["query"],
                "expected": problem["expected_patterns"],
                "actual": result.get("result_symbolic", result.get("text", "")),
                "passed": passed,
                "latency_ms": test_latency,
                "method": result.get("method", "failed"),
                "operation": problem["operation"],
                "difficulty": problem["difficulty"]
            })
        
        total_time = time.time() - start_time
        accuracy = total_passed / len(calculus_problems)
        avg_latency = sum(r["latency_ms"] for r in self.results) / len(self.results)
        
        print(f"\n🔥💀⚔️ SPRINT S-1 CALCULUS SLICE RESULTS ⚔️💀🔥")
        print("=" * 60)
        print(f"⚡ CALCULUS ACCURACY: {accuracy:.1%} ({total_passed}/{len(calculus_problems)})")
        print(f"⚡ AVERAGE LATENCY: {avg_latency:.1f}ms")
        print(f"⚡ TOTAL TEST TIME: {total_time:.1f}s")
        
        # Breakdown by operation type
        operations = {}
        for result in self.results:
            op = result["operation"]
            if op not in operations:
                operations[op] = {"passed": 0, "total": 0}
            operations[op]["total"] += 1
            if result["passed"]:
                operations[op]["passed"] += 1
        
        print(f"\n📊 OPERATION BREAKDOWN:")
        for op, stats in operations.items():
            acc = stats["passed"] / stats["total"] if stats["total"] > 0 else 0
            print(f"   {op}: {acc:.1%} ({stats['passed']}/{stats['total']})")
        
        # Sprint S-1 success criteria
        if accuracy >= 0.9:
            print(f"\n🟢 SPRINT S-1 SUCCESS: {accuracy:.1%} ≥ 90% target!")
            print("🚀 Ready to proceed to Sprint S-2: Deep Logic Gap")
        else:
            print(f"\n🟡 SPRINT S-1 PARTIAL: {accuracy:.1%} < 90% target")
            print("🔧 Need to tune CAS patterns or add more symbolic operations")
        
        return {
            "accuracy": accuracy,
            "total_passed": total_passed,
            "total_problems": len(calculus_problems),
            "avg_latency_ms": avg_latency,
            "total_time_s": total_time,
            "operations": operations,
            "results": self.results
        }

def main():
    """Run calculus slice test for Sprint S-1"""
    tester = CalculusSliceTester()
    results = tester.run_calculus_slice()
    
    # Save results
    with open("calculus_slice_results.json", "w") as f:
        json.dump(results, f, indent=2)
    
    print(f"\n💾 Results saved to calculus_slice_results.json")

if __name__ == "__main__":
    main() 