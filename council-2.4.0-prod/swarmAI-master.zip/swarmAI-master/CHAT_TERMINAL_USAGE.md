# 🧠⚡ V11 Emotional Chat Terminal Usage Guide

## Quick Start

```bash
# Start the emotional chat terminal
python emotional_chat_terminal.py
```

## Features

### 1. 🎭 Emotion Banners
Every response shows the emotional state of the 9-agent swarm:
```
[🤔 Anticipation + 😀 Joy – 🚫 Fear]
```

### 2. 💬 Natural Conversation 
Just type naturally:
```
YOU: How can we improve protein folding predictions?
SWARM: [🤔 Anticipation + 😀 Joy – 🚫 Fear]
       Current approaches miss side-chain entropy. A specialist could improve accuracy...
```

### 3. 🔬 LoRA Evolution Requests
Use natural language to request new capabilities:
```
YOU: could you grow a Python regex skill?
SWARM: [🤔 Anticipation + 😀 Joy – 🚫 Fear]
       We can develop regex expertise targeting common parsing tasks...
       
       ✚ Proposed LoRA: python_regex_lora
          gain_target : +6pp on code-block
          size_estimate: ~22 MB
          approve? (yes / no / edit)

APPROVE: yes
SWARM: ✔️ Queued job `python_regex_lora`. Training will run in tonight's window.
```

## Commands

- **help** - Show command reference
- **stop** - Toggle evolution on/off  
- **/debug** - Show full emotional transcripts
- **exit/quit** - Leave chat

## Evolution Triggers

These phrases trigger LoRA proposal generation:
- "grow [skill]"
- "train [capability]" 
- "could you learn [topic]"
- "add [feature]"
- "create [specialist]"
- "build [capability]"

## Behind the Scenes

1. **Normal Chat**: V11 Emotional Swarm (9 agents) → Consensus → Clean response
2. **LoRA Requests**: Emotional Round-Table → Democratic voting → Job spec generation
3. **Approval**: Creates YAML job specs in `jobs/queue/` for autonomous training

## System Integration

The chat terminal integrates with:
- ✅ V11 Emotional Swarm (sub-10ms consensus)
- ✅ Emotional Round-Table Protocol (democratic evolution)
- ✅ Cross-Agent Consensus Orchestrator (30-head reasoning) 
- ✅ Tamagotchi Evolution Queue (autonomous training)

Perfect for interactive exploration of the V11 Emotional AI system! 🚀 